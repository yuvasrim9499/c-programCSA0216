# Smart Library — Smart Library Management System

A responsive, multi-page Library Management System built with React, TypeScript, Vite, Tailwind CSS, Recharts, and React Router, supporting **Admin / Librarian** and **Student** workflows.

---

## Installation & Local Setup

1. **Install dependencies**
   ```bash
   npm install
   ```
2. **Start the development server**
   ```bash
   npm run dev
   ```
   The app runs on `http://localhost:3000`.
3. **Type-check and build for production**
   ```bash
   npm run lint
   npm run build
   ```

---

## Demo Credentials

All seeded data is stored locally in the browser via `localStorage` on first launch and can be restored anytime from **Settings → Reset Demo Data**.

| Role | Name | Email | Password | Notes |
| --- | --- | --- | --- | --- |
| **Admin / Librarian** | Dr. Elena Rostova | `admin@smartlibrary.edu` | `Admin@2026` | Full catalog, student, circulation, reports & settings access |
| **Student (Active History)** | Maya Patel (`STU-2026-101`) | `maya.patel@smartlibrary.edu` | `Student@2026` | Active, due-soon, overdue, and returned loans + wishlist |
| **Student (No Loan History)** | Liam Okafor (`STU-2026-108`) | `liam.okafor@smartlibrary.edu` | `Student@2026` | Demonstrates rule-based fallback recommendations for new readers |

> Public registration on `/login` creates **Student** accounts only; administrator accounts cannot be created via public registration.

---

## Project Structure

```text
src/
├── assets/images/        # Local book cover artwork & login hero illustration
├── components/           # Reusable UI & layout components
│   ├── AppLayout.tsx     # Responsive shell (sidebar, collapsible tablet state, mobile drawer)
│   ├── Sidebar.tsx       # Role-based navigation in deep navy (#0C102D)
│   ├── Header.tsx        # Sidebar toggle, global catalog search, notifications, profile menu
│   ├── StatCard.tsx      # KPI summary cards with tabular numerals
│   ├── BookCard.tsx      # Grid & list book cards with wishlist/admin actions
│   ├── BookCover.tsx     # Cover image with stylized SVG/CSS fallback on error
│   ├── BookFilters.tsx   # Search, category, availability, sort, and layout controls
│   ├── BookFormModal.tsx # Add/Edit book modal with ISBN & copy-count validation
│   ├── StudentFormModal.tsx # Add/Edit student modal with duplicate ID/email checks
│   ├── DataTable.tsx     # Horizontally scrollable data table wrapper
│   ├── StatusBadge.tsx   # Accessible color + icon + text badges
│   ├── Modal.tsx / ConfirmDialog.tsx / FormField.tsx / EmptyState.tsx / ToastContainer.tsx
│   └── ProtectedRoute.tsx # Route & role-based access guard
├── context/
│   └── LibraryContext.tsx # Reactive app state synchronized with service layer
├── data/
│   └── seedData.ts       # Relative-date seed generator (18 books, 8 students, 20 loans)
├── hooks/
│   └── useLibrary.ts     # Context consumer hook
├── pages/                # Multi-page views for Admin & Student roles
│   ├── LoginPage.tsx
│   ├── DashboardPage.tsx / AdminDashboard.tsx / StudentDashboard.tsx
│   ├── BookCatalogPage.tsx / BookDetailPage.tsx
│   ├── StudentsPage.tsx
│   ├── IssueReturnPage.tsx
│   ├── RecommendationsPage.tsx
│   ├── MyLoansPage.tsx / WishlistPage.tsx / ProfilePage.tsx
│   ├── ReportsPage.tsx
│   ├── NotificationsPage.tsx
│   └── SettingsPage.tsx
├── services/             # Decoupled data-access & business-logic layer
│   ├── storageService.ts # localStorage adapter + inventory reconciliation
│   ├── authService.ts
│   ├── bookService.ts
│   ├── studentService.ts
│   ├── loanService.ts
│   ├── recommendationService.ts
│   ├── notificationService.ts
│   ├── reportService.ts
│   └── settingsService.ts
├── types/
│   └── library.ts        # Domain TypeScript interfaces
└── utils/
    └── dateUtils.ts      # Calendar-safe YYYY-MM-DD utilities
```

---

## Demo Scope vs. Production Backend Requirements

This application is structured with a decoupled `src/services/` layer so a backend API can replace `storageService.ts` cleanly. The following parts are **local demo implementations** and would require server-side infrastructure for production:

1. **Authentication & Sessions**: Demo login checks credentials stored in browser `localStorage` (`authService.ts`). Production requires server-side password hashing (Argon2/bcrypt), signed HTTP-only session cookies or short-lived JWTs, and server-enforced RBAC middleware.
2. **Persistence & Concurrency**: Inventory updates (`availableCopies`) and loan transactions run in `localStorage`. Production requires a relational or transactional database (e.g., PostgreSQL) with atomic row locking so concurrent checkouts cannot over-allocate copies.
3. **Notifications & Email**: Due-soon and overdue alerts are generated client-side when the app loads (`notificationService.ts`). Production should run scheduled server jobs (cron/workers) for email/SMS reminders.
4. **Recommendations**: `recommendationService.ts` uses transparent, deterministic rule-based scoring over borrowing history, wishlist items, and topic interests without external AI APIs.
