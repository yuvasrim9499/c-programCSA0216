import {
  AdminAccount,
  Book,
  BookCategory,
  LibraryDatabase,
  LibrarySettings,
  Loan,
  NotificationItem,
  Student,
  WishlistMap,
} from '../types/library';
import { addDaysToTodayISO, getTodayISO } from '../utils/dateUtils';

export const LOGIN_HERO_IMAGE = '/src/assets/images/login_hero_library_1795592754804.jpg';

export const BOOK_COVERS = {
  python: '/src/assets/images/cover_python_code_1795592755166.jpg',
  machineLearning: '/src/assets/images/cover_machine_learning_1795592756094.jpg',
  dataScience: '/src/assets/images/cover_data_science_1795592756407.jpg',
  webDev: '/src/assets/images/cover_web_dev_1795592756808.jpg',
  deepLearning: '/src/assets/images/cover_deep_learning_1795592757684.jpg',
  aiSystems: '/src/assets/images/cover_ai_systems_1795592757377.jpg',
  algorithms: '/src/assets/images/cover_algorithms_math_1795592758150.jpg',
  softwareDesign: '/src/assets/images/cover_software_design_1795592758514.jpg',
};

export const ALL_CATEGORIES: BookCategory[] = [
  'Programming',
  'Artificial Intelligence',
  'Data Science',
  'Web & Systems',
  'Software Engineering',
  'Computer Science',
  'Design & UX',
];

export const DEFAULT_SETTINGS: LibrarySettings = {
  libraryName: 'Smart Library',
  defaultLoanDays: 14,
  maxActiveLoansPerStudent: 4,
  dailyOverdueFine: 1.5,
  currencySymbol: '₹',
  dueSoonWindowDays: 3,
};

export function createSeedDatabase(): LibraryDatabase {
  const today = getTodayISO();

  const admins: AdminAccount[] = [
    {
      id: 'adm-1',
      name: 'Dr. Elena Rostova',
      email: 'admin@smartlibrary.edu',
      password: 'Admin@2026',
      roleTitle: 'Head Librarian',
    },
  ];

  const baseBooks: Omit<Book, 'availableCopies'>[] = [
    {
      id: 'bk-101',
      title: 'Python Programming',
      author: 'Eric Matthes',
      isbn: '978-1718502703',
      category: 'Programming',
      description:
        'A hands-on, project-based introduction to Python covering clean syntax, object-oriented fundamentals, testing, and practical data visualization.',
      publicationYear: 2023,
      totalCopies: 6,
      shelfLocation: 'A1-04',
      rating: 4.9,
      coverUrl: BOOK_COVERS.python,
      addedAt: addDaysToTodayISO(-140),
    },
    {
      id: 'bk-102',
      title: 'Machine Learning',
      author: 'Tom M. Mitchell',
      isbn: '978-0070428072',
      category: 'Artificial Intelligence',
      description:
        'Foundational algorithms and statistical theory behind decision trees, Bayesian learning, neural networks, and reinforcement learning.',
      publicationYear: 2021,
      totalCopies: 4,
      shelfLocation: 'B2-11',
      rating: 4.8,
      coverUrl: BOOK_COVERS.machineLearning,
      addedAt: addDaysToTodayISO(-130),
    },
    {
      id: 'bk-103',
      title: 'Data Science Basics',
      author: 'Joel Grus',
      isbn: '978-1492041139',
      category: 'Data Science',
      description:
        'Learn the mathematics, probability, linear algebra, and data manipulation pipelines from first principles using clear worked examples.',
      publicationYear: 2022,
      totalCopies: 5,
      shelfLocation: 'B3-02',
      rating: 4.7,
      coverUrl: BOOK_COVERS.dataScience,
      addedAt: addDaysToTodayISO(-120),
    },
    {
      id: 'bk-104',
      title: 'Web Development',
      author: 'Jon Duckett',
      isbn: '978-1118907443',
      category: 'Web & Systems',
      description:
        'Visual guide to modern semantic HTML, responsive CSS architecture, interactive DOM scripting, and accessible web standards.',
      publicationYear: 2023,
      totalCopies: 5,
      shelfLocation: 'C1-08',
      rating: 4.6,
      coverUrl: BOOK_COVERS.webDev,
      addedAt: addDaysToTodayISO(-110),
    },
    {
      id: 'bk-105',
      title: 'Deep Learning',
      author: 'Ian Goodfellow & Yoshua Bengio',
      isbn: '978-0262035613',
      category: 'Artificial Intelligence',
      description:
        'Comprehensive reference on optimization, convolutional architectures, sequence modeling, representation learning, and generative models.',
      publicationYear: 2022,
      totalCopies: 3,
      shelfLocation: 'B2-18',
      rating: 4.9,
      coverUrl: BOOK_COVERS.deepLearning,
      addedAt: addDaysToTodayISO(-100),
    },
    {
      id: 'bk-106',
      title: 'Artificial Intelligence',
      author: 'Stuart Russell & Peter Norvig',
      isbn: '978-0134610993',
      category: 'Artificial Intelligence',
      description:
        'Authoritative exploration of intelligent agents, heuristic search, probabilistic reasoning, robotics, and ethical AI design.',
      publicationYear: 2024,
      totalCopies: 4,
      shelfLocation: 'B1-01',
      rating: 4.8,
      coverUrl: BOOK_COVERS.aiSystems,
      addedAt: addDaysToTodayISO(-95),
    },
    {
      id: 'bk-107',
      title: 'Data Science with Python',
      author: 'Jake VanderPlas',
      isbn: '978-1491912058',
      category: 'Data Science',
      description:
        'Essential guide to NumPy, pandas, Matplotlib, and Scikit-Learn workflows for exploratory analysis and reproducible modeling.',
      publicationYear: 2024,
      totalCopies: 5,
      shelfLocation: 'B3-09',
      rating: 4.9,
      coverUrl: BOOK_COVERS.dataScience,
      addedAt: addDaysToTodayISO(-85),
    },
    {
      id: 'bk-108',
      title: 'Clean Code Architecture',
      author: 'Robert C. Martin',
      isbn: '978-0132350884',
      category: 'Software Engineering',
      description:
        'Practical principles for modular boundaries, maintainable abstractions, automated testing discipline, and resilient team codebases.',
      publicationYear: 2021,
      totalCopies: 4,
      shelfLocation: 'D2-03',
      rating: 4.7,
      coverUrl: BOOK_COVERS.softwareDesign,
      addedAt: addDaysToTodayISO(-80),
    },
    {
      id: 'bk-109',
      title: 'Introduction to Algorithms',
      author: 'Thomas H. Cormen',
      isbn: '978-0262046305',
      category: 'Computer Science',
      description:
        'Rigorous treatment of asymptotic complexity, graph traversal, dynamic programming, amortized analysis, and NP-completeness.',
      publicationYear: 2023,
      totalCopies: 3,
      shelfLocation: 'A3-12',
      rating: 4.9,
      coverUrl: BOOK_COVERS.algorithms,
      addedAt: addDaysToTodayISO(-75),
    },
    {
      id: 'bk-110',
      title: 'Designing Data-Intensive Applications',
      author: 'Martin Kleppmann',
      isbn: '978-1449373320',
      category: 'Web & Systems',
      description:
        'Deep dive into distributed consensus, replication, partitioning, stream processing, and reliable storage engine internals.',
      publicationYear: 2024,
      totalCopies: 4,
      shelfLocation: 'C2-05',
      rating: 5.0,
      coverUrl: BOOK_COVERS.webDev,
      addedAt: addDaysToTodayISO(-65),
    },
    {
      id: 'bk-111',
      title: 'Statistical Learning Methods',
      author: 'Trevor Hastie & Robert Tibshirani',
      isbn: '978-0387848570',
      category: 'Data Science',
      description:
        'Unified statistical framework covering regression shrinkage, kernel smoothing, support vector machines, and ensemble trees.',
      publicationYear: 2022,
      totalCopies: 3,
      shelfLocation: 'B3-15',
      rating: 4.8,
      coverUrl: BOOK_COVERS.algorithms,
      addedAt: addDaysToTodayISO(-55),
    },
    {
      id: 'bk-112',
      title: 'Modern React & TypeScript',
      author: 'Alex Banks & Eve Porcello',
      isbn: '978-1492051725',
      category: 'Web & Systems',
      description:
        'Type-safe component patterns, state architecture, concurrent rendering, and accessible UI engineering for production web apps.',
      publicationYear: 2025,
      totalCopies: 5,
      shelfLocation: 'C1-14',
      rating: 4.7,
      coverUrl: BOOK_COVERS.python,
      addedAt: addDaysToTodayISO(-40),
    },
    {
      id: 'bk-113',
      title: 'Human-Centered Interface Design',
      author: 'Don Norman',
      isbn: '978-0465050659',
      category: 'Design & UX',
      description:
        'Classic examination of affordances, signifiers, conceptual models, and error-tolerant digital and physical product design.',
      publicationYear: 2022,
      totalCopies: 4,
      shelfLocation: 'E1-02',
      rating: 4.8,
      coverUrl: BOOK_COVERS.softwareDesign,
      addedAt: addDaysToTodayISO(-35),
    },
    {
      id: 'bk-114',
      title: 'Database Internals',
      author: 'Alex Petrov',
      isbn: '978-1492040347',
      category: 'Web & Systems',
      description:
        'How B-trees, LSM-trees, write-ahead logs, and distributed transactions operate inside modern storage engines.',
      publicationYear: 2023,
      totalCopies: 2,
      shelfLocation: 'C2-11',
      rating: 4.8,
      coverUrl: BOOK_COVERS.webDev,
      addedAt: addDaysToTodayISO(-30),
    },
    {
      id: 'bk-115',
      title: 'Operating System Concepts',
      author: 'Abraham Silberschatz',
      isbn: '978-1119800361',
      category: 'Computer Science',
      description:
        'Core principles of process scheduling, virtual memory, concurrency synchronization, file systems, and kernel security.',
      publicationYear: 2023,
      totalCopies: 4,
      shelfLocation: 'A2-07',
      rating: 4.6,
      coverUrl: BOOK_COVERS.algorithms,
      addedAt: addDaysToTodayISO(-22),
    },
    {
      id: 'bk-116',
      title: 'Natural Language Processing',
      author: 'Daniel Jurafsky & James H. Martin',
      isbn: '978-0131873216',
      category: 'Artificial Intelligence',
      description:
        'Comprehensive study of tokenization, transformer attention mechanisms, semantic parsing, and speech language models.',
      publicationYear: 2025,
      totalCopies: 3,
      shelfLocation: 'B2-22',
      rating: 4.9,
      coverUrl: BOOK_COVERS.deepLearning,
      addedAt: addDaysToTodayISO(-15),
    },
    {
      id: 'bk-117',
      title: 'Discrete Mathematics for Computing',
      author: 'Susanna S. Epp',
      isbn: '978-1337694193',
      category: 'Computer Science',
      description:
        'Clear foundation in formal logic, proof strategies, combinatorics, recurrence relations, and graph structures.',
      publicationYear: 2021,
      totalCopies: 4,
      shelfLocation: 'A3-04',
      rating: 4.5,
      coverUrl: BOOK_COVERS.algorithms,
      addedAt: addDaysToTodayISO(-10),
    },
    {
      id: 'bk-118',
      title: 'Systems Design & Scalability',
      author: 'Alex Xu',
      isbn: '978-1736049112',
      category: 'Software Engineering',
      description:
        'Step-by-step architectural blueprints for rate limiters, distributed caches, search indices, and high-throughput queues.',
      publicationYear: 2025,
      totalCopies: 5,
      shelfLocation: 'D1-09',
      rating: 4.8,
      coverUrl: BOOK_COVERS.aiSystems,
      addedAt: addDaysToTodayISO(-5),
    },
  ];

  const students: Student[] = [
    {
      id: 'stu-1',
      studentId: 'STU-2026-101',
      name: 'Maya Patel',
      email: 'maya.patel@smartlibrary.edu',
      password: 'Student@2026',
      department: 'Computer Science',
      year: 'Junior (Year 3)',
      status: 'active',
      interests: ['Data Science', 'Artificial Intelligence', 'Programming'],
      monthlyGoal: 4,
      notificationPrefs: { dueSoon: true, overdue: true, confirmations: true },
      joinedAt: addDaysToTodayISO(-180),
    },
    {
      id: 'stu-2',
      studentId: 'STU-2026-102',
      name: 'Ethan Brooks',
      email: 'ethan.brooks@smartlibrary.edu',
      password: 'Student@2026',
      department: 'Software Engineering',
      year: 'Senior (Year 4)',
      status: 'active',
      interests: ['Web & Systems', 'Software Engineering'],
      monthlyGoal: 3,
      notificationPrefs: { dueSoon: true, overdue: true, confirmations: true },
      joinedAt: addDaysToTodayISO(-165),
    },
    {
      id: 'stu-3',
      studentId: 'STU-2026-103',
      name: 'Sofia Alvarez',
      email: 'sofia.alvarez@smartlibrary.edu',
      password: 'Student@2026',
      department: 'Data Analytics',
      year: 'Sophomore (Year 2)',
      status: 'active',
      interests: ['Data Science', 'Computer Science'],
      monthlyGoal: 5,
      notificationPrefs: { dueSoon: true, overdue: true, confirmations: true },
      joinedAt: addDaysToTodayISO(-150),
    },
    {
      id: 'stu-4',
      studentId: 'STU-2026-104',
      name: 'Noah Takahashi',
      email: 'noah.takahashi@smartlibrary.edu',
      password: 'Student@2026',
      department: 'Artificial Intelligence',
      year: 'Graduate',
      status: 'active',
      interests: ['Artificial Intelligence', 'Computer Science'],
      monthlyGoal: 4,
      notificationPrefs: { dueSoon: true, overdue: true, confirmations: false },
      joinedAt: addDaysToTodayISO(-120),
    },
    {
      id: 'stu-5',
      studentId: 'STU-2026-105',
      name: 'Amara Nwosu',
      email: 'amara.nwosu@smartlibrary.edu',
      password: 'Student@2026',
      department: 'Human-Computer Interaction',
      year: 'Junior (Year 3)',
      status: 'active',
      interests: ['Design & UX', 'Web & Systems'],
      monthlyGoal: 3,
      notificationPrefs: { dueSoon: true, overdue: true, confirmations: true },
      joinedAt: addDaysToTodayISO(-95),
    },
    {
      id: 'stu-6',
      studentId: 'STU-2026-106',
      name: 'Lucas Lindqvist',
      email: 'lucas.lindqvist@smartlibrary.edu',
      password: 'Student@2026',
      department: 'Computer Science',
      year: 'Senior (Year 4)',
      status: 'active',
      interests: ['Software Engineering', 'Computer Science'],
      monthlyGoal: 3,
      notificationPrefs: { dueSoon: true, overdue: true, confirmations: true },
      joinedAt: addDaysToTodayISO(-80),
    },
    {
      id: 'stu-7',
      studentId: 'STU-2026-107',
      name: 'Chloe Moreau',
      email: 'chloe.moreau@smartlibrary.edu',
      password: 'Student@2026',
      department: 'Information Systems',
      year: 'Sophomore (Year 2)',
      status: 'inactive',
      interests: ['Web & Systems', 'Programming'],
      monthlyGoal: 2,
      notificationPrefs: { dueSoon: true, overdue: true, confirmations: true },
      joinedAt: addDaysToTodayISO(-210),
    },
    {
      id: 'stu-8',
      studentId: 'STU-2026-108',
      name: 'Liam Okafor',
      email: 'liam.okafor@smartlibrary.edu',
      password: 'Student@2026',
      department: 'Computer Science',
      year: 'Freshman (Year 1)',
      status: 'active',
      interests: ['Programming', 'Design & UX'],
      monthlyGoal: 3,
      notificationPrefs: { dueSoon: true, overdue: true, confirmations: true },
      joinedAt: addDaysToTodayISO(-12),
    },
  ];

  // Rich set of loans relative to today so active, due-soon, overdue, and returned loans are realistic
  const loans: Loan[] = [
    // Maya Patel (Demo Student) - 1 active healthy, 1 due soon, 1 overdue, 3 returned
    {
      id: 'LN-2026-001',
      bookId: 'bk-101', // Python Programming
      studentId: 'stu-1',
      issueDate: addDaysToTodayISO(-28),
      dueDate: addDaysToTodayISO(-14),
      returnDate: addDaysToTodayISO(-16),
      status: 'returned',
      finePaid: 0,
      notes: 'Returned early in excellent condition.',
    },
    {
      id: 'LN-2026-002',
      bookId: 'bk-103', // Data Science Basics
      studentId: 'stu-1',
      issueDate: addDaysToTodayISO(-19),
      dueDate: addDaysToTodayISO(-5),
      returnDate: addDaysToTodayISO(-6),
      status: 'returned',
      finePaid: 0,
    },
    {
      id: 'LN-2026-003',
      bookId: 'bk-102', // Machine Learning
      studentId: 'stu-1',
      issueDate: addDaysToTodayISO(-12),
      dueDate: addDaysToTodayISO(2), // Due soon!
      returnDate: null,
      status: 'active',
      finePaid: 0,
    },
    {
      id: 'LN-2026-004',
      bookId: 'bk-105', // Deep Learning
      studentId: 'stu-1',
      issueDate: addDaysToTodayISO(-18),
      dueDate: addDaysToTodayISO(-4), // Overdue 4 days!
      returnDate: null,
      status: 'active',
      finePaid: 0,
    },
    {
      id: 'LN-2026-005',
      bookId: 'bk-104', // Web Development
      studentId: 'stu-1',
      issueDate: addDaysToTodayISO(-4),
      dueDate: addDaysToTodayISO(10), // Active healthy
      returnDate: null,
      status: 'active',
      finePaid: 0,
    },
    {
      id: 'LN-2026-006',
      bookId: 'bk-109', // Introduction to Algorithms
      studentId: 'stu-1',
      issueDate: addDaysToTodayISO(-3),
      dueDate: addDaysToTodayISO(11),
      returnDate: addDaysToTodayISO(-1),
      status: 'returned',
      finePaid: 0,
    },
    // Ethan Brooks
    {
      id: 'LN-2026-007',
      bookId: 'bk-110', // Designing Data-Intensive Applications
      studentId: 'stu-2',
      issueDate: addDaysToTodayISO(-17),
      dueDate: addDaysToTodayISO(-3), // Overdue 3 days
      returnDate: null,
      status: 'active',
      finePaid: 0,
    },
    {
      id: 'LN-2026-008',
      bookId: 'bk-112', // Modern React & TypeScript
      studentId: 'stu-2',
      issueDate: addDaysToTodayISO(-5),
      dueDate: addDaysToTodayISO(9),
      returnDate: null,
      status: 'active',
      finePaid: 0,
    },
    {
      id: 'LN-2026-009',
      bookId: 'bk-108', // Clean Code Architecture
      studentId: 'stu-2',
      issueDate: addDaysToTodayISO(-22),
      dueDate: addDaysToTodayISO(-8),
      returnDate: addDaysToTodayISO(-5),
      status: 'returned',
      finePaid: 4.5,
    },
    // Sofia Alvarez
    {
      id: 'LN-2026-010',
      bookId: 'bk-107', // Data Science with Python
      studentId: 'stu-3',
      issueDate: addDaysToTodayISO(-13),
      dueDate: addDaysToTodayISO(1), // Due tomorrow
      returnDate: null,
      status: 'active',
      finePaid: 0,
    },
    {
      id: 'LN-2026-011',
      bookId: 'bk-111', // Statistical Learning Methods
      studentId: 'stu-3',
      issueDate: addDaysToTodayISO(-2),
      dueDate: addDaysToTodayISO(12),
      returnDate: null,
      status: 'active',
      finePaid: 0,
    },
    {
      id: 'LN-2026-012',
      bookId: 'bk-101', // Python Programming
      studentId: 'stu-3',
      issueDate: addDaysToTodayISO(-15),
      dueDate: addDaysToTodayISO(-1),
      returnDate: addDaysToTodayISO(-2),
      status: 'returned',
      finePaid: 0,
    },
    // Noah Takahashi
    {
      id: 'LN-2026-013',
      bookId: 'bk-106', // Artificial Intelligence
      studentId: 'stu-4',
      issueDate: addDaysToTodayISO(-20),
      dueDate: addDaysToTodayISO(-6), // Overdue 6 days
      returnDate: null,
      status: 'active',
      finePaid: 0,
    },
    {
      id: 'LN-2026-014',
      bookId: 'bk-116', // Natural Language Processing
      studentId: 'stu-4',
      issueDate: addDaysToTodayISO(-1),
      dueDate: addDaysToTodayISO(13),
      returnDate: null,
      status: 'active',
      finePaid: 0,
    },
    // Amara Nwosu
    {
      id: 'LN-2026-015',
      bookId: 'bk-113', // Human-Centered Interface Design
      studentId: 'stu-5',
      issueDate: addDaysToTodayISO(-6),
      dueDate: addDaysToTodayISO(8),
      returnDate: null,
      status: 'active',
      finePaid: 0,
    },
    {
      id: 'LN-2026-016',
      bookId: 'bk-104', // Web Development
      studentId: 'stu-5',
      issueDate: addDaysToTodayISO(-16),
      dueDate: addDaysToTodayISO(-2),
      returnDate: addDaysToTodayISO(-3),
      status: 'returned',
      finePaid: 0,
    },
    // Lucas Lindqvist
    {
      id: 'LN-2026-017',
      bookId: 'bk-114', // Database Internals
      studentId: 'stu-6',
      issueDate: addDaysToTodayISO(-12),
      dueDate: addDaysToTodayISO(2), // Due soon
      returnDate: null,
      status: 'active',
      finePaid: 0,
    },
    {
      id: 'LN-2026-018',
      bookId: 'bk-118', // Systems Design & Scalability
      studentId: 'stu-6',
      issueDate: addDaysToTodayISO(0),
      dueDate: addDaysToTodayISO(14),
      returnDate: null,
      status: 'active',
      finePaid: 0,
    },
    {
      id: 'LN-2026-019',
      bookId: 'bk-101', // Python Programming
      studentId: 'stu-6',
      issueDate: addDaysToTodayISO(-10),
      dueDate: addDaysToTodayISO(4),
      returnDate: addDaysToTodayISO(-4),
      status: 'returned',
      finePaid: 0,
    },
    {
      id: 'LN-2026-020',
      bookId: 'bk-115', // Operating System Concepts
      studentId: 'stu-2',
      issueDate: addDaysToTodayISO(-9),
      dueDate: addDaysToTodayISO(5),
      returnDate: addDaysToTodayISO(0),
      status: 'returned',
      finePaid: 0,
    },
  ];

  // Derive availableCopies strictly from totalCopies - activeLoans
  const activeCountByBook: Record<string, number> = {};
  for (const loan of loans) {
    if (loan.status === 'active') {
      activeCountByBook[loan.bookId] = (activeCountByBook[loan.bookId] || 0) + 1;
    }
  }

  const books: Book[] = baseBooks.map((book) => ({
    ...book,
    availableCopies: Math.max(0, book.totalCopies - (activeCountByBook[book.id] || 0)),
  }));

  const wishlists: WishlistMap = {
    'stu-1': ['bk-107', 'bk-110', 'bk-116'],
    'stu-2': ['bk-118', 'bk-114'],
    'stu-3': ['bk-103', 'bk-105'],
    'stu-5': ['bk-112'],
  };

  const nowIso = new Date().toISOString();
  const notifications: NotificationItem[] = [
    {
      id: 'ntf-seed-1',
      recipientId: 'admin',
      type: 'overdue',
      title: 'Overdue Loan Alert',
      message: 'Deep Learning (borrowed by Maya Patel) is 4 days overdue.',
      createdAt: new Date(Date.now() - 2 * 3600 * 1000).toISOString(),
      read: false,
      relatedLoanId: 'LN-2026-004',
    },
    {
      id: 'ntf-seed-2',
      recipientId: 'admin',
      type: 'overdue',
      title: 'Overdue Loan Alert',
      message: 'Artificial Intelligence (borrowed by Noah Takahashi) is 6 days overdue.',
      createdAt: new Date(Date.now() - 5 * 3600 * 1000).toISOString(),
      read: false,
      relatedLoanId: 'LN-2026-013',
    },
    {
      id: 'ntf-seed-3',
      recipientId: 'admin',
      type: 'issue',
      title: 'New Book Issued',
      message: `Systems Design & Scalability was issued to Lucas Lindqvist on ${today}.`,
      createdAt: new Date(Date.now() - 1 * 3600 * 1000).toISOString(),
      read: true,
      relatedLoanId: 'LN-2026-018',
    },
    {
      id: 'ntf-seed-4',
      recipientId: 'stu-1',
      type: 'due_soon',
      title: 'Book Due in 2 Days',
      message: 'Machine Learning is due soon. Please return or renew before the due date.',
      createdAt: new Date(Date.now() - 3 * 3600 * 1000).toISOString(),
      read: false,
      relatedLoanId: 'LN-2026-003',
    },
    {
      id: 'ntf-seed-5',
      recipientId: 'stu-1',
      type: 'overdue',
      title: 'Overdue Notice: Deep Learning',
      message: 'Deep Learning is 4 days past its due date. Current fine: ₹6.00.',
      createdAt: new Date(Date.now() - 6 * 3600 * 1000).toISOString(),
      read: false,
      relatedLoanId: 'LN-2026-004',
    },
    {
      id: 'ntf-seed-6',
      recipientId: 'stu-1',
      type: 'issue',
      title: 'Borrowing Confirmed',
      message: 'You borrowed Web Development. Enjoy your reading!',
      createdAt: new Date(Date.now() - 4 * 24 * 3600 * 1000).toISOString(),
      read: true,
      relatedLoanId: 'LN-2026-005',
    },
    {
      id: 'ntf-seed-7',
      recipientId: 'stu-1',
      type: 'return',
      title: 'Return Confirmed',
      message: 'Thank you for returning Introduction to Algorithms on time.',
      createdAt: nowIso,
      read: true,
      relatedLoanId: 'LN-2026-006',
    },
  ];

  return {
    books,
    students,
    admins,
    loans,
    notifications,
    settings: { ...DEFAULT_SETTINGS },
    wishlists,
    version: 1,
  };
}
