import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowRight,
  BookOpen,
  Check,
  Eye,
  EyeOff,
  GraduationCap,
  Library,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { FormField, inputBaseClass } from '../components/FormField';
import { Modal } from '../components/Modal';
import { LOGIN_HERO_IMAGE } from '../data/seedData';
import { useLibrary } from '../hooks/useLibrary';
import { storageService } from '../services/storageService';
import { Role } from '../types/library';

export const LoginPage: React.FC = () => {
  const { user, login, registerStudent, showToast } = useLibrary();
  const navigate = useNavigate();

  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [role, setRole] = useState<Role>('student');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(true);
  const [showPassword, setShowPassword] = useState(false);

  // Registration fields (Student only)
  const [fullName, setFullName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [studentId, setStudentId] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showRegPassword, setShowRegPassword] = useState(false);

  const [error, setError] = useState<string | null>(null);
  const [forgotOpen, setForgotOpen] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');

  useEffect(() => {
    if (user) {
      navigate('/dashboard', { replace: true });
    }
  }, [user, navigate]);

  useEffect(() => {
    const remembered = storageService.getRememberedLogin();
    if (remembered) {
      setEmail(remembered.email);
      setRole(remembered.role);
    }
  }, []);

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    const res = login({ email, password, role, rememberMe });
    if (!res.ok) {
      setError(res.error || 'Login failed.');
      return;
    }
    showToast({
      type: 'success',
      title: `Welcome back, ${res.data?.name}`,
      description:
        res.data?.role === 'admin'
          ? 'Signed in as Librarian / Admin'
          : `Signed in (${res.data?.studentId})`,
    });
    navigate('/dashboard', { replace: true });
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    const res = registerStudent({
      name: fullName,
      email: regEmail,
      studentId,
      password: regPassword,
      confirmPassword,
    });
    if (!res.ok) {
      setError(res.error || 'Registration failed.');
      return;
    }
    showToast({
      type: 'success',
      title: 'Account Created',
      description: `Welcome to Smart Library, ${res.data?.name}!`,
    });
    navigate('/dashboard', { replace: true });
  };

  const quickDemoSignIn = (demoRole: Role, demoEmail: string, demoPass: string) => {
    setError(null);
    const res = login({
      email: demoEmail,
      password: demoPass,
      role: demoRole,
      rememberMe: true,
    });
    if (res.ok) {
      showToast({
        type: 'success',
        title: `Signed in as ${res.data?.name}`,
        description:
          demoRole === 'admin'
            ? 'Admin / Librarian workspace'
            : `Student workspace (${res.data?.studentId})`,
      });
      navigate('/dashboard', { replace: true });
    }
  };

  const handleForgotSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!forgotEmail.trim()) return;
    setForgotOpen(false);
    showToast({
      type: 'info',
      title: 'Demo Password Reset',
      description: `For this local demo, use Student@2026 or Admin@2026 to sign in as ${forgotEmail}.`,
    });
    setForgotEmail('');
  };

  const passwordsMatch =
    confirmPassword.length > 0 && regPassword === confirmPassword;

  return (
    <div className="min-h-screen bg-[#F5F4FF] flex flex-col lg:flex-row">
      {/* Left Split Panel: Glowing Library Illustration & Brand */}
      <div className="relative lg:w-[48%] xl:w-[50%] bg-gradient-to-br from-[#0C102D] via-[#13194A] to-[#0C102D] text-white flex flex-col justify-between p-8 sm:p-12 overflow-hidden min-h-[400px] lg:min-h-screen">
        {/* Ambient Purple & Blue Orbs */}
        <motion.div
          animate={{ scale: [1, 1.08, 1], opacity: [0.35, 0.5, 0.35] }}
          transition={{ duration: 7, repeat: Infinity, ease: 'easeInOut' }}
          className="absolute -top-24 -left-24 w-96 h-96 rounded-full bg-[#713BFF]/30 blur-3xl pointer-events-none"
          aria-hidden="true"
        />
        <motion.div
          animate={{ scale: [1, 1.1, 1], opacity: [0.3, 0.45, 0.3] }}
          transition={{ duration: 8.5, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
          className="absolute -bottom-24 -right-24 w-[420px] h-[420px] rounded-full bg-[#4361EE]/30 blur-3xl pointer-events-none"
          aria-hidden="true"
        />

        {/* Subtle Top Brand */}
        <motion.div
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35 }}
          className="relative z-10 flex items-center gap-3"
        >
          <div className="w-10 h-10 rounded-xl bg-brand-gradient flex items-center justify-center shadow-lg shadow-[#713BFF]/35">
            <Library className="w-5 h-5 text-white" aria-hidden="true" />
          </div>
          <span className="font-display text-lg font-bold tracking-tight">Smart Library</span>
        </motion.div>

        {/* Centerpiece Illustration & Copy */}
        <div className="relative z-10 my-8 flex flex-col items-center text-center max-w-lg mx-auto">
          <div className="relative mb-8">
            {/* Soft Halo Behind Book Art */}
            <div
              className="absolute -inset-4 rounded-3xl bg-gradient-to-tr from-[#713BFF]/35 via-[#4361EE]/25 to-transparent blur-2xl pointer-events-none"
              aria-hidden="true"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.94 }}
              animate={{ opacity: 1, scale: 1, y: [0, -7, 0] }}
              transition={{
                opacity: { duration: 0.45 },
                scale: { duration: 0.45 },
                y: { duration: 5.5, repeat: Infinity, ease: 'easeInOut' },
              }}
              className="relative w-full max-w-[280px] sm:max-w-[330px] aspect-[3/4] rounded-2xl overflow-hidden border border-white/20 shadow-2xl shadow-[#713BFF]/30 bg-[#121740]"
            >
              <img
                src={LOGIN_HERO_IMAGE}
                alt="Glowing open book hovering above modern library shelves with violet and blue accents"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </motion.div>
          </div>

          <motion.h1
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.1 }}
            className="font-display text-2xl sm:text-3xl xl:text-4xl font-bold tracking-tight text-white [text-wrap:balance]"
          >
            Smart Library Management System
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.18 }}
            className="mt-3 text-base font-medium text-indigo-200 tracking-wide"
          >
            Read <span aria-hidden="true">•</span> Learn <span aria-hidden="true">•</span> Grow
          </motion.p>
        </div>

        <div className="relative z-10 flex flex-col sm:flex-row items-center justify-between gap-2 pt-6 border-t border-white/10 text-xs text-indigo-200/80">
          <p className="font-medium">Smarter Library. A Brighter Future.</p>
          <p>Local-Storage Demo Mode</p>
        </div>
      </div>

      {/* Right Split Panel: White Rounded Login / Registration Card */}
      <div className="flex-1 flex items-center justify-center p-5 sm:p-10 lg:p-14">
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
          className="w-full max-w-[470px] bg-white rounded-[20px] border border-indigo-100 shadow-xl shadow-[#0C102D]/6 p-7 sm:p-9"
        >
          <div className="flex items-center gap-3.5 mb-6">
            <div className="w-11 h-11 rounded-xl bg-brand-gradient flex items-center justify-center text-white shadow-md shadow-[#713BFF]/25 shrink-0">
              <BookOpen className="w-5 h-5" aria-hidden="true" />
            </div>
            <div>
              <h2 className="font-display text-xl sm:text-2xl font-bold text-[#0C102D]">
                {mode === 'login' ? 'Welcome Back!' : 'Create Student Account'}
              </h2>
              <p className="text-sm text-slate-500">
                {mode === 'login'
                  ? 'Login to access your account'
                  : 'Register with your student credentials'}
              </p>
            </div>
          </div>

          <AnimatePresence mode="wait">
            {error && (
              <motion.div
                key="auth-error"
                initial={{ opacity: 0, y: -6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                transition={{ duration: 0.16 }}
                role="alert"
                className="mb-5 p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-sm text-rose-700"
              >
                {error}
              </motion.div>
            )}
          </AnimatePresence>

          <AnimatePresence mode="wait">
            {mode === 'login' ? (
              <motion.form
                key="login-form"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
                onSubmit={handleLoginSubmit}
                className="space-y-4"
              >
                {/* Animated Role Selector */}
                <div>
                  <span className="block text-sm font-medium text-[#1F2442] mb-1.5">
                    Sign in as
                  </span>
                  <div
                    className="grid grid-cols-2 gap-1.5 p-1 bg-[#F5F4FF] rounded-xl border border-indigo-100"
                    role="tablist"
                    aria-label="Account role"
                  >
                    {(
                      [
                        { key: 'student', label: 'Student', icon: GraduationCap },
                        { key: 'admin', label: 'Admin / Librarian', icon: ShieldCheck },
                      ] as const
                    ).map((item) => {
                      const active = role === item.key;
                      const Icon = item.icon;
                      return (
                        <button
                          key={item.key}
                          type="button"
                          role="tab"
                          aria-selected={active}
                          onClick={() => {
                            setRole(item.key);
                            setError(null);
                          }}
                          className={`relative flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg text-sm font-semibold transition-colors ${
                            active ? 'text-white' : 'text-slate-600 hover:text-[#0C102D]'
                          }`}
                        >
                          {active && (
                            <motion.span
                              layoutId="login-role-pill"
                              transition={{ type: 'spring', stiffness: 450, damping: 32 }}
                              className="absolute inset-0 rounded-lg bg-brand-gradient shadow-sm"
                              aria-hidden="true"
                            />
                          )}
                          <Icon className="relative z-10 w-4 h-4 shrink-0" aria-hidden="true" />
                          <span className="relative z-10 whitespace-nowrap">{item.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <FormField id="login-email" label="Email Address" required>
                  <input
                    id="login-email"
                    type="email"
                    autoComplete="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder={
                      role === 'admin'
                        ? 'admin@smartlibrary.edu'
                        : 'maya.patel@smartlibrary.edu'
                    }
                    className={inputBaseClass}
                    required
                  />
                </FormField>

                <FormField id="login-password" label="Password" required>
                  <div className="relative">
                    <input
                      id="login-password"
                      type={showPassword ? 'text' : 'password'}
                      autoComplete="current-password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Enter your password"
                      className={`${inputBaseClass} pr-11`}
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword((s) => !s)}
                      aria-label={showPassword ? 'Hide password' : 'Show password'}
                      className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-700 rounded-lg"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </FormField>

                <div className="flex items-center justify-between gap-2 text-sm">
                  <label className="inline-flex items-center gap-2 text-slate-600 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={rememberMe}
                      onChange={(e) => setRememberMe(e.target.checked)}
                      className="w-4 h-4 rounded border-slate-300 text-[#713BFF] focus:ring-[#713BFF]"
                    />
                    <span>Remember me</span>
                  </label>

                  <button
                    type="button"
                    onClick={() => {
                      setForgotEmail(email);
                      setForgotOpen(true);
                    }}
                    className="text-sm font-medium text-[#713BFF] hover:text-[#4361EE] transition-colors"
                  >
                    Forgot password?
                  </button>
                </div>

                <motion.button
                  type="submit"
                  whileTap={{ scale: 0.99 }}
                  className="w-full py-3 px-4 rounded-xl text-sm font-semibold text-white bg-brand-gradient bg-brand-gradient-hover shadow-md shadow-[#713BFF]/20 transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#713BFF] focus-visible:ring-offset-2"
                >
                  Login
                </motion.button>

                <div className="text-center pt-1">
                  <span className="text-sm text-slate-500">New student? </span>
                  <button
                    type="button"
                    onClick={() => {
                      setMode('register');
                      setError(null);
                    }}
                    className="text-sm font-semibold text-[#713BFF] hover:text-[#4361EE] transition-colors"
                  >
                    Create New Account
                  </button>
                </div>
              </motion.form>
            ) : (
              <motion.form
                key="register-form"
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
                onSubmit={handleRegisterSubmit}
                className="space-y-3.5"
              >
                <div className="p-3 rounded-xl bg-[#F5F4FF] border border-indigo-100 text-xs text-slate-600">
                  Public registration creates <strong>Student</strong> accounts only. Librarian accounts are managed internally.
                </div>

                <FormField id="reg-name" label="Full Name" required>
                  <input
                    id="reg-name"
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="Alex Morgan"
                    className={inputBaseClass}
                    required
                  />
                </FormField>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <FormField id="reg-email" label="Email" required>
                    <input
                      id="reg-email"
                      type="email"
                      value={regEmail}
                      onChange={(e) => setRegEmail(e.target.value)}
                      placeholder="alex@smartlibrary.edu"
                      className={inputBaseClass}
                      required
                    />
                  </FormField>

                  <FormField id="reg-student-id" label="Student ID" required>
                    <input
                      id="reg-student-id"
                      type="text"
                      value={studentId}
                      onChange={(e) => setStudentId(e.target.value)}
                      placeholder="STU-2026-210"
                      className={`${inputBaseClass} font-mono uppercase`}
                      required
                    />
                  </FormField>
                </div>

                <FormField id="reg-password" label="Password" required helperText="Minimum 6 characters">
                  <div className="relative">
                    <input
                      id="reg-password"
                      type={showRegPassword ? 'text' : 'password'}
                      value={regPassword}
                      onChange={(e) => setRegPassword(e.target.value)}
                      placeholder="Create a password"
                      className={`${inputBaseClass} pr-11`}
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowRegPassword((s) => !s)}
                      aria-label={showRegPassword ? 'Hide password' : 'Show password'}
                      className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-700 rounded-lg"
                    >
                      {showRegPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </FormField>

                <FormField
                  id="reg-confirm-password"
                  label="Confirm Password"
                  required
                  error={
                    confirmPassword.length > 0 && !passwordsMatch
                      ? 'Passwords do not match'
                      : undefined
                  }
                >
                  <div className="relative">
                    <input
                      id="reg-confirm-password"
                      type={showRegPassword ? 'text' : 'password'}
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="Re-enter your password"
                      className={`${inputBaseClass} pr-10`}
                      required
                    />
                    {passwordsMatch && (
                      <Check className="w-4 h-4 text-emerald-600 absolute right-3.5 top-1/2 -translate-y-1/2" />
                    )}
                  </div>
                </FormField>

                <motion.button
                  type="submit"
                  whileTap={{ scale: 0.99 }}
                  className="w-full py-3 px-4 rounded-xl text-sm font-semibold text-white bg-brand-gradient bg-brand-gradient-hover shadow-md shadow-[#713BFF]/20 transition-all"
                >
                  Create Student Account
                </motion.button>

                <div className="text-center pt-1">
                  <span className="text-sm text-slate-500">Already have an account? </span>
                  <button
                    type="button"
                    onClick={() => {
                      setMode('login');
                      setError(null);
                    }}
                    className="text-sm font-semibold text-[#713BFF] hover:text-[#4361EE] transition-colors"
                  >
                    Back to Login
                  </button>
                </div>
              </motion.form>
            )}
          </AnimatePresence>

          {/* 1-Click Instant Demo Accounts */}
          <div className="mt-7 pt-5 border-t border-slate-100">
            <div className="flex items-center justify-between gap-2 mb-3">
              <span className="text-xs font-semibold text-[#0C102D] inline-flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-[#713BFF]" aria-hidden="true" />
                Instant 1-Click Demo Sign-In
              </span>
              <span className="text-[11px] text-slate-400">Local storage demo</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <motion.button
                type="button"
                whileHover={{ y: -2 }}
                whileTap={{ scale: 0.98 }}
                onClick={() =>
                  quickDemoSignIn('admin', 'admin@smartlibrary.edu', 'Admin@2026')
                }
                className="group text-left p-3 rounded-xl border border-indigo-100 bg-[#FAF9FF] hover:border-[#713BFF]/50 hover:bg-[#F5F4FF] transition-colors flex items-center justify-between gap-2"
              >
                <div className="min-w-0">
                  <p className="text-xs font-bold text-[#0C102D]">Admin / Librarian</p>
                  <p className="text-[11px] text-slate-500 truncate mt-0.5">
                    admin@smartlibrary.edu
                  </p>
                  <p className="text-[11px] font-mono text-[#713BFF] mt-0.5">Admin@2026</p>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-[#713BFF] group-hover:translate-x-0.5 transition-all shrink-0" />
              </motion.button>

              <motion.button
                type="button"
                whileHover={{ y: -2 }}
                whileTap={{ scale: 0.98 }}
                onClick={() =>
                  quickDemoSignIn('student', 'maya.patel@smartlibrary.edu', 'Student@2026')
                }
                className="group text-left p-3 rounded-xl border border-indigo-100 bg-[#FAF9FF] hover:border-[#4361EE]/50 hover:bg-[#F5F4FF] transition-colors flex items-center justify-between gap-2"
              >
                <div className="min-w-0">
                  <p className="text-xs font-bold text-[#0C102D]">Student (Maya)</p>
                  <p className="text-[11px] text-slate-500 truncate mt-0.5">
                    maya.patel@smartlibrary.edu
                  </p>
                  <p className="text-[11px] font-mono text-[#4361EE] mt-0.5">Student@2026</p>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-[#4361EE] group-hover:translate-x-0.5 transition-all shrink-0" />
              </motion.button>
            </div>

            <button
              type="button"
              onClick={() =>
                quickDemoSignIn('student', 'liam.okafor@smartlibrary.edu', 'Student@2026')
              }
              className="mt-2.5 w-full text-center py-2 px-3 rounded-xl border border-dashed border-indigo-200 text-xs font-medium text-slate-600 hover:text-[#713BFF] hover:border-[#713BFF]/40 hover:bg-[#FAF9FF] transition-colors"
            >
              Or try New Student (Liam Okafor — zero borrowing history) →
            </button>

            <p className="mt-3 text-[11px] text-slate-400 leading-relaxed">
              Note: Authentication uses browser local storage for demonstration only and does not provide production security.
            </p>
          </div>
        </motion.div>
      </div>

      {/* Forgot Password Demo Dialog */}
      <Modal
        isOpen={forgotOpen}
        onClose={() => setForgotOpen(false)}
        title="Password Recovery (Demo)"
        subtitle="In production, this sends a secure reset link via your backend."
        size="sm"
        footer={
          <>
            <button
              type="button"
              onClick={() => setForgotOpen(false)}
              className="px-4 py-2 rounded-xl text-sm font-medium text-slate-700 border border-slate-200 hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              form="forgot-form"
              className="px-4 py-2 rounded-xl text-sm font-semibold text-white bg-brand-gradient"
            >
              View Demo Hint
            </button>
          </>
        }
      >
        <form id="forgot-form" onSubmit={handleForgotSubmit} className="space-y-4">
          <FormField id="forgot-email" label="Account Email" required>
            <input
              id="forgot-email"
              type="email"
              value={forgotEmail}
              onChange={(e) => setForgotEmail(e.target.value)}
              placeholder="you@smartlibrary.edu"
              className={inputBaseClass}
              required
            />
          </FormField>
        </form>
      </Modal>
    </div>
  );
};
