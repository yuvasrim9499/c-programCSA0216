import React, { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  AlertCircle,
  ArrowRight,
  BookMarked,
  BookOpen,
  CheckCircle2,
  Heart,
  Sparkles,
} from 'lucide-react';
import { BookCard } from '../components/BookCard';
import { ColumnDef, DataTable } from '../components/DataTable';
import { EmptyState } from '../components/EmptyState';
import {
  AnimatedSection,
  StaggerGrid,
  StaggerItem,
} from '../components/MotionPrimitives';
import { StatCard } from '../components/StatCard';
import { StatusBadge } from '../components/StatusBadge';
import { useLibrary } from '../hooks/useLibrary';
import { computeLoanMetrics } from '../services/loanService';
import { recommendationService } from '../services/recommendationService';
import { formatDisplayDate, getTodayISO } from '../utils/dateUtils';

interface StudentLoanRow {
  id: string;
  bookId: string;
  title: string;
  author: string;
  issueDate: string;
  dueDate: string;
  status: ReturnType<typeof computeLoanMetrics>['derivedStatus'];
  daysInfo: string;
}

export const StudentDashboard: React.FC = () => {
  const {
    currentStudent,
    books,
    loans,
    settings,
    currentUserWishlist,
    toggleWishlist,
  } = useLibrary();
  const navigate = useNavigate();
  const today = getTodayISO();

  const myLoans = useMemo(() => {
    if (!currentStudent) return [];
    return loans.filter((l) => l.studentId === currentStudent.id);
  }, [currentStudent, loans]);

  const activeLoans = useMemo(
    () => myLoans.filter((l) => l.status === 'active'),
    [myLoans]
  );

  const returnedLoansCount = useMemo(
    () => myLoans.filter((l) => l.status === 'returned').length,
    [myLoans]
  );

  const attentionCount = useMemo(() => {
    return activeLoans.filter((l) => {
      const m = computeLoanMetrics(l, settings, today);
      return m.derivedStatus === 'Overdue' || m.derivedStatus === 'Due Soon';
    }).length;
  }, [activeLoans, settings, today]);

  const thisMonthBorrowed = useMemo(() => {
    const monthPrefix = today.slice(0, 7);
    return myLoans.filter((l) => l.issueDate.startsWith(monthPrefix)).length;
  }, [myLoans, today]);

  const monthlyGoal = currentStudent?.monthlyGoal || 3;
  const goalPct = Math.min(100, Math.round((thisMonthBorrowed / monthlyGoal) * 100));

  const bookMap = useMemo(() => new Map(books.map((b) => [b.id, b])), [books]);

  const currentLoanRows: StudentLoanRow[] = useMemo(() => {
    return activeLoans.map((loan) => {
      const book = bookMap.get(loan.bookId);
      const metrics = computeLoanMetrics(loan, settings, today);
      const daysInfo =
        metrics.derivedStatus === 'Overdue'
          ? `${metrics.daysOverdue}d overdue (${settings.currencySymbol}${metrics.calculatedFine.toFixed(2)})`
          : metrics.daysRemaining === 0
          ? 'Due today'
          : `${metrics.daysRemaining}d remaining`;

      return {
        id: loan.id,
        bookId: loan.bookId,
        title: book?.title ?? 'Unknown Book',
        author: book?.author ?? '',
        issueDate: loan.issueDate,
        dueDate: loan.dueDate,
        status: metrics.derivedStatus,
        daysInfo,
      };
    });
  }, [activeLoans, bookMap, settings, today]);

  const recommendations = useMemo(
    () =>
      recommendationService.getRecommendationsForStudent(
        currentStudent,
        books,
        loans,
        currentUserWishlist,
        4
      ),
    [books, currentStudent, currentUserWishlist, loans]
  );

  const columns: ColumnDef<StudentLoanRow>[] = [
    {
      key: 'title',
      header: 'Book',
      render: (row) => (
        <button
          type="button"
          onClick={() => navigate(`/books/${row.bookId}`)}
          className="text-left hover:text-[#713BFF] transition-colors"
        >
          <p className="font-semibold text-[#0C102D]">{row.title}</p>
          <p className="text-xs text-slate-500">{row.author}</p>
        </button>
      ),
    },
    {
      key: 'issueDate',
      header: 'Issued',
      render: (row) => (
        <span className="tabular-nums text-slate-600">{formatDisplayDate(row.issueDate)}</span>
      ),
    },
    {
      key: 'dueDate',
      header: 'Due Date',
      render: (row) => (
        <span className="tabular-nums text-slate-600">{formatDisplayDate(row.dueDate)}</span>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      render: (row) => <StatusBadge status={row.status} />,
    },
    {
      key: 'timeline',
      header: 'Timeline',
      align: 'right',
      render: (row) => (
        <span
          className={`text-xs font-medium tabular-nums ${
            row.status === 'Overdue'
              ? 'text-rose-600'
              : row.status === 'Due Soon'
              ? 'text-amber-700'
              : 'text-slate-600'
          }`}
        >
          {row.daysInfo}
        </span>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-[#0C102D] tracking-tight">
            Welcome back, {currentStudent?.name.split(' ')[0] || 'Reader'}
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Track your active loans, reading progress, and personalized book picks.
          </p>
        </div>

        <button
          type="button"
          onClick={() => navigate('/books')}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold text-white bg-brand-gradient bg-brand-gradient-hover shadow-md shadow-[#713BFF]/20 transition-all self-start sm:self-auto whitespace-nowrap"
        >
          <BookOpen className="w-4 h-4" aria-hidden="true" />
          <span>Browse Catalog</span>
        </button>
      </div>

      {/* Summary Cards */}
      <section aria-label="Student reading metrics">
        <StaggerGrid className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
          <StaggerItem>
            <StatCard
              title="Current Loans"
              value={activeLoans.length}
              description={`Limit: ${settings.maxActiveLoansPerStudent} active books`}
              icon={BookMarked}
              accent="purple"
              onClick={() => navigate('/my-loans')}
            />
          </StaggerItem>
          <StaggerItem>
            <StatCard
              title="Due Soon / Overdue"
              value={attentionCount}
              description={
                attentionCount > 0
                  ? 'Check due dates to avoid late fines'
                  : 'All borrowed books are on schedule'
              }
              icon={AlertCircle}
              accent={attentionCount > 0 ? 'amber' : 'emerald'}
              onClick={() => navigate('/my-loans')}
            />
          </StaggerItem>
          <StaggerItem>
            <StatCard
              title="Books Returned"
              value={returnedLoansCount}
              description="Completed reading history"
              icon={CheckCircle2}
              accent="blue"
              onClick={() => navigate('/profile')}
            />
          </StaggerItem>
          <StaggerItem>
            <StatCard
              title="Saved Wishlist"
              value={currentUserWishlist.length}
              description="Books bookmarked for later"
              icon={Heart}
              accent="rose"
              onClick={() => navigate('/wishlist')}
            />
          </StaggerItem>
        </StaggerGrid>
      </section>

      {/* Monthly Reading Goal + Current Loans */}
      <AnimatedSection delay={0.05} className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <section className="card-surface p-5 sm:p-6 flex flex-col justify-between bg-gradient-to-br from-white to-[#F7F5FF]">
          <div>
            <div className="flex items-center justify-between gap-2">
              <h2 className="font-display text-lg font-bold text-[#0C102D]">
                Monthly Reading Goal
              </h2>
              <span className="text-xs font-semibold text-[#713BFF] tabular-nums">
                {goalPct}%
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Books borrowed this month toward your personal target
            </p>

            <div className="mt-6">
              <div className="flex items-baseline justify-between mb-2">
                <span className="font-display text-3xl font-bold text-[#0C102D] tabular-nums">
                  {thisMonthBorrowed}
                  <span className="text-base font-medium text-slate-400">
                    {' '}
                    / {monthlyGoal} books
                  </span>
                </span>
              </div>
              <div className="w-full h-3 rounded-full bg-indigo-100 overflow-hidden">
                <div
                  className="h-full rounded-full bg-brand-gradient transition-all duration-300"
                  style={{ width: `${goalPct}%` }}
                />
              </div>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-indigo-100 flex items-center justify-between">
            <span className="text-xs text-slate-500">Adjust target in profile</span>
            <button
              type="button"
              onClick={() => navigate('/profile')}
              className="text-xs font-semibold text-[#713BFF] hover:text-[#4361EE] inline-flex items-center gap-1"
            >
              <span>My Profile</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </section>

        <section className="xl:col-span-2 card-surface overflow-hidden">
          <div className="px-5 sm:px-6 py-4 border-b border-slate-100 flex items-center justify-between gap-2">
            <div>
              <h2 className="font-display text-lg font-bold text-[#0C102D]">Current Loans</h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Books currently checked out to your student ID
              </p>
            </div>
            <button
              type="button"
              onClick={() => navigate('/my-loans')}
              className="text-xs font-semibold text-[#713BFF] hover:text-[#4361EE] inline-flex items-center gap-1 whitespace-nowrap"
            >
              <span>View All Loans</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <DataTable
            columns={columns}
            data={currentLoanRows}
            rowKey={(r) => r.id}
            emptyState={
              <div className="p-6">
                <EmptyState
                  icon={BookMarked}
                  title="No active loans"
                  description="You currently have no checked-out books. Browse the catalog to discover your next read."
                  actionLabel="Browse Books"
                  onAction={() => navigate('/books')}
                />
              </div>
            }
          />
        </section>
      </AnimatedSection>

      {/* Personalized Recommendations Preview */}
      <AnimatedSection delay={0.08} className="space-y-4">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-brand-gradient text-white flex items-center justify-center shrink-0">
              <Sparkles className="w-4 h-4" aria-hidden="true" />
            </div>
            <div>
              <h2 className="font-display text-lg font-bold text-[#0C102D]">
                Recommended For You
              </h2>
              <p className="text-xs text-slate-500">
                Rule-based picks from your borrowing history and interests
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => navigate('/recommendations')}
            className="text-xs font-semibold text-[#713BFF] hover:text-[#4361EE] inline-flex items-center gap-1 whitespace-nowrap"
          >
            <span>See All</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <StaggerGrid className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {recommendations.map((rec) => (
            <StaggerItem key={rec.book.id}>
              <BookCard
                book={rec.book}
                isStudent
                isWishlisted={currentUserWishlist.includes(rec.book.id)}
                onToggleWishlist={toggleWishlist}
                onViewDetails={(b) => navigate(`/books/${b.id}`)}
                recommendationReason={rec.reason}
              />
            </StaggerItem>
          ))}
        </StaggerGrid>
      </AnimatedSection>
    </div>
  );
};
