import React, { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  ArrowLeftRight,
  BookCheck,
  BookOpen,
  CheckCircle2,
  Search,
  UserCheck,
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { BookCover } from '../components/BookCover';
import { ConfirmDialog } from '../components/ConfirmDialog';
import { ColumnDef, DataTable } from '../components/DataTable';
import { EmptyState } from '../components/EmptyState';
import { FormField, inputBaseClass } from '../components/FormField';
import {
  AnimatedSection,
  EASE_SMOOTH,
  TabPanelPresence,
} from '../components/MotionPrimitives';
import { StatusBadge } from '../components/StatusBadge';
import { useLibrary } from '../hooks/useLibrary';
import { computeLoanMetrics } from '../services/loanService';
import { addDaysISO, formatDisplayDate, getTodayISO } from '../utils/dateUtils';

interface RecentIssueRow {
  id: string;
  studentName: string;
  studentCode: string;
  bookTitle: string;
  issueDate: string;
  dueDate: string;
  status: ReturnType<typeof computeLoanMetrics>['derivedStatus'];
  fine: number;
  isActive: boolean;
}

export const IssueReturnPage: React.FC = () => {
  const {
    students,
    books,
    loans,
    settings,
    issueBook,
    returnBook,
    showToast,
  } = useLibrary();
  const [searchParams, setSearchParams] = useSearchParams();

  const initialTab = searchParams.get('tab') === 'return' ? 'return' : 'issue';
  const [activeTab, setActiveTab] = useState<'issue' | 'return'>(initialTab);

  // Issue Book State
  const [studentSearch, setStudentSearch] = useState('');
  const [selectedStudentId, setSelectedStudentId] = useState('');
  const [bookSearch, setBookSearch] = useState('');
  const [selectedBookId, setSelectedBookId] = useState(searchParams.get('bookId') || '');
  const [issueDate, setIssueDate] = useState(getTodayISO());
  const [dueDate, setDueDate] = useState(
    addDaysISO(getTodayISO(), settings.defaultLoanDays)
  );
  const [issueNotes, setIssueNotes] = useState('');
  const [issueError, setIssueError] = useState<string | null>(null);

  // Return Book State
  const [loanSearch, setLoanSearch] = useState(searchParams.get('loanId') || '');
  const [selectedLoanId, setSelectedLoanId] = useState(searchParams.get('loanId') || '');
  const [returnConfirmOpen, setReturnConfirmOpen] = useState(false);

  const today = getTodayISO();
  const bookMap = useMemo(() => new Map(books.map((b) => [b.id, b])), [books]);
  const studentMap = useMemo(() => new Map(students.map((s) => [s.id, s])), [students]);

  useEffect(() => {
    const tabParam = searchParams.get('tab');
    const loanParam = searchParams.get('loanId');
    const bookParam = searchParams.get('bookId');
    if (tabParam === 'return') setActiveTab('return');
    if (loanParam) {
      setSelectedLoanId(loanParam);
      setLoanSearch(loanParam);
    }
    if (bookParam) {
      setSelectedBookId(bookParam);
    }
  }, [searchParams]);

  // Keep default due date synced when issueDate changes
  const handleIssueDateChange = (nextDate: string) => {
    setIssueDate(nextDate);
    if (nextDate) {
      setDueDate(addDaysISO(nextDate, settings.defaultLoanDays));
    }
  };

  const filteredStudents = useMemo(() => {
    const q = studentSearch.trim().toLowerCase();
    return students.filter((s) => {
      if (!q) return true;
      return (
        s.name.toLowerCase().includes(q) ||
        s.studentId.toLowerCase().includes(q) ||
        s.email.toLowerCase().includes(q)
      );
    });
  }, [studentSearch, students]);

  const filteredBooks = useMemo(() => {
    const q = bookSearch.trim().toLowerCase();
    return books.filter((b) => {
      if (!q) return true;
      return (
        b.title.toLowerCase().includes(q) ||
        b.author.toLowerCase().includes(q) ||
        b.isbn.toLowerCase().includes(q)
      );
    });
  }, [bookSearch, books]);

  const selectedStudent = studentMap.get(selectedStudentId);
  const selectedBook = bookMap.get(selectedBookId);

  const selectedStudentActiveLoans = useMemo(() => {
    if (!selectedStudent) return [];
    return loans.filter((l) => l.studentId === selectedStudent.id && l.status === 'active');
  }, [loans, selectedStudent]);

  const selectedStudentFine = useMemo(() => {
    return selectedStudentActiveLoans.reduce(
      (sum, l) => sum + computeLoanMetrics(l, settings, today).calculatedFine,
      0
    );
  }, [selectedStudentActiveLoans, settings, today]);

  const activeLoanList = useMemo(() => {
    const q = loanSearch.trim().toLowerCase();
    return loans
      .filter((l) => l.status === 'active')
      .map((loan) => {
        const student = studentMap.get(loan.studentId);
        const book = bookMap.get(loan.bookId);
        const metrics = computeLoanMetrics(loan, settings, today);
        return { loan, student, book, metrics };
      })
      .filter(({ loan, student, book }) => {
        if (!q) return true;
        return (
          loan.id.toLowerCase().includes(q) ||
          (student?.name.toLowerCase().includes(q) ?? false) ||
          (student?.studentId.toLowerCase().includes(q) ?? false) ||
          (book?.title.toLowerCase().includes(q) ?? false) ||
          (book?.isbn.toLowerCase().includes(q) ?? false)
        );
      });
  }, [bookMap, loanSearch, loans, settings, studentMap, today]);

  const selectedReturnItem = useMemo(
    () => activeLoanList.find((item) => item.loan.id === selectedLoanId),
    [activeLoanList, selectedLoanId]
  );

  const handleIssueSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIssueError(null);
    if (!selectedStudentId) {
      setIssueError('Please select a student.');
      return;
    }
    if (!selectedBookId) {
      setIssueError('Please select an available book.');
      return;
    }

    const res = issueBook({
      studentId: selectedStudentId,
      bookId: selectedBookId,
      issueDate,
      dueDate,
      notes: issueNotes,
    });

    if (!res.ok) {
      setIssueError(res.error || 'Could not issue book.');
      showToast({ type: 'error', title: 'Issue Blocked', description: res.error });
      return;
    }

    showToast({
      type: 'success',
      title: 'Book Issued Successfully',
      description: `"${selectedBook?.title}" issued to ${selectedStudent?.name}.`,
    });
    setSelectedBookId('');
    setIssueNotes('');
  };

  const handleConfirmReturn = () => {
    if (!selectedReturnItem) return;
    const res = returnBook(selectedReturnItem.loan.id, today);
    if (!res.ok) {
      showToast({ type: 'error', title: 'Return Failed', description: res.error });
      return;
    }
    showToast({
      type: 'success',
      title: 'Book Returned',
      description: `"${selectedReturnItem.book?.title}" has been returned to inventory.`,
    });
    setSelectedLoanId('');
    setLoanSearch('');
  };

  const recentIssuesRows: RecentIssueRow[] = useMemo(() => {
    return [...loans]
      .sort((a, b) => b.issueDate.localeCompare(a.issueDate))
      .slice(0, 8)
      .map((loan) => {
        const student = studentMap.get(loan.studentId);
        const book = bookMap.get(loan.bookId);
        const metrics = computeLoanMetrics(loan, settings, today);
        return {
          id: loan.id,
          studentName: student?.name ?? 'Unknown',
          studentCode: student?.studentId ?? '—',
          bookTitle: book?.title ?? 'Unknown Book',
          issueDate: loan.issueDate,
          dueDate: loan.dueDate,
          status: metrics.derivedStatus,
          fine: metrics.calculatedFine,
          isActive: loan.status === 'active',
        };
      });
  }, [bookMap, loans, settings, studentMap, today]);

  const recentColumns: ColumnDef<RecentIssueRow>[] = [
    {
      key: 'student',
      header: 'Student',
      colTrack: 'minmax(0, 1.3fr)',
      render: (r) => (
        <div className="min-w-0">
          <p className="font-semibold text-[#0C102D] truncate">{r.studentName}</p>
          <p className="text-xs font-mono text-slate-400">{r.studentCode}</p>
        </div>
      ),
    },
    {
      key: 'book',
      header: 'Book',
      colTrack: 'minmax(0, 1.5fr)',
      render: (r) => <span className="font-medium text-[#1F2442] line-clamp-1">{r.bookTitle}</span>,
    },
    {
      key: 'issueDate',
      header: 'Issue Date',
      colTrack: 'minmax(0, 0.85fr)',
      render: (r) => (
        <span className="tabular-nums text-slate-600 whitespace-nowrap">
          {formatDisplayDate(r.issueDate)}
        </span>
      ),
    },
    {
      key: 'dueDate',
      header: 'Due Date',
      colTrack: 'minmax(0, 0.85fr)',
      render: (r) => (
        <span className="tabular-nums text-slate-600 whitespace-nowrap">
          {formatDisplayDate(r.dueDate)}
        </span>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      colTrack: 'minmax(0, 0.85fr)',
      render: (r) => <StatusBadge status={r.status} />,
    },
    {
      key: 'actions',
      header: 'Actions',
      align: 'right',
      colTrack: 'minmax(0, 0.9fr)',
      render: (r) =>
        r.isActive ? (
          <button
            type="button"
            onClick={() => {
              setActiveTab('return');
              setSelectedLoanId(r.id);
              setLoanSearch(r.id);
              setSearchParams({ tab: 'return', loanId: r.id });
            }}
            className="px-3 py-1.5 rounded-lg text-xs font-semibold text-[#713BFF] bg-[#F5F4FF] hover:bg-[#ECE9FF] transition-colors whitespace-nowrap"
          >
            Return Book
          </button>
        ) : (
          <span className="text-xs text-slate-400">Completed</span>
        ),
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-[#0C102D] tracking-tight">
            Issue & Return Circulation
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Default loan duration: <strong className="text-[#0C102D]">{settings.defaultLoanDays} days</strong> · Daily overdue fine:{' '}
            <strong className="text-[#0C102D] tabular-nums">
              {settings.currencySymbol}
              {settings.dailyOverdueFine.toFixed(2)}/day
            </strong>
          </p>
        </div>

        {/* Two Tabs */}
        <div
          className="inline-flex items-center p-1 bg-white rounded-xl border border-indigo-100 shadow-xs self-start"
          role="tablist"
          aria-label="Circulation mode"
        >
          <button
            type="button"
            role="tab"
            aria-selected={activeTab === 'issue'}
            onClick={() => {
              setActiveTab('issue');
              setSearchParams({});
            }}
            className={`relative inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-colors ${
              activeTab === 'issue'
                ? 'text-white'
                : 'text-slate-600 hover:text-[#0C102D]'
            }`}
          >
            {activeTab === 'issue' && (
              <motion.span
                layoutId="circulation-tab-pill"
                transition={{ type: 'spring', stiffness: 450, damping: 32 }}
                className="absolute inset-0 rounded-lg bg-brand-gradient shadow-sm"
                aria-hidden="true"
              />
            )}
            <ArrowLeftRight className="relative z-10 w-4 h-4" />
            <span className="relative z-10">Issue Book</span>
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={activeTab === 'return'}
            onClick={() => {
              setActiveTab('return');
              setSearchParams({ tab: 'return' });
            }}
            className={`relative inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-colors ${
              activeTab === 'return'
                ? 'text-white'
                : 'text-slate-600 hover:text-[#0C102D]'
            }`}
          >
            {activeTab === 'return' && (
              <motion.span
                layoutId="circulation-tab-pill"
                transition={{ type: 'spring', stiffness: 450, damping: 32 }}
                className="absolute inset-0 rounded-lg bg-brand-gradient shadow-sm"
                aria-hidden="true"
              />
            )}
            <BookCheck className="relative z-10 w-4 h-4" />
            <span className="relative z-10">Return Book</span>
          </button>
        </div>
      </div>

      <TabPanelPresence tabKey={activeTab}>
        {activeTab === 'issue' ? (
        <form onSubmit={handleIssueSubmit} className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Student + Book Selection */}
          <div className="lg:col-span-7 space-y-6">
            <div className="card-surface p-5 sm:p-6 space-y-4">
              <div className="flex items-center gap-2">
                <UserCheck className="w-5 h-5 text-[#713BFF]" />
                <h2 className="font-display text-lg font-bold text-[#0C102D]">
                  1. Select Student
                </h2>
              </div>

              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <label htmlFor="issue-student-search" className="sr-only">
                  Search student
                </label>
                <input
                  id="issue-student-search"
                  type="search"
                  value={studentSearch}
                  onChange={(e) => setStudentSearch(e.target.value)}
                  placeholder="Search student by name, ID, or email..."
                  className={`${inputBaseClass} pl-10`}
                />
              </div>

              <FormField id="issue-student-select" label="Student Account" required>
                <select
                  id="issue-student-select"
                  value={selectedStudentId}
                  onChange={(e) => setSelectedStudentId(e.target.value)}
                  className={inputBaseClass}
                  required
                >
                  <option value="">-- Choose a student --</option>
                  {filteredStudents.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.studentId} — {s.name} ({s.status})
                    </option>
                  ))}
                </select>
              </FormField>

              {selectedStudent && (
                <div className="p-4 rounded-xl bg-[#FAF9FF] border border-indigo-100 flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <p className="text-sm font-semibold text-[#0C102D]">
                      {selectedStudent.name}{' '}
                      <span className="font-mono text-xs text-[#713BFF]">
                        ({selectedStudent.studentId})
                      </span>
                    </p>
                    <p className="text-xs text-slate-500 mt-0.5">
                      {selectedStudent.department} · Active loans:{' '}
                      <strong className="text-[#0C102D] tabular-nums">
                        {selectedStudentActiveLoans.length} / {settings.maxActiveLoansPerStudent}
                      </strong>
                      {selectedStudentFine > 0 && (
                        <span className="text-rose-600 font-semibold ml-2 tabular-nums">
                          · Outstanding Fine: {settings.currencySymbol}
                          {selectedStudentFine.toFixed(2)}
                        </span>
                      )}
                    </p>
                  </div>
                  <StatusBadge
                    status={selectedStudent.status === 'active' ? 'Active' : 'Inactive'}
                  />
                </div>
              )}
            </div>

            <div className="card-surface p-5 sm:p-6 space-y-4">
              <div className="flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-[#4361EE]" />
                <h2 className="font-display text-lg font-bold text-[#0C102D]">
                  2. Select Book
                </h2>
              </div>

              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <label htmlFor="issue-book-search" className="sr-only">
                  Search book
                </label>
                <input
                  id="issue-book-search"
                  type="search"
                  value={bookSearch}
                  onChange={(e) => setBookSearch(e.target.value)}
                  placeholder="Search book by title, author, or ISBN..."
                  className={`${inputBaseClass} pl-10`}
                />
              </div>

              <FormField id="issue-book-select" label="Catalog Title" required>
                <select
                  id="issue-book-select"
                  value={selectedBookId}
                  onChange={(e) => setSelectedBookId(e.target.value)}
                  className={inputBaseClass}
                  required
                >
                  <option value="">-- Choose a book --</option>
                  {filteredBooks.map((b) => (
                    <option key={b.id} value={b.id} disabled={b.availableCopies <= 0}>
                      {b.title} — {b.author} ({b.availableCopies}/{b.totalCopies} available)
                    </option>
                  ))}
                </select>
              </FormField>

              {selectedBook && (
                <div className="p-4 rounded-xl bg-[#FAF9FF] border border-indigo-100 flex items-center gap-4">
                  <div className="w-14 h-20 rounded-lg overflow-hidden shrink-0 border border-slate-200">
                    <BookCover
                      src={selectedBook.coverUrl}
                      title={selectedBook.title}
                      category={selectedBook.category}
                      className="w-full h-full"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-[#0C102D] truncate">
                      {selectedBook.title}
                    </p>
                    <p className="text-xs text-slate-500 truncate">
                      {selectedBook.author} · Shelf {selectedBook.shelfLocation}
                    </p>
                    <p className="text-xs font-mono text-slate-400 mt-1">
                      ISBN: {selectedBook.isbn}
                    </p>
                  </div>
                  <StatusBadge
                    status={selectedBook.availableCopies > 0 ? 'Available' : 'Unavailable'}
                  />
                </div>
              )}
            </div>
          </div>

          {/* Dates & Confirmation Summary */}
          <div className="lg:col-span-5">
            <div className="card-surface p-5 sm:p-6 space-y-4 sticky top-24">
              <h2 className="font-display text-lg font-bold text-[#0C102D]">
                3. Loan Dates & Issue
              </h2>

              {issueError && (
                <div
                  role="alert"
                  className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-sm text-rose-700"
                >
                  {issueError}
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <FormField id="issue-date" label="Issue Date" required>
                  <input
                    id="issue-date"
                    type="date"
                    value={issueDate}
                    onChange={(e) => handleIssueDateChange(e.target.value)}
                    className={`${inputBaseClass} tabular-nums`}
                    required
                  />
                </FormField>

                <FormField id="due-date" label="Due Date" required>
                  <input
                    id="due-date"
                    type="date"
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className={`${inputBaseClass} tabular-nums`}
                    required
                  />
                </FormField>
              </div>

              <FormField id="issue-notes" label="Circulation Notes (Optional)">
                <textarea
                  id="issue-notes"
                  rows={2}
                  value={issueNotes}
                  onChange={(e) => setIssueNotes(e.target.value)}
                  placeholder="Condition notes or special instructions..."
                  className={inputBaseClass}
                />
              </FormField>

              <div className="p-4 rounded-xl bg-[#F5F4FF] border border-indigo-100 space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-500">Borrower</span>
                  <span className="font-semibold text-[#0C102D]">
                    {selectedStudent?.name || 'Not selected'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Book</span>
                  <span className="font-semibold text-[#0C102D] truncate max-w-[200px]">
                    {selectedBook?.title || 'Not selected'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Return Deadline</span>
                  <span className="font-semibold text-[#713BFF] tabular-nums">
                    {formatDisplayDate(dueDate)}
                  </span>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 px-4 rounded-xl text-sm font-semibold text-white bg-brand-gradient bg-brand-gradient-hover shadow-md shadow-[#713BFF]/20 transition-all"
              >
                Issue Book
              </button>
            </div>
          </div>
        </form>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Active Loans Lookup */}
          <div className="lg:col-span-7 card-surface p-5 sm:p-6 space-y-4">
            <h2 className="font-display text-lg font-bold text-[#0C102D]">
              Find Active Loan to Return
            </h2>

            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <label htmlFor="return-loan-search" className="sr-only">
                Search active loan by student, book, or loan ID
              </label>
              <input
                id="return-loan-search"
                type="search"
                value={loanSearch}
                onChange={(e) => setLoanSearch(e.target.value)}
                placeholder="Search by loan ID, student name/ID, book title, or ISBN..."
                className={`${inputBaseClass} pl-10`}
              />
            </div>

            {activeLoanList.length === 0 ? (
              <EmptyState
                icon={CheckCircle2}
                title="No matching active loans"
                description="All loans matching your filter have already been returned."
              />
            ) : (
              <div className="space-y-2.5 max-h-[420px] overflow-y-auto pr-1">
                {activeLoanList.map(({ loan, student, book, metrics }) => {
                  const isSelected = loan.id === selectedLoanId;
                  return (
                    <button
                      key={loan.id}
                      type="button"
                      onClick={() => setSelectedLoanId(loan.id)}
                      className={`w-full text-left p-4 rounded-xl border transition-all flex flex-wrap items-center justify-between gap-3 ${
                        isSelected
                          ? 'border-[#713BFF] bg-[#F5F4FF] ring-2 ring-[#713BFF]/20'
                          : 'border-slate-200/90 bg-white hover:border-[#713BFF]/40'
                      }`}
                    >
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
                          <span>{loan.id}</span>
                          <span aria-hidden="true">·</span>
                          <span>{student?.studentId}</span>
                        </div>
                        <p className="text-sm font-bold text-[#0C102D] mt-0.5 truncate">
                          {book?.title ?? 'Unknown Book'}
                        </p>
                        <p className="text-xs text-slate-600 mt-0.5">
                          Borrowed by <strong>{student?.name}</strong> · Due{' '}
                          <span className="tabular-nums">{formatDisplayDate(loan.dueDate)}</span>
                        </p>
                      </div>

                      <div className="flex items-center gap-3 shrink-0">
                        {metrics.calculatedFine > 0 && (
                          <span className="text-xs font-bold text-rose-600 tabular-nums">
                            Fine {settings.currencySymbol}
                            {metrics.calculatedFine.toFixed(2)}
                          </span>
                        )}
                        <StatusBadge status={metrics.derivedStatus} />
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Return Summary & Confirm */}
          <div className="lg:col-span-5">
            <div className="card-surface p-5 sm:p-6 space-y-5 sticky top-24">
              <h2 className="font-display text-lg font-bold text-[#0C102D]">
                Return Summary
              </h2>

              <AnimatePresence mode="wait" initial={false}>
                {!selectedReturnItem ? (
                  <motion.div
                    key="return-empty"
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -4 }}
                    transition={{ duration: 0.16, ease: EASE_SMOOTH }}
                  >
                    <EmptyState
                      icon={BookCheck}
                      title="Select an active loan"
                      description="Choose a checked-out book from the list to review due status, overdue fine, and complete the return."
                    />
                  </motion.div>
                ) : (
                  <motion.div
                    key={selectedReturnItem.loan.id}
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -4 }}
                    transition={{ duration: 0.16, ease: EASE_SMOOTH }}
                    className="space-y-5"
                  >
                    <div className="flex items-center gap-4 p-4 rounded-xl bg-[#FAF9FF] border border-indigo-100">
                      <div className="w-14 h-20 rounded-lg overflow-hidden shrink-0 border border-slate-200">
                        <BookCover
                          src={selectedReturnItem.book?.coverUrl || ''}
                          title={selectedReturnItem.book?.title || 'Book'}
                          className="w-full h-full"
                        />
                      </div>
                      <div className="min-w-0">
                        <p className="text-xs font-mono text-[#713BFF]">
                          {selectedReturnItem.loan.id}
                        </p>
                        <p className="text-sm font-bold text-[#0C102D] truncate">
                          {selectedReturnItem.book?.title}
                        </p>
                        <p className="text-xs text-slate-500 mt-0.5">
                          {selectedReturnItem.student?.name} ({selectedReturnItem.student?.studentId})
                        </p>
                      </div>
                    </div>

                    <div className="space-y-2.5 text-sm">
                      <div className="flex justify-between py-1.5 border-b border-slate-100">
                        <span className="text-slate-500">Issue Date</span>
                        <span className="font-medium text-[#0C102D] tabular-nums">
                          {formatDisplayDate(selectedReturnItem.loan.issueDate)}
                        </span>
                      </div>
                      <div className="flex justify-between py-1.5 border-b border-slate-100">
                        <span className="text-slate-500">Due Date</span>
                        <span className="font-medium text-[#0C102D] tabular-nums">
                          {formatDisplayDate(selectedReturnItem.loan.dueDate)}
                        </span>
                      </div>
                      <div className="flex justify-between py-1.5 border-b border-slate-100">
                        <span className="text-slate-500">Return Date (Today)</span>
                        <span className="font-medium text-[#0C102D] tabular-nums">
                          {formatDisplayDate(today)}
                        </span>
                      </div>
                      <div className="flex justify-between items-center py-1.5 border-b border-slate-100">
                        <span className="text-slate-500">Current Status</span>
                        <StatusBadge status={selectedReturnItem.metrics.derivedStatus} />
                      </div>
                      <div className="flex justify-between items-center pt-1">
                        <span className="font-semibold text-[#0C102D]">Calculated Overdue Fine</span>
                        <span
                          className={`text-lg font-display font-bold tabular-nums ${
                            selectedReturnItem.metrics.calculatedFine > 0
                              ? 'text-rose-600'
                              : 'text-emerald-600'
                          }`}
                        >
                          {settings.currencySymbol}
                          {selectedReturnItem.metrics.calculatedFine.toFixed(2)}
                        </span>
                      </div>
                      {selectedReturnItem.metrics.daysOverdue > 0 && (
                        <p className="text-xs text-rose-600 tabular-nums">
                          {selectedReturnItem.metrics.daysOverdue} overdue{' '}
                          {selectedReturnItem.metrics.daysOverdue === 1 ? 'day' : 'days'} ×{' '}
                          {settings.currencySymbol}
                          {settings.dailyOverdueFine.toFixed(2)}/day
                        </p>
                      )}
                    </div>

                    <button
                      type="button"
                      onClick={() => setReturnConfirmOpen(true)}
                      className="w-full py-3 px-4 rounded-xl text-sm font-semibold text-white bg-brand-gradient bg-brand-gradient-hover shadow-md shadow-[#713BFF]/20 transition-all"
                    >
                      Confirm Return
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      )}
      </TabPanelPresence>

      {/* Recent Issues Table */}
      <AnimatedSection delay={0.08} className="card-surface overflow-hidden">
        <div className="px-5 sm:px-6 py-4 border-b border-slate-100">
          <h2 className="font-display text-lg font-bold text-[#0C102D]">Recent Issues</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Latest loans issued and their current return status
          </p>
        </div>

        <DataTable
          columns={recentColumns}
          data={recentIssuesRows}
          rowKey={(r) => r.id}
          emptyState={
            <div className="p-6">
              <EmptyState
                icon={ArrowLeftRight}
                title="No circulation history yet"
                description="Use the Issue Book form above to lend a book to a student."
              />
            </div>
          }
        />
      </AnimatedSection>

      <ConfirmDialog
        isOpen={returnConfirmOpen}
        onClose={() => setReturnConfirmOpen(false)}
        onConfirm={handleConfirmReturn}
        title="Confirm Book Return"
        message={
          selectedReturnItem
            ? `Confirm return of "${selectedReturnItem.book?.title}" from ${selectedReturnItem.student?.name}${
                selectedReturnItem.metrics.calculatedFine > 0
                  ? ` with a calculated fine of ${settings.currencySymbol}${selectedReturnItem.metrics.calculatedFine.toFixed(2)}`
                  : ''
              }?`
            : ''
        }
        confirmLabel="Confirm Return"
        tone="primary"
      />
    </div>
  );
};
