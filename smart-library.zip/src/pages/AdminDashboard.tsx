import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  AlertTriangle,
  ArrowLeftRight,
  ArrowRight,
  BookOpen,
  BookPlus,
  Sparkles,
  UserPlus,
  Users,
} from 'lucide-react';
import {
  CartesianGrid,
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { AnimatePresence, motion } from 'motion/react';
import { BookCover } from '../components/BookCover';
import { BookFormModal } from '../components/BookFormModal';
import { ColumnDef, DataTable } from '../components/DataTable';
import { EmptyState } from '../components/EmptyState';
import {
  AnimatedSection,
  EASE_SMOOTH,
  StaggerGrid,
  StaggerItem,
} from '../components/MotionPrimitives';
import { StatCard } from '../components/StatCard';
import { StatusBadge } from '../components/StatusBadge';
import { StudentFormModal } from '../components/StudentFormModal';
import { useLibrary } from '../hooks/useLibrary';
import { computeLoanMetrics } from '../services/loanService';
import { recommendationService } from '../services/recommendationService';
import { reportService } from '../services/reportService';
import { addDaysToTodayISO, formatDisplayDate, getTodayISO } from '../utils/dateUtils';

interface RecentLoanRow {
  id: string;
  studentName: string;
  studentCode: string;
  bookTitle: string;
  issueDate: string;
  dueDate: string;
  status: ReturnType<typeof computeLoanMetrics>['derivedStatus'];
}

export const AdminDashboard: React.FC = () => {
  const { books, students, loans, settings } = useLibrary();
  const navigate = useNavigate();

  const [activityRange, setActivityRange] = useState<7 | 14 | 30>(14);
  const [addBookOpen, setAddBookOpen] = useState(false);
  const [addStudentOpen, setAddStudentOpen] = useState(false);

  const today = getTodayISO();

  const totalBookCopies = useMemo(
    () => books.reduce((sum, b) => sum + b.totalCopies, 0),
    [books]
  );
  const availableBookCopies = useMemo(
    () => books.reduce((sum, b) => sum + b.availableCopies, 0),
    [books]
  );
  const activeStudentsCount = useMemo(
    () => students.filter((s) => s.status === 'active').length,
    [students]
  );
  const activeLoans = useMemo(
    () => loans.filter((l) => l.status === 'active'),
    [loans]
  );
  const overdueRows = useMemo(
    () => reportService.getOverdueReport(loans, books, students, settings),
    [books, loans, settings, students]
  );

  const activityData = useMemo(() => {
    const startIso = addDaysToTodayISO(-(activityRange - 1));
    return reportService.buildActivitySeries(loans, startIso, today);
  }, [activityRange, loans, today]);

  const popularBooks = useMemo(
    () => reportService.getPopularBooks(books, loans, 5),
    [books, loans]
  );

  const compactRecommendations = useMemo(
    () => recommendationService.getGlobalCatalogRecommendations(books, loans, 4),
    [books, loans]
  );

  const bookMap = useMemo(() => new Map(books.map((b) => [b.id, b])), [books]);
  const studentMap = useMemo(() => new Map(students.map((s) => [s.id, s])), [students]);

  const recentActivityRows: RecentLoanRow[] = useMemo(() => {
    return [...loans]
      .sort((a, b) => b.issueDate.localeCompare(a.issueDate))
      .slice(0, 6)
      .map((loan) => {
        const book = bookMap.get(loan.bookId);
        const student = studentMap.get(loan.studentId);
        const metrics = computeLoanMetrics(loan, settings, today);
        return {
          id: loan.id,
          studentName: student?.name ?? 'Unknown Student',
          studentCode: student?.studentId ?? '—',
          bookTitle: book?.title ?? 'Unknown Book',
          issueDate: loan.issueDate,
          dueDate: loan.dueDate,
          status: metrics.derivedStatus,
        };
      });
  }, [bookMap, loans, settings, studentMap, today]);

  const recentColumns: ColumnDef<RecentLoanRow>[] = [
    {
      key: 'student',
      header: 'Student',
      colTrack: 'minmax(0, 1.3fr)',
      render: (row) => (
        <div className="min-w-0">
          <p className="font-medium text-[#0C102D] truncate">{row.studentName}</p>
          <p className="text-xs font-mono text-slate-400">{row.studentCode}</p>
        </div>
      ),
    },
    {
      key: 'book',
      header: 'Book Title',
      colTrack: 'minmax(0, 1.5fr)',
      render: (row) => (
        <span className="font-medium text-[#1F2442] line-clamp-1">{row.bookTitle}</span>
      ),
    },
    {
      key: 'issueDate',
      header: 'Issued',
      colTrack: 'minmax(0, 0.85fr)',
      render: (row) => (
        <span className="text-slate-600 tabular-nums whitespace-nowrap">
          {formatDisplayDate(row.issueDate)}
        </span>
      ),
    },
    {
      key: 'dueDate',
      header: 'Due Date',
      colTrack: 'minmax(0, 0.85fr)',
      render: (row) => (
        <span className="text-slate-600 tabular-nums whitespace-nowrap">
          {formatDisplayDate(row.dueDate)}
        </span>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      colTrack: 'minmax(0, 0.85fr)',
      render: (row) => <StatusBadge status={row.status} />,
    },
  ];

  return (
    <div className="space-y-6">
      {/* Page Title & Quick Actions */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-[#0C102D] tracking-tight">
            Librarian Dashboard
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Real-time overview of catalog inventory, student loans, and circulation activity.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={() => setAddBookOpen(true)}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold text-[#0C102D] bg-white border border-indigo-200 hover:border-[#713BFF] hover:text-[#713BFF] transition-colors shadow-xs whitespace-nowrap"
          >
            <BookPlus className="w-4 h-4" aria-hidden="true" />
            <span>Add Book</span>
          </button>

          <button
            type="button"
            onClick={() => setAddStudentOpen(true)}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold text-[#0C102D] bg-white border border-indigo-200 hover:border-[#4361EE] hover:text-[#4361EE] transition-colors shadow-xs whitespace-nowrap"
          >
            <UserPlus className="w-4 h-4" aria-hidden="true" />
            <span>Register Student</span>
          </button>

          <button
            type="button"
            onClick={() => navigate('/issue-return')}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold text-white bg-brand-gradient bg-brand-gradient-hover shadow-md shadow-[#713BFF]/20 transition-all whitespace-nowrap"
          >
            <ArrowLeftRight className="w-4 h-4" aria-hidden="true" />
            <span>Issue Book</span>
          </button>
        </div>
      </div>

      {/* Four Summary Cards */}
      <section aria-label="Library metrics">
        <StaggerGrid className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
          <StaggerItem>
            <StatCard
              title="Total Books"
              value={books.length}
              description={`${totalBookCopies} total copies · ${availableBookCopies} available`}
              icon={BookOpen}
              accent="purple"
              onClick={() => navigate('/books')}
            />
          </StaggerItem>
          <StaggerItem>
            <StatCard
              title="Total Students"
              value={students.length}
              description={`${activeStudentsCount} active student memberships`}
              icon={Users}
              accent="blue"
              onClick={() => navigate('/students')}
            />
          </StaggerItem>
          <StaggerItem>
            <StatCard
              title="Issued Books"
              value={activeLoans.length}
              description="Currently checked out across all students"
              icon={ArrowLeftRight}
              accent="amber"
              onClick={() => navigate('/issue-return')}
            />
          </StaggerItem>
          <StaggerItem>
            <StatCard
              title="Overdue Books"
              value={overdueRows.length}
              description={
                overdueRows.length > 0
                  ? `Requires follow-up (${settings.currencySymbol}${overdueRows
                      .reduce((sum, r) => sum + r.fineAmount, 0)
                      .toFixed(2)} accrued)`
                  : 'All active loans are within due dates'
              }
              icon={AlertTriangle}
              accent="rose"
              onClick={() => navigate('/issue-return?tab=return')}
            />
          </StaggerItem>
        </StaggerGrid>
      </section>

      {/* Main Chart + Popular Books */}
      <AnimatedSection delay={0.05} className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <section className="xl:col-span-2 card-surface p-5 sm:p-6 flex flex-col">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
            <div>
              <h2 className="font-display text-lg font-bold text-[#0C102D]">
                Library Activity
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Daily issued vs. returned books calculated from active circulation logs
              </p>
            </div>

            <div className="inline-flex items-center p-1 bg-[#F5F4FF] rounded-xl border border-indigo-100 self-start">
              {([7, 14, 30] as const).map((days) => (
                <button
                  key={days}
                  type="button"
                  onClick={() => setActivityRange(days)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all whitespace-nowrap ${
                    activityRange === days
                      ? 'bg-white text-[#713BFF] shadow-xs'
                      : 'text-slate-500 hover:text-[#0C102D]'
                  }`}
                >
                  {days} Days
                </button>
              ))}
            </div>
          </div>

          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={activityData} margin={{ top: 8, right: 12, left: -16, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#ECE9FF" vertical={false} />
                <XAxis
                  dataKey="label"
                  tick={{ fill: '#64748B', fontSize: 12 }}
                  axisLine={{ stroke: '#E2E8F0' }}
                  tickLine={false}
                />
                <YAxis
                  allowDecimals={false}
                  tick={{ fill: '#64748B', fontSize: 12 }}
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip
                  contentStyle={{
                    borderRadius: '12px',
                    border: '1px solid rgba(113,59,255,0.15)',
                    boxShadow: '0 10px 25px -5px rgba(12,16,45,0.12)',
                    fontSize: '12px',
                  }}
                />
                <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '8px' }} />
                <Line
                  type="monotone"
                  dataKey="issued"
                  name="Issued Books"
                  stroke="#713BFF"
                  strokeWidth={2.5}
                  dot={{ r: 3.5, fill: '#713BFF' }}
                  activeDot={{ r: 5 }}
                />
                <Line
                  type="monotone"
                  dataKey="returned"
                  name="Returned Books"
                  stroke="#4361EE"
                  strokeWidth={2.5}
                  dot={{ r: 3.5, fill: '#4361EE' }}
                  activeDot={{ r: 5 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </section>

        {/* Popular Books */}
        <section className="card-surface p-5 sm:p-6 flex flex-col">
          <div className="flex items-center justify-between gap-2 mb-4">
            <div>
              <h2 className="font-display text-lg font-bold text-[#0C102D]">Popular Books</h2>
              <p className="text-xs text-slate-500 mt-0.5">Most borrowed catalog titles</p>
            </div>
            <button
              type="button"
              onClick={() => navigate('/books')}
              className="text-xs font-semibold text-[#713BFF] hover:text-[#4361EE] inline-flex items-center gap-1"
            >
              <span>Catalog</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3 flex-1">
            {popularBooks.map((item) => (
              <button
                key={item.book.id}
                type="button"
                onClick={() => navigate(`/books/${item.book.id}`)}
                className="w-full flex items-center gap-3 p-2.5 rounded-xl hover:bg-[#F5F4FF] transition-colors text-left"
              >
                <div className="w-11 h-14 rounded-lg overflow-hidden shrink-0 border border-slate-100">
                  <BookCover
                    src={item.book.coverUrl}
                    title={item.book.title}
                    category={item.book.category}
                    className="w-full h-full"
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-[#0C102D] truncate">
                    {item.book.title}
                  </p>
                  <p className="text-xs text-slate-500 truncate">{item.book.author}</p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-sm font-bold text-[#713BFF] tabular-nums">
                    {item.borrowCount}
                  </p>
                  <p className="text-[11px] text-slate-400">loans</p>
                </div>
              </button>
            ))}
          </div>
        </section>
      </AnimatedSection>

      {/* Recent Borrowing Activity + Overdue Books */}
      <AnimatedSection delay={0.08} className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <section className="xl:col-span-2 card-surface overflow-hidden">
          <div className="px-5 sm:px-6 py-4 border-b border-slate-100 flex items-center justify-between gap-2">
            <div>
              <h2 className="font-display text-lg font-bold text-[#0C102D]">
                Recent Borrowing Activity
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Latest issue and return transactions
              </p>
            </div>
            <button
              type="button"
              onClick={() => navigate('/issue-return')}
              className="text-xs font-semibold text-[#713BFF] hover:text-[#4361EE] inline-flex items-center gap-1 whitespace-nowrap"
            >
              <span>Manage Loans</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <DataTable
            columns={recentColumns}
            data={recentActivityRows}
            rowKey={(r) => r.id}
            emptyState={
              <div className="p-6">
                <EmptyState
                  icon={ArrowLeftRight}
                  title="No borrowing activity yet"
                  description="Issue a book to a student to see live loan records here."
                  actionLabel="Issue Book"
                  onAction={() => navigate('/issue-return')}
                />
              </div>
            }
          />
        </section>

        {/* Overdue Books List */}
        <section className="card-surface p-5 sm:p-6 flex flex-col">
          <div className="flex items-center justify-between gap-2 mb-4">
            <div>
              <h2 className="font-display text-lg font-bold text-[#0C102D]">Overdue Books</h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Loans past due date as of {formatDisplayDate(today)}
              </p>
            </div>
            <span className="px-2.5 py-1 rounded-lg bg-rose-50 text-rose-700 text-xs font-semibold tabular-nums">
              {overdueRows.length} overdue
            </span>
          </div>

          {overdueRows.length === 0 ? (
            <EmptyState
              icon={BookOpen}
              title="No overdue loans"
              description="All currently checked-out books are within their scheduled return dates."
            />
          ) : (
            <div className="space-y-3 flex-1">
              <AnimatePresence initial={false}>
                {overdueRows.map((row) => (
                  <motion.div
                    key={row.loan.id}
                    layout
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.96 }}
                    transition={{ duration: 0.18, ease: EASE_SMOOTH }}
                    className="p-3.5 rounded-xl border border-rose-100 bg-rose-50/40 flex items-start justify-between gap-3"
                  >
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-[#0C102D] truncate">
                        {row.book.title}
                      </p>
                      <p className="text-xs text-slate-600 mt-0.5 truncate">
                        {row.student.name} · <span className="font-mono">{row.student.studentId}</span>
                      </p>
                      <p className="text-xs font-medium text-rose-700 mt-1.5 tabular-nums">
                        {row.daysOverdue} {row.daysOverdue === 1 ? 'day' : 'days'} overdue · Fine{' '}
                        {settings.currencySymbol}
                        {row.fineAmount.toFixed(2)}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => navigate(`/issue-return?tab=return&loanId=${row.loan.id}`)}
                      className="px-3 py-1.5 rounded-lg text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 transition-colors shrink-0"
                    >
                      Return
                    </button>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          )}
        </section>
      </AnimatedSection>

      {/* Compact Book Recommendations Panel */}
      <AnimatedSection delay={0.1} className="card-surface p-5 sm:p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-brand-gradient text-white flex items-center justify-center shrink-0">
              <Sparkles className="w-4 h-4" aria-hidden="true" />
            </div>
            <div>
              <h2 className="font-display text-lg font-bold text-[#0C102D]">
                Book Recommendations
              </h2>
              <p className="text-xs text-slate-500">
                Top-ranked catalog picks based on loan demand and reader ratings
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => navigate('/recommendations')}
            className="text-xs font-semibold text-[#713BFF] hover:text-[#4361EE] inline-flex items-center gap-1 self-start sm:self-auto"
          >
            <span>Explore Recommendations</span>
            <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
          </button>
        </div>

        <StaggerGrid className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {compactRecommendations.map((rec) => (
            <StaggerItem key={rec.book.id}>
              <motion.button
                type="button"
                whileHover={{ y: -2 }}
                onClick={() => navigate(`/books/${rec.book.id}`)}
                className="w-full flex items-center gap-3 p-3 rounded-xl border border-indigo-100/80 hover:border-[#713BFF]/40 hover:bg-[#FAF9FF] transition-colors text-left"
              >
                <div className="w-12 h-16 rounded-lg overflow-hidden shrink-0 border border-slate-100">
                  <BookCover
                    src={rec.book.coverUrl}
                    title={rec.book.title}
                    category={rec.book.category}
                    className="w-full h-full"
                  />
                </div>
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-[#0C102D] truncate">
                    {rec.book.title}
                  </p>
                  <p className="text-xs text-slate-500 truncate">{rec.book.author}</p>
                  <p className="text-[11px] font-medium text-[#4361EE] mt-1 truncate">
                    {rec.reason}
                  </p>
                </div>
              </motion.button>
            </StaggerItem>
          ))}
        </StaggerGrid>
      </AnimatedSection>

      <BookFormModal isOpen={addBookOpen} onClose={() => setAddBookOpen(false)} />
      <StudentFormModal isOpen={addStudentOpen} onClose={() => setAddStudentOpen(false)} />
    </div>
  );
};
