import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { BookOpen, BookPlus, ChevronLeft, ChevronRight } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { BookCard } from '../components/BookCard';
import {
  AvailabilityFilter,
  BookFilters,
  BookSortOption,
} from '../components/BookFilters';
import { BookFormModal } from '../components/BookFormModal';
import { ConfirmDialog } from '../components/ConfirmDialog';
import { EmptyState } from '../components/EmptyState';
import {
  EASE_SMOOTH,
  staggerListItemVariants,
  staggerListVariants,
} from '../components/MotionPrimitives';
import { useLibrary } from '../hooks/useLibrary';
import { Book } from '../types/library';

export const BookCatalogPage: React.FC = () => {
  const {
    user,
    books,
    currentUserWishlist,
    toggleWishlist,
    deleteBook,
    showToast,
  } = useLibrary();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();

  const [searchQuery, setSearchQuery] = useState(searchParams.get('q') || '');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [availability, setAvailability] = useState<AvailabilityFilter>('all');
  const [sortBy, setSortBy] = useState<BookSortOption>('title_asc');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [currentPage, setCurrentPage] = useState(1);

  const [formOpen, setFormOpen] = useState(false);
  const [editingBook, setEditingBook] = useState<Book | null>(null);
  const [deletingBook, setDeletingBook] = useState<Book | null>(null);

  const isAdmin = user?.role === 'admin';
  const pageSize = viewMode === 'grid' ? 8 : 8;

  useEffect(() => {
    const q = searchParams.get('q');
    if (q !== null && q !== searchQuery) {
      setSearchQuery(q);
    }
  }, [searchParams]);

  const filteredBooks = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const list = books.filter((book) => {
      if (q) {
        const matches =
          book.title.toLowerCase().includes(q) ||
          book.author.toLowerCase().includes(q) ||
          book.category.toLowerCase().includes(q) ||
          book.isbn.toLowerCase().includes(q);
        if (!matches) return false;
      }
      if (selectedCategory !== 'all' && book.category !== selectedCategory) {
        return false;
      }
      if (availability === 'available' && book.availableCopies <= 0) {
        return false;
      }
      if (availability === 'checked_out' && book.availableCopies > 0) {
        return false;
      }
      return true;
    });

    return [...list].sort((a, b) => {
      if (sortBy === 'rating_desc') return b.rating - a.rating || a.title.localeCompare(b.title);
      if (sortBy === 'newest')
        return b.publicationYear - a.publicationYear || b.addedAt.localeCompare(a.addedAt);
      return a.title.localeCompare(b.title);
    });
  }, [availability, books, searchQuery, selectedCategory, sortBy]);

  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery, selectedCategory, availability, sortBy, viewMode]);

  const totalPages = Math.max(1, Math.ceil(filteredBooks.length / pageSize));
  const paginatedBooks = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredBooks.slice(start, start + pageSize);
  }, [currentPage, filteredBooks, pageSize]);

  const hasActiveFilters =
    searchQuery.trim() !== '' || selectedCategory !== 'all' || availability !== 'all';

  const handleClearFilters = () => {
    setSearchQuery('');
    setSelectedCategory('all');
    setAvailability('all');
    setSortBy('title_asc');
    if (searchParams.has('q')) {
      setSearchParams({});
    }
  };

  const handleConfirmDelete = () => {
    if (!deletingBook) return;
    const res = deleteBook(deletingBook.id);
    if (!res.ok) {
      showToast({
        type: 'error',
        title: 'Cannot Delete Book',
        description: res.error,
      });
    } else {
      showToast({
        type: 'success',
        title: 'Book Removed',
        description: `"${deletingBook.title}" has been deleted from the catalog.`,
      });
    }
    setDeletingBook(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-[#0C102D] tracking-tight">
            Book Catalog
          </h1>
          <p className="text-sm text-slate-500 mt-1 tabular-nums">
            Showing {filteredBooks.length} of {books.length} titles in the collection
          </p>
        </div>

        {isAdmin && (
          <button
            type="button"
            onClick={() => {
              setEditingBook(null);
              setFormOpen(true);
            }}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold text-white bg-brand-gradient bg-brand-gradient-hover shadow-md shadow-[#713BFF]/20 transition-all self-start sm:self-auto whitespace-nowrap"
          >
            <BookPlus className="w-4 h-4" aria-hidden="true" />
            <span>Add Book</span>
          </button>
        )}
      </div>

      <BookFilters
        books={books}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        selectedCategory={selectedCategory}
        onCategoryChange={setSelectedCategory}
        availability={availability}
        onAvailabilityChange={setAvailability}
        sortBy={sortBy}
        onSortChange={setSortBy}
        viewMode={viewMode}
        onViewModeChange={setViewMode}
        onClearFilters={handleClearFilters}
        hasActiveFilters={hasActiveFilters}
      />

      <AnimatePresence mode="wait" initial={false}>
        {paginatedBooks.length === 0 ? (
          <motion.div
            key="catalog-empty"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.18, ease: EASE_SMOOTH }}
          >
            <EmptyState
              icon={BookOpen}
              title="No matching books found"
              description="Try adjusting your search keywords, category, or availability filter."
              actionLabel="Clear Filters"
              onAction={handleClearFilters}
            />
          </motion.div>
        ) : (
          <motion.div
            key={`catalog-${viewMode}-${currentPage}-${selectedCategory}-${availability}-${sortBy}`}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.16, ease: EASE_SMOOTH }}
            className="space-y-6"
          >
            <motion.ul
              initial="hidden"
              animate="visible"
              variants={staggerListVariants}
              className={
                viewMode === 'grid'
                  ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5 list-none m-0 p-0'
                  : 'space-y-3.5 list-none m-0 p-0'
              }
            >
              {paginatedBooks.map((book) => (
                <motion.li
                  key={book.id}
                  variants={staggerListItemVariants}
                  className={viewMode === 'grid' ? 'h-full' : ''}
                >
                  <BookCard
                    book={book}
                    viewMode={viewMode}
                    isStudent={!isAdmin}
                    isWishlisted={currentUserWishlist.includes(book.id)}
                    onToggleWishlist={toggleWishlist}
                    onViewDetails={(b) => navigate(`/books/${b.id}`)}
                    onEdit={
                      isAdmin
                        ? (b) => {
                            setEditingBook(b);
                            setFormOpen(true);
                          }
                        : undefined
                    }
                    onDelete={isAdmin ? (b) => setDeletingBook(b) : undefined}
                  />
                </motion.li>
              ))}
            </motion.ul>

            {/* Pagination */}
            {totalPages > 1 && (
              <nav
                aria-label="Catalog pagination"
                className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2"
              >
                <p className="text-xs text-slate-500 tabular-nums">
                  Page {currentPage} of {totalPages}
                </p>

                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    disabled={currentPage === 1}
                    onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                    className="inline-flex items-center gap-1 px-3 py-2 rounded-xl text-xs font-medium bg-white border border-slate-200 text-slate-700 hover:bg-[#FAF9FF] disabled:opacity-45 disabled:pointer-events-none"
                  >
                    <ChevronLeft className="w-4 h-4" />
                    <span>Previous</span>
                  </button>

                  {Array.from({ length: totalPages }, (_, idx) => idx + 1).map((pageNum) => (
                    <button
                      key={pageNum}
                      type="button"
                      onClick={() => setCurrentPage(pageNum)}
                      aria-current={currentPage === pageNum ? 'page' : undefined}
                      className={`w-9 h-9 rounded-xl text-xs font-semibold tabular-nums transition-all ${
                        currentPage === pageNum
                          ? 'bg-brand-gradient text-white shadow-sm'
                          : 'bg-white border border-slate-200 text-slate-700 hover:border-[#713BFF]/40'
                      }`}
                    >
                      {pageNum}
                    </button>
                  ))}

                  <button
                    type="button"
                    disabled={currentPage === totalPages}
                    onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                    className="inline-flex items-center gap-1 px-3 py-2 rounded-xl text-xs font-medium bg-white border border-slate-200 text-slate-700 hover:bg-[#FAF9FF] disabled:opacity-45 disabled:pointer-events-none"
                  >
                    <span>Next</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </nav>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      <BookFormModal
        isOpen={formOpen}
        onClose={() => {
          setFormOpen(false);
          setEditingBook(null);
        }}
        editingBook={editingBook}
      />

      <ConfirmDialog
        isOpen={Boolean(deletingBook)}
        onClose={() => setDeletingBook(null)}
        onConfirm={handleConfirmDelete}
        title="Delete Book from Catalog"
        message={
          deletingBook
            ? `Are you sure you want to permanently remove "${deletingBook.title}"? Books with active student loans cannot be deleted until all copies are returned.`
            : ''
        }
        confirmLabel="Delete Book"
        tone="danger"
      />
    </div>
  );
};
