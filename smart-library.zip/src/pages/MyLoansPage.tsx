import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { BookMarked, BookOpen, Clock } from 'lucide-react';
import { motion } from 'motion/react';
import { ColumnDef, DataTable } from '../components/DataTable';
import { EmptyState } from '../components/EmptyState';
import { TabPanelPresence } from '../components/MotionPrimitives';
import { StatusBadge } from '../components/StatusBadge';
import { useLibrary } from '../hooks/useLibrary';
import { computeLoanMetrics } from '../services/loanService';
import { formatDisplayDate, getTodayISO } from '../utils/dateUtils';

interface LoanViewRow {
  id: string;
  bookId: string;
  title: string;
  author: string;
  issueDate: string;
  dueDate: string;
  returnDate: string | null;
  status: ReturnType<typeof computeLoanMetrics>['derivedStatus'];
  timelineText: string;
  fine: number;
}

export const MyLoansPage: React.FC = () => {
  const { currentStudent, loans, books, settings } = useLibrary();
  const navigate = useNavigate();
  const [tab, setTab] = useState<'current' | 'history'>('current');
  const today = getTodayISO();

  const bookMap = useMemo(() => new Map(books.map((b) => [b.id, b])), [books]);

  const myLoanRows: LoanViewRow[] = useMemo(() => {
    if (!currentStudent) return [];
    return loans
      .filter((l) => l.studentId === currentStudent.id)
      .sort((a, b) => b.issueDate.localeCompare(a.issueDate))
      .map((loan) => {
        const book = bookMap.get(loan.bookId);
        const metrics = computeLoanMetrics(loan, settings, today);
        let timelineText = 'Returned';
        if (loan.status === 'active') {
          if (metrics.derivedStatus === 'Overdue') {
            timelineText = `${metrics.daysOverdue} ${
              metrics.daysOverdue === 1 ? 'day' : 'days'
            } overdue`;
          } else if (metrics.daysRemaining === 0) {
            timelineText = 'Due today';
          } else {
            timelineText = `${metrics.daysRemaining} ${
              metrics.daysRemaining === 1 ? 'day' : 'days'
            } remaining`;
          }
        }
        return {
          id: loan.id,
          bookId: loan.bookId,
          title: book?.title ?? 'Unknown Book',
          author: book?.author ?? '',
          issueDate: loan.issueDate,
          dueDate: loan.dueDate,
          returnDate: loan.returnDate,
          status: metrics.derivedStatus,
          timelineText,
          fine: metrics.calculatedFine,
        };
      });
  }, [bookMap, currentStudent, loans, settings, today]);

  const currentLoans = myLoanRows.filter((r) => r.status !== 'Returned');
  const historyLoans = myLoanRows.filter((r) => r.status === 'Returned');

  const currentColumns: ColumnDef<LoanViewRow>[] = [
    {
      key: 'book',
      header: 'Book Title',
      render: (r) => (
        <button
          type="button"
          onClick={() => navigate(`/books/${r.bookId}`)}
          className="text-left hover:text-[#713BFF]"
        >
          <p className="font-semibold text-[#0C102D]">{r.title}</p>
          <p className="text-xs text-slate-500">{r.author}</p>
        </button>
      ),
    },
    {
      key: 'issueDate',
      header: 'Issue Date',
      render: (r) => <span className="tabular-nums">{formatDisplayDate(r.issueDate)}</span>,
    },
    {
      key: 'dueDate',
      header: 'Due Date',
      render: (r) => <span className="tabular-nums">{formatDisplayDate(r.dueDate)}</span>,
    },
    {
      key: 'status',
      header: 'Status',
      render: (r) => <StatusBadge status={r.status} />,
    },
    {
      key: 'remaining',
      header: 'Remaining / Overdue',
      render: (r) => (
        <span
          className={`text-xs font-semibold tabular-nums ${
            r.status === 'Overdue'
              ? 'text-rose-600'
              : r.status === 'Due Soon'
              ? 'text-amber-700'
              : 'text-slate-600'
          }`}
        >
          {r.timelineText}
        </span>
      ),
    },
    {
      key: 'fine',
      header: 'Accrued Fine',
      align: 'right',
      render: (r) => (
        <span
          className={`font-semibold tabular-nums ${
            r.fine > 0 ? 'text-rose-600' : 'text-slate-500'
          }`}
        >
          {settings.currencySymbol}
          {r.fine.toFixed(2)}
        </span>
      ),
    },
  ];

  const historyColumns: ColumnDef<LoanViewRow>[] = [
    {
      key: 'book',
      header: 'Book Title',
      render: (r) => (
        <button
          type="button"
          onClick={() => navigate(`/books/${r.bookId}`)}
          className="text-left hover:text-[#713BFF]"
        >
          <p className="font-semibold text-[#0C102D]">{r.title}</p>
          <p className="text-xs text-slate-500">{r.author}</p>
        </button>
      ),
    },
    {
      key: 'issueDate',
      header: 'Issue Date',
      render: (r) => <span className="tabular-nums">{formatDisplayDate(r.issueDate)}</span>,
    },
    {
      key: 'returnDate',
      header: 'Return Date',
      render: (r) => <span className="tabular-nums">{formatDisplayDate(r.returnDate)}</span>,
    },
    {
      key: 'status',
      header: 'Status',
      render: (r) => <StatusBadge status={r.status} />,
    },
    {
      key: 'fine',
      header: 'Fine Paid',
      align: 'right',
      render: (r) => (
        <span className="tabular-nums text-slate-600">
          {settings.currencySymbol}
          {r.fine.toFixed(2)}
        </span>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-[#0C102D] tracking-tight">
            My Loans
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Monitor active due dates, overdue notices, and completed reading history
          </p>
        </div>

        <div className="inline-flex items-center p-1 bg-white rounded-xl border border-indigo-100 shadow-xs self-start">
          <button
            type="button"
            onClick={() => setTab('current')}
            className={`relative inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-colors ${
              tab === 'current'
                ? 'text-white'
                : 'text-slate-600 hover:text-[#0C102D]'
            }`}
          >
            {tab === 'current' && (
              <motion.span
                layoutId="myloans-tab-pill"
                transition={{ type: 'spring', stiffness: 450, damping: 32 }}
                className="absolute inset-0 rounded-lg bg-brand-gradient shadow-sm"
                aria-hidden="true"
              />
            )}
            <BookMarked className="relative z-10 w-4 h-4" />
            <span className="relative z-10">Current Loans ({currentLoans.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setTab('history')}
            className={`relative inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-colors ${
              tab === 'history'
                ? 'text-white'
                : 'text-slate-600 hover:text-[#0C102D]'
            }`}
          >
            {tab === 'history' && (
              <motion.span
                layoutId="myloans-tab-pill"
                transition={{ type: 'spring', stiffness: 450, damping: 32 }}
                className="absolute inset-0 rounded-lg bg-brand-gradient shadow-sm"
                aria-hidden="true"
              />
            )}
            <Clock className="relative z-10 w-4 h-4" />
            <span className="relative z-10">Borrowing History ({historyLoans.length})</span>
          </button>
        </div>
      </div>

      <div className="card-surface overflow-hidden">
        <TabPanelPresence tabKey={tab}>
          {tab === 'current' ? (
            <DataTable
              columns={currentColumns}
              data={currentLoans}
              rowKey={(r) => r.id}
              emptyState={
                <div className="p-8">
                  <EmptyState
                    icon={BookOpen}
                    title="No active loans"
                    description="You do not have any books checked out right now."
                    actionLabel="Browse Books"
                    onAction={() => navigate('/books')}
                  />
                </div>
              }
            />
          ) : (
            <DataTable
              columns={historyColumns}
              data={historyLoans}
              rowKey={(r) => r.id}
              emptyState={
                <div className="p-8">
                  <EmptyState
                    icon={Clock}
                    title="No borrowing history yet"
                    description="Books you borrow and return will appear in your reading history."
                    actionLabel="Explore Catalog"
                    onAction={() => navigate('/books')}
                  />
                </div>
              }
            />
          )}
        </TabPanelPresence>
      </div>
    </div>
  );
};
