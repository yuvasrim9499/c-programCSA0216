import React, { useMemo, useState } from 'react';
import {
  Eye,
  Pencil,
  Power,
  Search,
  UserPlus,
  Users,
} from 'lucide-react';
import { motion } from 'motion/react';
import { ConfirmDialog } from '../components/ConfirmDialog';
import { ColumnDef, DataTable } from '../components/DataTable';
import { EmptyState } from '../components/EmptyState';
import { Modal } from '../components/Modal';
import { AnimatedSection } from '../components/MotionPrimitives';
import { StatusBadge } from '../components/StatusBadge';
import { StudentFormModal } from '../components/StudentFormModal';
import { useLibrary } from '../hooks/useLibrary';
import { computeLoanMetrics } from '../services/loanService';
import { Student } from '../types/library';
import { formatDisplayDate, getTodayISO } from '../utils/dateUtils';

interface StudentRow {
  student: Student;
  activeLoans: number;
  totalLoans: number;
  outstandingFine: number;
}

export const StudentsPage: React.FC = () => {
  const { students, loans, books, settings, toggleStudentStatus, showToast } =
    useLibrary();

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive'>('all');
  const [formOpen, setFormOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [detailStudent, setDetailStudent] = useState<Student | null>(null);
  const [confirmToggleStudent, setConfirmToggleStudent] = useState<Student | null>(null);

  const today = getTodayISO();
  const bookMap = useMemo(() => new Map(books.map((b) => [b.id, b])), [books]);

  const studentRows: StudentRow[] = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();

    return students
      .filter((stu) => {
        if (statusFilter !== 'all' && stu.status !== statusFilter) return false;
        if (q) {
          return (
            stu.name.toLowerCase().includes(q) ||
            stu.email.toLowerCase().includes(q) ||
            stu.studentId.toLowerCase().includes(q) ||
            stu.department.toLowerCase().includes(q)
          );
        }
        return true;
      })
      .map((stu) => {
        const stuLoans = loans.filter((l) => l.studentId === stu.id);
        const active = stuLoans.filter((l) => l.status === 'active');
        const outstandingFine = active.reduce((sum, l) => {
          return sum + computeLoanMetrics(l, settings, today).calculatedFine;
        }, 0);
        return {
          student: stu,
          activeLoans: active.length,
          totalLoans: stuLoans.length,
          outstandingFine,
        };
      });
  }, [loans, searchQuery, settings, statusFilter, students, today]);

  const detailLoans = useMemo(() => {
    if (!detailStudent) return [];
    return loans
      .filter((l) => l.studentId === detailStudent.id)
      .sort((a, b) => b.issueDate.localeCompare(a.issueDate))
      .map((l) => ({
        loan: l,
        book: bookMap.get(l.bookId),
        metrics: computeLoanMetrics(l, settings, today),
      }));
  }, [bookMap, detailStudent, loans, settings, today]);

  const handleToggleStatus = () => {
    if (!confirmToggleStudent) return;
    const res = toggleStudentStatus(confirmToggleStudent.id);
    if (res.ok && res.data) {
      showToast({
        type: 'success',
        title: `Student ${res.data.status === 'active' ? 'Activated' : 'Deactivated'}`,
        description: `${res.data.name} (${res.data.studentId})`,
      });
    }
    setConfirmToggleStudent(null);
  };

  const columns: ColumnDef<StudentRow>[] = [
    {
      key: 'studentId',
      header: 'Student ID',
      colTrack: 'minmax(0, 0.85fr)',
      render: (r) => (
        <span className="font-mono text-xs font-semibold text-[#713BFF]">
          {r.student.studentId}
        </span>
      ),
    },
    {
      key: 'name',
      header: 'Student',
      colTrack: 'minmax(0, 1.25fr)',
      render: (r) => (
        <div className="min-w-0">
          <p className="font-semibold text-[#0C102D] truncate">{r.student.name}</p>
          <p className="text-xs text-slate-500 truncate">{r.student.department}</p>
        </div>
      ),
    },
    {
      key: 'email',
      header: 'Email',
      colTrack: 'minmax(0, 1.55fr)',
      render: (r) => <span className="text-slate-600 truncate block">{r.student.email}</span>,
    },
    {
      key: 'activeLoans',
      header: 'Active Loans',
      align: 'center',
      colTrack: 'minmax(0, 0.8fr)',
      render: (r) => (
        <span className="font-semibold text-[#0C102D] tabular-nums">
          {r.activeLoans}
          <span className="text-slate-400 font-normal"> / {settings.maxActiveLoansPerStudent}</span>
        </span>
      ),
    },
    {
      key: 'fines',
      header: 'Outstanding Fines',
      align: 'right',
      colTrack: 'minmax(0, 0.9fr)',
      render: (r) => (
        <span
          className={`font-semibold tabular-nums ${
            r.outstandingFine > 0 ? 'text-rose-600' : 'text-slate-500'
          }`}
        >
          {settings.currencySymbol}
          {r.outstandingFine.toFixed(2)}
        </span>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      colTrack: 'minmax(0, 0.75fr)',
      render: (r) => (
        <StatusBadge status={r.student.status === 'active' ? 'Active' : 'Inactive'} />
      ),
    },
    {
      key: 'actions',
      header: 'Actions',
      align: 'right',
      render: (r) => (
        <div className="inline-flex items-center justify-end gap-1.5">
          <button
            type="button"
            onClick={() => setDetailStudent(r.student)}
            aria-label={`View borrowing history for ${r.student.name}`}
            className="p-2 rounded-lg text-slate-500 hover:text-[#4361EE] hover:bg-[#EEF2FF] transition-colors"
          >
            <Eye className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => {
              setEditingStudent(r.student);
              setFormOpen(true);
            }}
            aria-label={`Edit ${r.student.name}`}
            className="p-2 rounded-lg text-slate-500 hover:text-[#713BFF] hover:bg-[#F5F4FF] transition-colors"
          >
            <Pencil className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => setConfirmToggleStudent(r.student)}
            aria-label={
              r.student.status === 'active'
                ? `Deactivate ${r.student.name}`
                : `Activate ${r.student.name}`
            }
            className={`p-2 rounded-lg transition-colors ${
              r.student.status === 'active'
                ? 'text-slate-500 hover:text-rose-600 hover:bg-rose-50'
                : 'text-slate-500 hover:text-emerald-600 hover:bg-emerald-50'
            }`}
          >
            <Power className="w-4 h-4" />
          </button>
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-[#0C102D] tracking-tight">
            Student Management
          </h1>
          <p className="text-sm text-slate-500 mt-1 tabular-nums">
            Manage {students.length} registered student memberships and borrowing eligibility
          </p>
        </div>

        <button
          type="button"
          onClick={() => {
            setEditingStudent(null);
            setFormOpen(true);
          }}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold text-white bg-brand-gradient bg-brand-gradient-hover shadow-md shadow-[#713BFF]/20 transition-all self-start sm:self-auto whitespace-nowrap"
        >
          <UserPlus className="w-4 h-4" aria-hidden="true" />
          <span>Add Student</span>
        </button>
      </div>

      {/* Search & Status Filter */}
      <AnimatedSection delay={0.02}>
        <div className="card-surface p-4 flex flex-col sm:flex-row sm:items-center gap-3">
          <div className="relative flex-1 min-w-0">
            <Search
              className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
              aria-hidden="true"
            />
            <label htmlFor="student-search" className="sr-only">
              Search students by name, ID, email, or department
            </label>
            <input
              id="student-search"
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by student ID, name, email, or department..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 bg-white text-sm text-[#111827] placeholder:text-slate-400 focus:outline-none focus:border-[#713BFF] focus:ring-3 focus:ring-[#713BFF]/15"
            />
          </div>

          <div className="inline-flex items-center p-1 bg-[#F5F4FF] rounded-xl border border-indigo-100 self-start sm:self-auto">
            {(['all', 'active', 'inactive'] as const).map((st) => {
              const active = statusFilter === st;
              return (
                <button
                  key={st}
                  type="button"
                  onClick={() => setStatusFilter(st)}
                  className={`relative px-3.5 py-1.5 rounded-lg text-xs font-semibold capitalize transition-colors ${
                    active ? 'text-[#713BFF]' : 'text-slate-500 hover:text-[#0C102D]'
                  }`}
                >
                  {active && (
                    <motion.span
                      layoutId="students-status-pill"
                      transition={{ type: 'spring', stiffness: 420, damping: 32 }}
                      className="absolute inset-0 rounded-lg bg-white shadow-xs"
                    />
                  )}
                  <span className="relative z-10">{st}</span>
                </button>
              );
            })}
          </div>
        </div>
      </AnimatedSection>

      {/* Student Table */}
      <AnimatedSection delay={0.06}>
        <div className="card-surface overflow-hidden">
          <DataTable
            columns={columns}
            data={studentRows}
            rowKey={(r) => r.student.id}
            emptyState={
              <div className="p-8">
                <EmptyState
                  icon={Users}
                  title="No students match your search"
                  description="Try clearing the search query or registering a new student account."
                  actionLabel="Reset Search"
                  onAction={() => {
                    setSearchQuery('');
                    setStatusFilter('all');
                  }}
                />
              </div>
            }
          />
        </div>
      </AnimatedSection>

      <StudentFormModal
        isOpen={formOpen}
        onClose={() => {
          setFormOpen(false);
          setEditingStudent(null);
        }}
        editingStudent={editingStudent}
      />

      {/* Student Detail & History Modal */}
      <Modal
        isOpen={Boolean(detailStudent)}
        onClose={() => setDetailStudent(null)}
        title={detailStudent?.name || 'Student Details'}
        subtitle={
          detailStudent
            ? `${detailStudent.studentId} · ${detailStudent.department} · ${detailStudent.year}`
            : undefined
        }
        size="lg"
        footer={
          <button
            type="button"
            onClick={() => setDetailStudent(null)}
            className="px-4 py-2 rounded-xl text-sm font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50"
          >
            Close
          </button>
        }
      >
        {detailStudent && (
          <div className="space-y-5">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-3.5 rounded-xl bg-[#FAF9FF] border border-indigo-100">
                <p className="text-xs text-slate-500">Email</p>
                <p className="text-sm font-medium text-[#0C102D] mt-0.5 truncate">
                  {detailStudent.email}
                </p>
              </div>
              <div className="p-3.5 rounded-xl bg-[#FAF9FF] border border-indigo-100">
                <p className="text-xs text-slate-500">Account Status</p>
                <div className="mt-1">
                  <StatusBadge
                    status={detailStudent.status === 'active' ? 'Active' : 'Inactive'}
                  />
                </div>
              </div>
              <div className="p-3.5 rounded-xl bg-[#FAF9FF] border border-indigo-100">
                <p className="text-xs text-slate-500">Member Since</p>
                <p className="text-sm font-medium text-[#0C102D] mt-0.5 tabular-nums">
                  {formatDisplayDate(detailStudent.joinedAt)}
                </p>
              </div>
            </div>

            <div>
              <h3 className="font-display text-sm font-bold text-[#0C102D] mb-2.5">
                Borrowing History ({detailLoans.length})
              </h3>
              {detailLoans.length === 0 ? (
                <p className="text-sm text-slate-500 py-4 text-center rounded-xl bg-[#FAF9FF]">
                  This student has not borrowed any books yet.
                </p>
              ) : (
                <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                  {detailLoans.map(({ loan, book, metrics }) => (
                    <div
                      key={loan.id}
                      className="p-3 rounded-xl border border-slate-200/80 flex flex-wrap items-center justify-between gap-2"
                    >
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-[#0C102D] truncate">
                          {book?.title ?? 'Unknown Book'}
                        </p>
                        <p className="text-xs text-slate-500 tabular-nums">
                          Issued {formatDisplayDate(loan.issueDate)} · Due{' '}
                          {formatDisplayDate(loan.dueDate)}
                          {loan.returnDate
                            ? ` · Returned ${formatDisplayDate(loan.returnDate)}`
                            : ''}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        {metrics.calculatedFine > 0 && (
                          <span className="text-xs font-semibold text-rose-600 tabular-nums">
                            {settings.currencySymbol}
                            {metrics.calculatedFine.toFixed(2)}
                          </span>
                        )}
                        <StatusBadge status={metrics.derivedStatus} />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </Modal>

      <ConfirmDialog
        isOpen={Boolean(confirmToggleStudent)}
        onClose={() => setConfirmToggleStudent(null)}
        onConfirm={handleToggleStatus}
        title={
          confirmToggleStudent?.status === 'active'
            ? 'Deactivate Student Account'
            : 'Activate Student Account'
        }
        message={
          confirmToggleStudent?.status === 'active'
            ? `Deactivating ${confirmToggleStudent.name} (${confirmToggleStudent.studentId}) will prevent them from logging in or borrowing new books.`
            : `Re-activate ${confirmToggleStudent?.name}'s library membership?`
        }
        confirmLabel={
          confirmToggleStudent?.status === 'active' ? 'Deactivate' : 'Activate'
        }
        tone={confirmToggleStudent?.status === 'active' ? 'danger' : 'primary'}
      />
    </div>
  );
};
