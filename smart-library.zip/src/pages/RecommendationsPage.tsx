import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { BookOpen, Info, Sparkles } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { BookCard } from '../components/BookCard';
import {
  AnimatedSection,
  EASE_SMOOTH,
  StaggerGrid,
  StaggerItem,
} from '../components/MotionPrimitives';
import { ALL_CATEGORIES } from '../data/seedData';
import { useLibrary } from '../hooks/useLibrary';
import { recommendationService } from '../services/recommendationService';
import { BookCategory } from '../types/library';

export const RecommendationsPage: React.FC = () => {
  const {
    user,
    currentStudent,
    students,
    books,
    loans,
    wishlists,
    currentUserWishlist,
    toggleWishlist,
    updateStudentProfile,
    showToast,
  } = useLibrary();
  const navigate = useNavigate();

  const isAdmin = user?.role === 'admin';
  const [previewStudentId, setPreviewStudentId] = useState<string>('global');

  const activeTargetStudent = useMemo(() => {
    if (!isAdmin) return currentStudent;
    if (previewStudentId === 'global') return undefined;
    return students.find((s) => s.id === previewStudentId);
  }, [currentStudent, isAdmin, previewStudentId, students]);

  const targetWishlist = useMemo(() => {
    if (!activeTargetStudent) return [];
    return isAdmin ? wishlists[activeTargetStudent.id] || [] : currentUserWishlist;
  }, [activeTargetStudent, currentUserWishlist, isAdmin, wishlists]);

  const studentHasHistory = useMemo(() => {
    if (!activeTargetStudent) return false;
    return loans.some((l) => l.studentId === activeTargetStudent.id);
  }, [activeTargetStudent, loans]);

  const recommendations = useMemo(() => {
    if (isAdmin && previewStudentId === 'global') {
      return recommendationService.getGlobalCatalogRecommendations(books, loans, 8);
    }
    return recommendationService.getRecommendationsForStudent(
      activeTargetStudent,
      books,
      loans,
      targetWishlist,
      8
    );
  }, [activeTargetStudent, books, isAdmin, loans, previewStudentId, targetWishlist]);

  const handleToggleInterest = (cat: BookCategory) => {
    if (!currentStudent) return;
    const exists = currentStudent.interests.includes(cat);
    const nextInterests = exists
      ? currentStudent.interests.filter((c) => c !== cat)
      : [...currentStudent.interests, cat];

    const res = updateStudentProfile({
      name: currentStudent.name,
      email: currentStudent.email,
      department: currentStudent.department,
      year: currentStudent.year,
      interests: nextInterests,
      monthlyGoal: currentStudent.monthlyGoal,
      notificationPrefs: currentStudent.notificationPrefs,
    });
    if (res.ok) {
      showToast({
        type: 'info',
        title: 'Interests Updated',
        description: 'Your book recommendations have been refreshed.',
      });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-[#0C102D] tracking-tight">
            Book Recommendations
          </h1>
          <p className="text-sm text-slate-500 mt-1">Discover your next great read</p>
        </div>

        {isAdmin && (
          <div className="flex items-center gap-2.5">
            <label htmlFor="preview-student" className="text-xs font-medium text-slate-500 whitespace-nowrap">
              Preview for:
            </label>
            <select
              id="preview-student"
              value={previewStudentId}
              onChange={(e) => setPreviewStudentId(e.target.value)}
              className="rounded-xl border border-slate-200 bg-white px-3.5 py-2 text-sm text-[#0C102D] focus:outline-none focus:border-[#713BFF]"
            >
              <option value="global">Catalog-Wide Top Picks</option>
              {students.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.studentId})
                </option>
              ))}
            </select>
          </div>
        )}
      </div>

      {/* Featured Purple Card Explaining Rule-Based Suggestions */}
      <AnimatedSection>
        <section className="rounded-2xl bg-brand-gradient text-white p-6 sm:p-8 shadow-xl shadow-[#713BFF]/20 relative overflow-hidden">
        <div
          className="absolute -right-12 -top-12 w-56 h-56 rounded-full bg-white/10 blur-2xl pointer-events-none"
          aria-hidden="true"
        />
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="max-w-2xl space-y-2.5">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-lg bg-white/15 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Rule-Based Recommendation Engine</span>
            </div>

            <h2 className="font-display text-xl sm:text-2xl font-bold [text-wrap:balance]">
              {activeTargetStudent
                ? studentHasHistory
                  ? `Personalized picks for ${activeTargetStudent.name}`
                  : `Starter reading guide for ${activeTargetStudent.name}`
                : 'Catalog-wide curated reading highlights'}
            </h2>

            <p className="text-sm text-indigo-100 leading-relaxed">
              {activeTargetStudent && !studentHasHistory
                ? 'No borrowing history yet — recommendations are matched directly to selected topic interests, highest reader ratings, and foundational titles available now.'
                : 'Suggestions are computed transparently using local borrowing history, adjacent academic categories, wishlist bookmarks, selected topic interests, and catalog ratings.'}
            </p>
          </div>

          <div className="bg-white/12 backdrop-blur-xs rounded-xl p-4 border border-white/15 shrink-0 max-w-xs">
            <div className="flex items-start gap-2.5 text-xs text-indigo-100">
              <Info className="w-4 h-4 shrink-0 mt-0.5 text-white" />
              <p className="leading-relaxed">
                This demo uses deterministic client-side matching rules rather than an external AI service.
              </p>
            </div>
          </div>
        </div>

        {/* Interactive Interest Selector for Students */}
        {!isAdmin && currentStudent && (
          <div className="relative z-10 mt-6 pt-5 border-t border-white/15">
            <p className="text-xs font-semibold text-indigo-100 mb-2.5">
              Your Topic Interests (click to refine recommendations):
            </p>
            <div className="flex flex-wrap gap-2">
              {ALL_CATEGORIES.map((cat) => {
                const selected = currentStudent.interests.includes(cat);
                return (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => handleToggleInterest(cat)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                      selected
                        ? 'bg-white text-[#713BFF] shadow-sm'
                        : 'bg-white/12 text-white hover:bg-white/20 border border-white/15'
                    }`}
                  >
                    {cat}
                  </button>
                );
              })}
            </div>
          </div>
        )}
        </section>
      </AnimatedSection>

      {/* Fallback Starter Notice for Zero History */}
      <AnimatePresence>
        {activeTargetStudent && !studentHasHistory && (
          <motion.div
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.18, ease: EASE_SMOOTH }}
            className="card-surface p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-[#FAF9FF]"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-[#4361EE]/10 text-[#4361EE] flex items-center justify-center shrink-0">
                <BookOpen className="w-4 h-4" />
              </div>
              <p className="text-sm text-slate-600">
                Showing foundational picks based on selected interests while borrowing history is empty.
              </p>
            </div>
            {!isAdmin && (
              <button
                type="button"
                onClick={() => navigate('/books')}
                className="text-xs font-semibold text-[#713BFF] hover:text-[#4361EE] whitespace-nowrap"
              >
                Browse Full Catalog →
              </button>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Recommended Books Grid */}
      <AnimatePresence mode="wait" initial={false}>
        <motion.div
          key={`${previewStudentId}-${currentStudent?.interests.join(',') || 'adm'}`}
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -4 }}
          transition={{ duration: 0.16, ease: EASE_SMOOTH }}
        >
          <StaggerGrid className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {recommendations.map((rec) => (
              <StaggerItem key={rec.book.id}>
                <BookCard
                  book={rec.book}
                  isStudent={!isAdmin}
                  isWishlisted={!isAdmin && currentUserWishlist.includes(rec.book.id)}
                  onToggleWishlist={!isAdmin ? toggleWishlist : undefined}
                  onViewDetails={(b) => navigate(`/books/${b.id}`)}
                  recommendationReason={rec.reason}
                />
              </StaggerItem>
            ))}
          </StaggerGrid>
        </motion.div>
      </AnimatePresence>
    </div>
  );
};
