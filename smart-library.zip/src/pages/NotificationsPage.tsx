import React, { useMemo, useState } from 'react';
import {
  AlertCircle,
  ArrowLeftRight,
  Bell,
  BookCheck,
  CheckCheck,
  Clock,
  Trash2,
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { EmptyState } from '../components/EmptyState';
import { EASE_SMOOTH } from '../components/MotionPrimitives';
import { useLibrary } from '../hooks/useLibrary';
import { NotificationType } from '../types/library';
import { formatRelativeTimestamp } from '../utils/dateUtils';

const TYPE_META: Record<
  NotificationType,
  {
    label: string;
    bg: string;
    text: string;
    icon: React.ComponentType<{ className?: string }>;
  }
> = {
  due_soon: {
    label: 'Due Soon',
    bg: 'bg-amber-50',
    text: 'text-amber-600',
    icon: Clock,
  },
  overdue: {
    label: 'Overdue Notice',
    bg: 'bg-rose-50',
    text: 'text-rose-600',
    icon: AlertCircle,
  },
  issue: {
    label: 'Loan Issued',
    bg: 'bg-[#EEF2FF]',
    text: 'text-[#4361EE]',
    icon: ArrowLeftRight,
  },
  return: {
    label: 'Return Confirmed',
    bg: 'bg-emerald-50',
    text: 'text-emerald-600',
    icon: BookCheck,
  },
  system: {
    label: 'System',
    bg: 'bg-[#F5F4FF]',
    text: 'text-[#713BFF]',
    icon: Bell,
  },
};

export const NotificationsPage: React.FC = () => {
  const {
    notifications,
    unreadNotificationCount,
    markNotificationRead,
    markAllNotificationsRead,
    clearReadNotifications,
    showToast,
  } = useLibrary();

  const [filter, setFilter] = useState<'all' | 'unread'>('all');

  const visibleNotifications = useMemo(() => {
    if (filter === 'unread') return notifications.filter((n) => !n.read);
    return notifications;
  }, [filter, notifications]);

  const readCount = notifications.length - unreadNotificationCount;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-[#0C102D] tracking-tight">
            Notifications
          </h1>
          <p className="text-sm text-slate-500 mt-1 tabular-nums">
            {unreadNotificationCount} unread{' '}
            {unreadNotificationCount === 1 ? 'notification' : 'notifications'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {unreadNotificationCount > 0 && (
            <button
              type="button"
              onClick={() => {
                markAllNotificationsRead();
                showToast({ type: 'success', title: 'All notifications marked as read' });
              }}
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold text-[#713BFF] bg-white border border-indigo-200 hover:bg-[#F5F4FF] transition-colors"
            >
              <CheckCheck className="w-4 h-4" />
              <span>Mark All Read</span>
            </button>
          )}

          {readCount > 0 && (
            <button
              type="button"
              onClick={() => {
                clearReadNotifications();
                showToast({ type: 'info', title: 'Cleared read notifications' });
              }}
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-600 bg-white border border-slate-200 hover:bg-slate-50 transition-colors"
            >
              <Trash2 className="w-4 h-4" />
              <span>Clear Read</span>
            </button>
          )}
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="inline-flex items-center p-1 bg-white rounded-xl border border-indigo-100 shadow-xs">
        {(['all', 'unread'] as const).map((tab) => {
          const active = filter === tab;
          return (
            <button
              key={tab}
              type="button"
              onClick={() => setFilter(tab)}
              className={`relative px-4 py-2 rounded-lg text-xs font-semibold transition-colors ${
                active ? 'text-white' : 'text-slate-600 hover:text-[#0C102D]'
              }`}
            >
              {active && (
                <motion.span
                  layoutId="notifications-filter-pill"
                  transition={{ type: 'spring', stiffness: 420, damping: 32 }}
                  className="absolute inset-0 rounded-lg bg-brand-gradient shadow-sm"
                />
              )}
              <span className="relative z-10">
                {tab === 'all'
                  ? `All (${notifications.length})`
                  : `Unread (${unreadNotificationCount})`}
              </span>
            </button>
          );
        })}
      </div>

      <AnimatePresence mode="wait" initial={false}>
        {visibleNotifications.length === 0 ? (
          <motion.div
            key="notifications-empty"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.16, ease: EASE_SMOOTH }}
          >
            <EmptyState
              icon={Bell}
              title={filter === 'unread' ? 'All caught up!' : 'No notifications yet'}
              description={
                filter === 'unread'
                  ? 'You have read all of your library reminders and confirmations.'
                  : 'Due-soon reminders, overdue notices, and loan confirmations will appear here.'
              }
              actionLabel={
                filter === 'unread' && notifications.length > 0
                  ? 'Show All Notifications'
                  : undefined
              }
              onAction={
                filter === 'unread' && notifications.length > 0
                  ? () => setFilter('all')
                  : undefined
              }
            />
          </motion.div>
        ) : (
          <motion.div
            key={`notifications-list-${filter}`}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.14 }}
            className="space-y-3"
          >
            <AnimatePresence mode="popLayout" initial={false}>
              {visibleNotifications.map((item) => {
                const meta = TYPE_META[item.type] || TYPE_META.system;
                const Icon = meta.icon;

                return (
                  <motion.div
                    key={item.id}
                    layout="position"
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.98 }}
                    transition={{ duration: 0.18, ease: EASE_SMOOTH }}
                    className={`card-surface p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-colors ${
                      !item.read ? 'border-[#713BFF]/30 bg-[#FDFCFF]' : ''
                    }`}
                  >
                    <div className="flex items-start gap-3.5 min-w-0">
                      <div
                        className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${meta.bg} ${meta.text}`}
                      >
                        <Icon className="w-5 h-5" aria-hidden="true" />
                      </div>

                      <div className="min-w-0">
                        <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                          <span className={`font-semibold ${meta.text}`}>{meta.label}</span>
                          <span aria-hidden="true">·</span>
                          <span className="tabular-nums">
                            {formatRelativeTimestamp(item.createdAt)}
                          </span>
                          {!item.read && (
                            <>
                              <span aria-hidden="true">·</span>
                              <span className="font-semibold text-[#713BFF]">Unread</span>
                            </>
                          )}
                        </div>
                        <h2 className="font-display text-sm sm:text-base font-bold text-[#0C102D] mt-1">
                          {item.title}
                        </h2>
                        <p className="text-sm text-slate-600 mt-0.5 leading-relaxed">
                          {item.message}
                        </p>
                      </div>
                    </div>

                    {!item.read && (
                      <button
                        type="button"
                        onClick={() => markNotificationRead(item.id)}
                        className="px-3.5 py-2 rounded-xl text-xs font-semibold text-[#713BFF] bg-[#F5F4FF] hover:bg-[#ECE9FF] transition-colors self-start sm:self-center whitespace-nowrap shrink-0"
                      >
                        Mark as Read
                      </button>
                    )}
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
