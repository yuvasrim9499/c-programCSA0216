import React, { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Heart } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { BookCard } from '../components/BookCard';
import { EmptyState } from '../components/EmptyState';
import { EASE_SMOOTH } from '../components/MotionPrimitives';
import { useLibrary } from '../hooks/useLibrary';

export const WishlistPage: React.FC = () => {
  const { books, currentUserWishlist, toggleWishlist } = useLibrary();
  const navigate = useNavigate();

  const savedBooks = useMemo(
    () => books.filter((b) => currentUserWishlist.includes(b.id)),
    [books, currentUserWishlist]
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl sm:text-3xl font-bold text-[#0C102D] tracking-tight">
          My Wishlist
        </h1>
        <p className="text-sm text-slate-500 mt-1 tabular-nums">
          {savedBooks.length} {savedBooks.length === 1 ? 'book' : 'books'} saved for future reading
        </p>
      </div>

      <AnimatePresence mode="wait" initial={false}>
        {savedBooks.length === 0 ? (
          <motion.div
            key="wishlist-empty"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.18, ease: EASE_SMOOTH }}
          >
            <EmptyState
              icon={Heart}
              title="Your wishlist is empty"
              description="Tap the heart icon on any book in the catalog or recommendations to save it for later."
              actionLabel="Browse Book Catalog"
              onAction={() => navigate('/books')}
            />
          </motion.div>
        ) : (
          <motion.div
            key="wishlist-grid"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5"
          >
            <AnimatePresence mode="popLayout">
              {savedBooks.map((book) => (
                <motion.div
                  key={book.id}
                  layout="position"
                  initial={{ opacity: 0, scale: 0.96 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.92 }}
                  transition={{ duration: 0.18, ease: EASE_SMOOTH }}
                >
                  <BookCard
                    book={book}
                    isStudent
                    isWishlisted
                    onToggleWishlist={toggleWishlist}
                    onViewDetails={(b) => navigate(`/books/${b.id}`)}
                  />
                </motion.div>
              ))}
            </AnimatePresence>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
