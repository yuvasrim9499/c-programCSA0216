import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  AlertCircle,
  Bell,
  BookMarked,
  BookOpen,
  CheckCircle2,
  Clock,
  Heart,
  Pencil,
  Receipt,
} from 'lucide-react';
import { motion } from 'motion/react';
import { BookCard } from '../components/BookCard';
import { ColumnDef, DataTable } from '../components/DataTable';
import { EmptyState } from '../components/EmptyState';
import { FormField, inputBaseClass } from '../components/FormField';
import { Modal } from '../components/Modal';
import {
  AnimatedSection,
  StaggerGrid,
  StaggerItem,
  TabPanelPresence,
} from '../components/MotionPrimitives';
import { StatCard } from '../components/StatCard';
import { StatusBadge } from '../components/StatusBadge';
import { ALL_CATEGORIES } from '../data/seedData';
import { useLibrary } from '../hooks/useLibrary';
import { computeLoanMetrics } from '../services/loanService';
import { BookCategory } from '../types/library';
import {
  formatDisplayDate,
  formatRelativeTimestamp,
  getTodayISO,
} from '../utils/dateUtils';

type ProfileTab = 'current' | 'history' | 'wishlist' | 'fines' | 'notifications';

export const ProfilePage: React.FC = () => {
  const {
    currentStudent,
    books,
    loans,
    notifications,
    settings,
    currentUserWishlist,
    toggleWishlist,
    markNotificationRead,
    updateStudentProfile,
    showToast,
  } = useLibrary();
  const navigate = useNavigate();

  const [activeTab, setActiveTab] = useState<ProfileTab>('current');
  const [editOpen, setEditOpen] = useState(false);

  // Edit profile form state
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [department, setDepartment] = useState('');
  const [year, setYear] = useState('');
  const [monthlyGoal, setMonthlyGoal] = useState('4');
  const [interests, setInterests] = useState<BookCategory[]>([]);
  const [editError, setEditError] = useState<string | null>(null);

  const today = getTodayISO();
  const bookMap = useMemo(() => new Map(books.map((b) => [b.id, b])), [books]);

  useEffect(() => {
    if (!editOpen || !currentStudent) return;
    setEditError(null);
    setName(currentStudent.name);
    setEmail(currentStudent.email);
    setDepartment(currentStudent.department);
    setYear(currentStudent.year);
    setMonthlyGoal(String(currentStudent.monthlyGoal));
    setInterests(currentStudent.interests);
  }, [currentStudent, editOpen]);

  const myLoans = useMemo(() => {
    if (!currentStudent) return [];
    return loans
      .filter((l) => l.studentId === currentStudent.id)
      .sort((a, b) => b.issueDate.localeCompare(a.issueDate));
  }, [currentStudent, loans]);

  const enrichedLoans = useMemo(() => {
    return myLoans.map((loan) => ({
      loan,
      book: bookMap.get(loan.bookId),
      metrics: computeLoanMetrics(loan, settings, today),
    }));
  }, [bookMap, myLoans, settings, today]);

  const currentLoans = enrichedLoans.filter((item) => item.loan.status === 'active');
  const historyLoans = enrichedLoans.filter((item) => item.loan.status === 'returned');
  const fineRows = enrichedLoans.filter((item) => item.metrics.calculatedFine > 0);
  const outstandingFines = currentLoans.reduce(
    (sum, item) => sum + item.metrics.calculatedFine,
    0
  );

  const wishlistBooks = useMemo(
    () => books.filter((b) => currentUserWishlist.includes(b.id)),
    [books, currentUserWishlist]
  );

  const thisMonthBorrowed = useMemo(() => {
    const prefix = today.slice(0, 7);
    return myLoans.filter((l) => l.issueDate.startsWith(prefix)).length;
  }, [myLoans, today]);

  if (!currentStudent) return null;

  const initials = currentStudent.name
    .split(' ')
    .map((n) => n[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();

  const goalPct = Math.min(
    100,
    Math.round((thisMonthBorrowed / Math.max(1, currentStudent.monthlyGoal)) * 100)
  );

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    setEditError(null);
    const res = updateStudentProfile({
      name,
      email,
      department,
      year,
      interests,
      monthlyGoal: Number.parseInt(monthlyGoal, 10) || 3,
      notificationPrefs: currentStudent.notificationPrefs,
    });
    if (!res.ok) {
      setEditError(res.error || 'Could not update profile.');
      return;
    }
    showToast({ type: 'success', title: 'Profile Updated' });
    setEditOpen(false);
  };

  const currentColumns: ColumnDef<(typeof enrichedLoans)[number]>[] = [
    {
      key: 'book',
      header: 'Book Title',
      render: (r) => (
        <button
          type="button"
          onClick={() => navigate(`/books/${r.loan.bookId}`)}
          className="font-semibold text-[#0C102D] hover:text-[#713BFF] text-left"
        >
          {r.book?.title ?? 'Unknown Book'}
        </button>
      ),
    },
    {
      key: 'issue',
      header: 'Issue Date',
      render: (r) => <span className="tabular-nums">{formatDisplayDate(r.loan.issueDate)}</span>,
    },
    {
      key: 'due',
      header: 'Due Date',
      render: (r) => <span className="tabular-nums">{formatDisplayDate(r.loan.dueDate)}</span>,
    },
    {
      key: 'status',
      header: 'Status',
      render: (r) => <StatusBadge status={r.metrics.derivedStatus} />,
    },
    {
      key: 'days',
      header: 'Remaining / Overdue',
      align: 'right',
      render: (r) => (
        <span
          className={`text-xs font-semibold tabular-nums ${
            r.metrics.derivedStatus === 'Overdue'
              ? 'text-rose-600'
              : r.metrics.derivedStatus === 'Due Soon'
              ? 'text-amber-700'
              : 'text-slate-600'
          }`}
        >
          {r.metrics.derivedStatus === 'Overdue'
            ? `${r.metrics.daysOverdue} days overdue`
            : r.metrics.daysRemaining === 0
            ? 'Due today'
            : `${r.metrics.daysRemaining} days left`}
        </span>
      ),
    },
  ];

  const historyColumns: ColumnDef<(typeof enrichedLoans)[number]>[] = [
    {
      key: 'book',
      header: 'Book Title',
      render: (r) => (
        <button
          type="button"
          onClick={() => navigate(`/books/${r.loan.bookId}`)}
          className="font-semibold text-[#0C102D] hover:text-[#713BFF] text-left"
        >
          {r.book?.title ?? 'Unknown Book'}
        </button>
      ),
    },
    {
      key: 'issue',
      header: 'Issue Date',
      render: (r) => <span className="tabular-nums">{formatDisplayDate(r.loan.issueDate)}</span>,
    },
    {
      key: 'return',
      header: 'Return Date',
      render: (r) => (
        <span className="tabular-nums">{formatDisplayDate(r.loan.returnDate)}</span>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      render: (r) => <StatusBadge status={r.metrics.derivedStatus} />,
    },
  ];

  const fineColumns: ColumnDef<(typeof enrichedLoans)[number]>[] = [
    {
      key: 'loanId',
      header: 'Loan ID',
      render: (r) => <span className="font-mono text-xs text-slate-500">{r.loan.id}</span>,
    },
    {
      key: 'book',
      header: 'Book Title',
      render: (r) => (
        <span className="font-semibold text-[#0C102D]">{r.book?.title ?? 'Unknown Book'}</span>
      ),
    },
    {
      key: 'due',
      header: 'Due Date',
      render: (r) => <span className="tabular-nums">{formatDisplayDate(r.loan.dueDate)}</span>,
    },
    {
      key: 'state',
      header: 'State',
      render: (r) => (
        <StatusBadge status={r.loan.status === 'returned' ? 'Returned' : 'Overdue'} />
      ),
    },
    {
      key: 'amount',
      header: 'Fine Amount',
      align: 'right',
      render: (r) => (
        <span className="font-bold text-rose-600 tabular-nums">
          {settings.currencySymbol}
          {r.metrics.calculatedFine.toFixed(2)}
        </span>
      ),
    },
  ];

  const tabs: { key: ProfileTab; label: string; count?: number }[] = [
    { key: 'current', label: 'Current Loans', count: currentLoans.length },
    { key: 'history', label: 'Borrowing History', count: historyLoans.length },
    { key: 'wishlist', label: 'Wishlist', count: wishlistBooks.length },
    { key: 'fines', label: 'Fines', count: fineRows.length },
    { key: 'notifications', label: 'Notifications', count: notifications.length },
  ];

  return (
    <div className="space-y-6">
      {/* Header Profile Card */}
      <section className="card-surface p-6 sm:p-8 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div className="flex flex-col sm:flex-row sm:items-center gap-5">
          <div className="w-20 h-20 rounded-2xl bg-brand-gradient text-white font-display text-2xl font-bold flex items-center justify-center shadow-lg shadow-[#713BFF]/25 shrink-0">
            {initials}
          </div>

          <div>
            <div className="flex flex-wrap items-center gap-2.5">
              <h1 className="font-display text-2xl font-bold text-[#0C102D]">
                {currentStudent.name}
              </h1>
              <span className="font-mono text-xs font-semibold px-2.5 py-1 rounded-lg bg-[#F5F4FF] text-[#713BFF] border border-indigo-100">
                {currentStudent.studentId}
              </span>
            </div>
            <p className="text-sm text-slate-600 mt-1">{currentStudent.email}</p>
            <p className="text-xs text-slate-500 mt-1">
              {currentStudent.department} · {currentStudent.year} · Joined{' '}
              {formatDisplayDate(currentStudent.joinedAt)}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setEditOpen(true)}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold text-white bg-brand-gradient bg-brand-gradient-hover shadow-md shadow-[#713BFF]/20 transition-all self-start lg:self-auto whitespace-nowrap"
        >
          <Pencil className="w-4 h-4" />
          <span>Edit Profile</span>
        </button>
      </section>

      {/* Reading Summary Cards + Monthly Borrowing Goal */}
      <AnimatedSection delay={0.04} className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <StaggerGrid className="lg:col-span-8 grid grid-cols-1 sm:grid-cols-3 gap-4">
          <StaggerItem>
            <StatCard
              title="Active Loans"
              value={currentLoans.length}
              description={`Max ${settings.maxActiveLoansPerStudent} allowed`}
              icon={BookMarked}
              accent="purple"
            />
          </StaggerItem>
          <StaggerItem>
            <StatCard
              title="Books Completed"
              value={historyLoans.length}
              description="Returned to library"
              icon={CheckCircle2}
              accent="blue"
            />
          </StaggerItem>
          <StaggerItem>
            <StatCard
              title="Outstanding Fines"
              value={`${settings.currencySymbol}${outstandingFines.toFixed(2)}`}
              description={outstandingFines > 0 ? 'Settle upon return' : 'Account in good standing'}
              icon={AlertCircle}
              accent={outstandingFines > 0 ? 'rose' : 'emerald'}
            />
          </StaggerItem>
        </StaggerGrid>

        <div className="lg:col-span-4 card-surface p-5 flex flex-col justify-between bg-gradient-to-br from-white to-[#F7F5FF]">
          <div className="flex items-center justify-between gap-2">
            <h2 className="font-display text-base font-bold text-[#0C102D]">
              Monthly Borrowing Goal
            </h2>
            <span className="text-xs font-bold text-[#713BFF] tabular-nums">{goalPct}%</span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            <strong className="text-[#0C102D] tabular-nums">{thisMonthBorrowed}</strong> of{' '}
            <strong className="text-[#0C102D] tabular-nums">{currentStudent.monthlyGoal}</strong>{' '}
            books borrowed this month
          </p>
          <div className="mt-4 w-full h-3 rounded-full bg-indigo-100 overflow-hidden">
            <div
              className="h-full rounded-full bg-brand-gradient transition-all duration-300"
              style={{ width: `${goalPct}%` }}
            />
          </div>
        </div>
      </AnimatedSection>

      {/* Tabs */}
      <AnimatedSection delay={0.08} className="card-surface overflow-hidden">
        <div
          className="px-4 sm:px-6 pt-3 border-b border-slate-100 flex items-center gap-1 overflow-x-auto"
          role="tablist"
          aria-label="Profile sections"
        >
          {tabs.map((t) => {
            const active = activeTab === t.key;
            return (
              <button
                key={t.key}
                type="button"
                role="tab"
                aria-selected={active}
                onClick={() => setActiveTab(t.key)}
                className={`relative px-4 py-3 text-sm font-semibold transition-colors whitespace-nowrap shrink-0 ${
                  active
                    ? 'text-[#713BFF]'
                    : 'text-slate-500 hover:text-[#0C102D]'
                }`}
              >
                {t.label}{' '}
                <span className="ml-1 text-xs font-mono text-slate-400 tabular-nums">
                  ({t.count})
                </span>
                {active && (
                  <motion.span
                    layoutId="profile-tab-underline"
                    transition={{ type: 'spring', stiffness: 450, damping: 34 }}
                    className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#713BFF] rounded-full"
                    aria-hidden="true"
                  />
                )}
              </button>
            );
          })}
        </div>

        <div className="p-4 sm:p-6">
          <TabPanelPresence tabKey={activeTab}>
            {activeTab === 'current' && (
            <DataTable
              columns={currentColumns}
              data={currentLoans}
              rowKey={(r) => r.loan.id}
              emptyState={
                <EmptyState
                  icon={BookOpen}
                  title="No active loans"
                  description="You currently have no books checked out."
                  actionLabel="Browse Catalog"
                  onAction={() => navigate('/books')}
                />
              }
            />
          )}

          {activeTab === 'history' && (
            <DataTable
              columns={historyColumns}
              data={historyLoans}
              rowKey={(r) => r.loan.id}
              emptyState={
                <EmptyState
                  icon={Clock}
                  title="No completed loans yet"
                  description="Returned books will appear here as your reading log."
                />
              }
            />
          )}

          {activeTab === 'wishlist' &&
            (wishlistBooks.length === 0 ? (
              <EmptyState
                icon={Heart}
                title="No saved wishlist books"
                description="Save books from the catalog to keep track of what to read next."
                actionLabel="Explore Catalog"
                onAction={() => navigate('/books')}
              />
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
                {wishlistBooks.map((book) => (
                  <BookCard
                    key={book.id}
                    book={book}
                    isStudent
                    isWishlisted
                    onToggleWishlist={toggleWishlist}
                    onViewDetails={(b) => navigate(`/books/${b.id}`)}
                  />
                ))}
              </div>
            ))}

          {activeTab === 'fines' && (
            <DataTable
              columns={fineColumns}
              data={fineRows}
              rowKey={(r) => r.loan.id}
              emptyState={
                <EmptyState
                  icon={Receipt}
                  title="No fines recorded"
                  description="Great job! You have no overdue or settled late fees."
                />
              }
            />
          )}

          {activeTab === 'notifications' &&
            (notifications.length === 0 ? (
              <EmptyState
                icon={Bell}
                title="No notifications"
                description="Due-soon reminders and borrowing confirmations will appear here."
              />
            ) : (
              <div className="space-y-3">
                {notifications.map((n) => (
                  <div
                    key={n.id}
                    className={`p-4 rounded-xl border flex items-start justify-between gap-4 ${
                      n.read
                        ? 'border-slate-100 bg-white'
                        : 'border-indigo-200 bg-[#FAF9FF]'
                    }`}
                  >
                    <div>
                      <p className="text-sm font-semibold text-[#0C102D]">{n.title}</p>
                      <p className="text-xs text-slate-600 mt-1">{n.message}</p>
                      <p className="text-[11px] text-slate-400 mt-1.5">
                        {formatRelativeTimestamp(n.createdAt)}
                      </p>
                    </div>
                    {!n.read && (
                      <button
                        type="button"
                        onClick={() => markNotificationRead(n.id)}
                        className="px-3 py-1.5 rounded-lg text-xs font-semibold text-[#713BFF] bg-white border border-indigo-200 hover:bg-[#F5F4FF] shrink-0"
                      >
                        Mark Read
                      </button>
                    )}
                  </div>
                ))}
              </div>
            ))}
          </TabPanelPresence>
        </div>
      </AnimatedSection>

      {/* Edit Profile Modal */}
      <Modal
        isOpen={editOpen}
        onClose={() => setEditOpen(false)}
        title="Edit Student Profile"
        subtitle="Update your contact info, monthly reading goal, and topic interests."
        size="lg"
        footer={
          <>
            <button
              type="button"
              onClick={() => setEditOpen(false)}
              className="px-4 py-2 rounded-xl text-sm font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              form="edit-profile-form"
              className="px-5 py-2 rounded-xl text-sm font-semibold text-white bg-brand-gradient"
            >
              Save Profile
            </button>
          </>
        }
      >
        <form id="edit-profile-form" onSubmit={handleSaveProfile} className="space-y-4">
          {editError && (
            <div
              role="alert"
              className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-sm text-rose-700"
            >
              {editError}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <FormField id="prof-name" label="Full Name" required>
              <input
                id="prof-name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className={inputBaseClass}
                required
              />
            </FormField>

            <FormField id="prof-email" label="Email" required>
              <input
                id="prof-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className={inputBaseClass}
                required
              />
            </FormField>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <FormField id="prof-dept" label="Department">
              <input
                id="prof-dept"
                type="text"
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                className={inputBaseClass}
              />
            </FormField>

            <FormField id="prof-year" label="Academic Year">
              <input
                id="prof-year"
                type="text"
                value={year}
                onChange={(e) => setYear(e.target.value)}
                className={inputBaseClass}
              />
            </FormField>

            <FormField id="prof-goal" label="Monthly Goal (books)">
              <input
                id="prof-goal"
                type="number"
                min={1}
                max={30}
                value={monthlyGoal}
                onChange={(e) => setMonthlyGoal(e.target.value)}
                className={`${inputBaseClass} tabular-nums`}
              />
            </FormField>
          </div>

          <div>
            <span className="block text-sm font-medium text-[#1F2442] mb-2">
              Reading Interests
            </span>
            <div className="flex flex-wrap gap-2">
              {ALL_CATEGORIES.map((cat) => {
                const selected = interests.includes(cat);
                return (
                  <button
                    key={cat}
                    type="button"
                    onClick={() =>
                      setInterests((prev) =>
                        prev.includes(cat)
                          ? prev.filter((c) => c !== cat)
                          : [...prev, cat]
                      )
                    }
                    className={`px-3 py-1.5 rounded-xl text-xs font-medium border transition-colors ${
                      selected
                        ? 'bg-[#713BFF] text-white border-[#713BFF]'
                        : 'bg-white text-slate-600 border-slate-200 hover:border-[#713BFF]/40'
                    }`}
                  >
                    {cat}
                  </button>
                );
              })}
            </div>
          </div>
        </form>
      </Modal>
    </div>
  );
};
