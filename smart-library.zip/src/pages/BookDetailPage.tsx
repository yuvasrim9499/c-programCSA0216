import React, { useMemo, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  ArrowLeft,
  ArrowLeftRight,
  BookOpen,
  Calendar,
  Hash,
  Heart,
  Info,
  MapPin,
  Pencil,
  Star,
  Trash2,
} from 'lucide-react';
import { motion } from 'motion/react';
import { BookCover } from '../components/BookCover';
import { BookFormModal } from '../components/BookFormModal';
import { ConfirmDialog } from '../components/ConfirmDialog';
import { EmptyState } from '../components/EmptyState';
import { EASE_SMOOTH } from '../components/MotionPrimitives';
import { StatusBadge } from '../components/StatusBadge';
import { useLibrary } from '../hooks/useLibrary';
import { computeLoanMetrics } from '../services/loanService';
import { formatDisplayDate, getTodayISO } from '../utils/dateUtils';

export const BookDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const {
    user,
    books,
    loans,
    students,
    settings,
    currentUserWishlist,
    toggleWishlist,
    deleteBook,
    showToast,
  } = useLibrary();

  const [editOpen, setEditOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);

  const book = useMemo(() => books.find((b) => b.id === id), [books, id]);
  const isAdmin = user?.role === 'admin';
  const today = getTodayISO();

  const activeBookLoans = useMemo(() => {
    if (!book) return [];
    const studentMap = new Map(students.map((s) => [s.id, s]));
    return loans
      .filter((l) => l.bookId === book.id && l.status === 'active')
      .map((loan) => ({
        loan,
        student: studentMap.get(loan.studentId),
        metrics: computeLoanMetrics(loan, settings, today),
      }));
  }, [book, loans, settings, students, today]);

  if (!book) {
    return (
      <div className="space-y-4">
        <button
          type="button"
          onClick={() => navigate('/books')}
          className="inline-flex items-center gap-2 text-sm font-medium text-slate-600 hover:text-[#713BFF]"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Book Catalog</span>
        </button>
        <EmptyState
          icon={BookOpen}
          title="Book not found"
          description="The requested book could not be located in the Smart Library catalog."
          actionLabel="Browse Catalog"
          onAction={() => navigate('/books')}
        />
      </div>
    );
  }

  const isWishlisted = currentUserWishlist.includes(book.id);
  const isAvailable = book.availableCopies > 0;

  const handleConfirmDelete = () => {
    const res = deleteBook(book.id);
    if (!res.ok) {
      showToast({
        type: 'error',
        title: 'Deletion Blocked',
        description: res.error,
      });
      return;
    }
    showToast({
      type: 'success',
      title: 'Book Deleted',
      description: `"${book.title}" was removed from the catalog.`,
    });
    navigate('/books', { replace: true });
  };

  return (
    <div className="space-y-6">
      <button
        type="button"
        onClick={() => navigate('/books')}
        className="inline-flex items-center gap-2 text-sm font-medium text-slate-600 hover:text-[#713BFF] transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Book Catalog</span>
      </button>

      <div className="card-surface p-6 sm:p-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Larger Cover Artwork */}
          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.24, ease: EASE_SMOOTH }}
            className="lg:col-span-4 xl:col-span-3"
          >
            <div className="aspect-[3/4] w-full max-w-[280px] mx-auto lg:max-w-none rounded-2xl overflow-hidden border border-indigo-100 shadow-lg">
              <BookCover
                src={book.coverUrl}
                title={book.title}
                author={book.author}
                category={book.category}
                className="w-full h-full"
              />
            </div>
          </motion.div>

          {/* Detailed Information */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.24, delay: 0.05, ease: EASE_SMOOTH }}
            className="lg:col-span-8 xl:col-span-9 space-y-6"
          >
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
              <div>
                <div className="flex flex-wrap items-center gap-2.5 text-xs font-medium text-slate-500">
                  <span className="text-[#713BFF] font-semibold">{book.category}</span>
                  <span aria-hidden="true">·</span>
                  <span className="inline-flex items-center gap-1 text-amber-600 font-semibold tabular-nums">
                    <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                    {book.rating.toFixed(1)} rating
                  </span>
                </div>

                <h1 className="font-display text-2xl sm:text-3xl font-bold text-[#0C102D] mt-2">
                  {book.title}
                </h1>
                <p className="text-base text-slate-600 mt-1">by {book.author}</p>
              </div>

              <div className="flex flex-wrap items-center gap-2.5 shrink-0">
                <StatusBadge status={isAvailable ? 'Available' : 'Unavailable'} />

                {!isAdmin && (
                  <button
                    type="button"
                    onClick={() => toggleWishlist(book.id)}
                    className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold border transition-colors ${
                      isWishlisted
                        ? 'bg-rose-50 border-rose-200 text-rose-600'
                        : 'bg-white border-slate-200 text-slate-700 hover:border-rose-200 hover:text-rose-600'
                    }`}
                  >
                    <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-rose-500' : ''}`} />
                    <span>{isWishlisted ? 'Wishlisted' : 'Add to Wishlist'}</span>
                  </button>
                )}

                {isAdmin && (
                  <>
                    <button
                      type="button"
                      onClick={() => navigate(`/issue-return?bookId=${book.id}`)}
                      disabled={!isAvailable}
                      className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold text-white bg-brand-gradient bg-brand-gradient-hover disabled:opacity-45 disabled:pointer-events-none"
                    >
                      <ArrowLeftRight className="w-4 h-4" />
                      <span>Issue Copy</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setEditOpen(true)}
                      className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-sm font-medium border border-slate-200 text-slate-700 hover:border-[#713BFF] hover:text-[#713BFF]"
                    >
                      <Pencil className="w-4 h-4" />
                      <span>Edit</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setDeleteOpen(true)}
                      className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-sm font-medium border border-rose-200 text-rose-600 hover:bg-rose-50"
                    >
                      <Trash2 className="w-4 h-4" />
                      <span>Delete</span>
                    </button>
                  </>
                )}
              </div>
            </div>

            <p className="text-sm sm:text-base text-slate-600 leading-relaxed max-w-3xl">
              {book.description}
            </p>

            {/* Metadata Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-4 border-t border-slate-100">
              <div className="p-3.5 rounded-xl bg-[#FAF9FF] border border-indigo-100/70">
                <div className="flex items-center gap-1.5 text-xs text-slate-500">
                  <Hash className="w-3.5 h-3.5 text-[#713BFF]" />
                  <span>ISBN</span>
                </div>
                <p className="mt-1 text-sm font-mono font-semibold text-[#0C102D] break-all">
                  {book.isbn}
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-[#FAF9FF] border border-indigo-100/70">
                <div className="flex items-center gap-1.5 text-xs text-slate-500">
                  <Calendar className="w-3.5 h-3.5 text-[#4361EE]" />
                  <span>Publication Year</span>
                </div>
                <p className="mt-1 text-sm font-semibold text-[#0C102D] tabular-nums">
                  {book.publicationYear}
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-[#FAF9FF] border border-indigo-100/70">
                <div className="flex items-center gap-1.5 text-xs text-slate-500">
                  <BookOpen className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Availability</span>
                </div>
                <p className="mt-1 text-sm font-semibold text-[#0C102D] tabular-nums">
                  {book.availableCopies} of {book.totalCopies} copies
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-[#FAF9FF] border border-indigo-100/70">
                <div className="flex items-center gap-1.5 text-xs text-slate-500">
                  <MapPin className="w-3.5 h-3.5 text-[#713BFF]" />
                  <span>Shelf Location</span>
                </div>
                <p className="mt-1 text-sm font-mono font-semibold text-[#0C102D]">
                  {book.shelfLocation}
                </p>
              </div>
            </div>

            {/* Friendly Borrowing Guidance for Students */}
            {!isAdmin && (
              <div className="p-4 rounded-xl bg-[#F5F4FF] border border-indigo-100 flex items-start gap-3">
                <Info className="w-5 h-5 text-[#713BFF] shrink-0 mt-0.5" />
                <div className="text-sm text-slate-600 leading-relaxed">
                  {isAvailable ? (
                    <>
                      <strong className="text-[#0C102D]">Ready to borrow:</strong>{' '}
                      {book.availableCopies}{' '}
                      {book.availableCopies === 1 ? 'copy is' : 'copies are'} located at{' '}
                      <span className="font-mono font-semibold text-[#713BFF]">
                        Shelf {book.shelfLocation}
                      </span>
                      . Present your Student ID ({user?.studentId}) at the circulation desk to check it out for{' '}
                      {settings.defaultLoanDays} days.
                    </>
                  ) : (
                    <>
                      <strong className="text-[#0C102D]">Currently checked out:</strong> All{' '}
                      {book.totalCopies} copies are on loan. Add this title to your wishlist to keep track of it when a copy returns.
                    </>
                  )}
                </div>
              </div>
            )}

            {/* Admin-only active borrowers section */}
            {isAdmin && (
              <div className="pt-4 border-t border-slate-100">
                <h2 className="font-display text-base font-bold text-[#0C102D] mb-3">
                  Active Loans for This Title ({activeBookLoans.length})
                </h2>
                {activeBookLoans.length === 0 ? (
                  <p className="text-sm text-slate-500">
                    All {book.totalCopies} copies are currently available on shelf {book.shelfLocation}.
                  </p>
                ) : (
                  <div className="space-y-2">
                    {activeBookLoans.map(({ loan, student, metrics }) => (
                      <div
                        key={loan.id}
                        className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-xl border border-slate-200/80 bg-[#FAF9FF]"
                      >
                        <div>
                          <p className="text-sm font-semibold text-[#0C102D]">
                            {student?.name ?? 'Unknown Student'}{' '}
                            <span className="font-mono text-xs text-slate-400">
                              ({student?.studentId})
                            </span>
                          </p>
                          <p className="text-xs text-slate-500 tabular-nums">
                            Issued {formatDisplayDate(loan.issueDate)} · Due{' '}
                            {formatDisplayDate(loan.dueDate)}
                          </p>
                        </div>
                        <div className="flex items-center gap-2.5">
                          <StatusBadge status={metrics.derivedStatus} />
                          <button
                            type="button"
                            onClick={() =>
                              navigate(`/issue-return?tab=return&loanId=${loan.id}`)
                            }
                            className="px-3 py-1.5 rounded-lg text-xs font-semibold text-[#713BFF] bg-white border border-indigo-200 hover:bg-[#F5F4FF]"
                          >
                            Process Return
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </motion.div>
        </div>
      </div>

      <BookFormModal
        isOpen={editOpen}
        onClose={() => setEditOpen(false)}
        editingBook={book}
      />

      <ConfirmDialog
        isOpen={deleteOpen}
        onClose={() => setDeleteOpen(false)}
        onConfirm={handleConfirmDelete}
        title="Delete Book"
        message={`Remove "${book.title}" from Smart Library? Note: books with active loans (${activeBookLoans.length}) cannot be deleted until all copies are returned.`}
        confirmLabel="Delete Book"
        tone="danger"
      />
    </div>
  );
};
