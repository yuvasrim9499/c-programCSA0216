import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowLeftRight,
  BookOpen,
  CheckCircle2,
  Download,
  Receipt,
} from 'lucide-react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { ColumnDef, DataTable } from '../components/DataTable';
import { EmptyState } from '../components/EmptyState';
import { AnimatedSection, StaggerGrid, StaggerItem } from '../components/MotionPrimitives';
import { StatCard } from '../components/StatCard';
import { useLibrary } from '../hooks/useLibrary';
import { computeLoanMetrics } from '../services/loanService';
import { OverdueReportRow, reportService } from '../services/reportService';
import { addDaysToTodayISO, formatDisplayDate, getTodayISO } from '../utils/dateUtils';

const CHART_COLORS = [
  '#713BFF',
  '#4361EE',
  '#8B5CF6',
  '#3B82F6',
  '#6366F1',
  '#0EA5E9',
  '#A855F7',
];

export const ReportsPage: React.FC = () => {
  const { books, students, loans, settings, showToast } = useLibrary();

  const today = getTodayISO();
  const [startDate, setStartDate] = useState(addDaysToTodayISO(-29));
  const [endDate, setEndDate] = useState(today);

  const applyPreset = (days: number) => {
    setStartDate(addDaysToTodayISO(-(days - 1)));
    setEndDate(today);
  };

  const filteredLoans = useMemo(() => {
    return loans.filter(
      (l) =>
        (l.issueDate >= startDate && l.issueDate <= endDate) ||
        (l.returnDate !== null && l.returnDate >= startDate && l.returnDate <= endDate)
    );
  }, [endDate, loans, startDate]);

  const issuedInRange = useMemo(
    () => loans.filter((l) => l.issueDate >= startDate && l.issueDate <= endDate).length,
    [endDate, loans, startDate]
  );

  const returnedInRange = useMemo(
    () =>
      loans.filter(
        (l) => l.returnDate && l.returnDate >= startDate && l.returnDate <= endDate
      ).length,
    [endDate, loans, startDate]
  );

  const overdueRows = useMemo(
    () => reportService.getOverdueReport(loans, books, students, settings),
    [books, loans, settings, students]
  );

  const totalFinesInRange = useMemo(() => {
    return filteredLoans.reduce((sum, l) => {
      return sum + computeLoanMetrics(l, settings, today).calculatedFine;
    }, 0);
  }, [filteredLoans, settings, today]);

  const activitySeries = useMemo(() => {
    if (!startDate || !endDate || startDate > endDate) return [];
    return reportService.buildActivitySeries(loans, startDate, endDate);
  }, [endDate, loans, startDate]);

  const categoryStats = useMemo(
    () => reportService.getCategoryDistribution(books, filteredLoans),
    [books, filteredLoans]
  );

  const popularBooks = useMemo(
    () => reportService.getPopularBooks(books, filteredLoans, 6),
    [books, filteredLoans]
  );

  const handleExportCSV = () => {
    reportService.exportFilteredLoansCSV(
      filteredLoans,
      books,
      students,
      settings,
      `smart-library-report-${startDate}-to-${endDate}.csv`
    );
    showToast({
      type: 'success',
      title: 'CSV Exported',
      description: `Downloaded ${filteredLoans.length} loan records for ${startDate} – ${endDate}.`,
    });
  };

  const overdueColumns: ColumnDef<OverdueReportRow>[] = [
    {
      key: 'loanId',
      header: 'Loan ID',
      render: (r) => <span className="font-mono text-xs text-slate-500">{r.loan.id}</span>,
    },
    {
      key: 'student',
      header: 'Student',
      render: (r) => (
        <div>
          <p className="font-semibold text-[#0C102D]">{r.student.name}</p>
          <p className="text-xs font-mono text-slate-400">{r.student.studentId}</p>
        </div>
      ),
    },
    {
      key: 'book',
      header: 'Book Title',
      render: (r) => <span className="font-medium text-[#1F2442]">{r.book.title}</span>,
    },
    {
      key: 'dueDate',
      header: 'Due Date',
      render: (r) => (
        <span className="tabular-nums text-slate-600">{formatDisplayDate(r.loan.dueDate)}</span>
      ),
    },
    {
      key: 'daysOverdue',
      header: 'Days Overdue',
      align: 'right',
      render: (r) => (
        <span className="font-semibold text-rose-600 tabular-nums">{r.daysOverdue}d</span>
      ),
    },
    {
      key: 'fine',
      header: 'Accrued Fine',
      align: 'right',
      render: (r) => (
        <span className="font-bold text-rose-600 tabular-nums">
          {settings.currencySymbol}
          {r.fineAmount.toFixed(2)}
        </span>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-[#0C102D] tracking-tight">
            Library Reports & Analytics
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Filter circulation trends by date range, inspect overdue accounts, and export CSV reports
          </p>
        </div>

        <button
          type="button"
          onClick={handleExportCSV}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold text-white bg-brand-gradient bg-brand-gradient-hover shadow-md shadow-[#713BFF]/20 transition-all self-start lg:self-auto whitespace-nowrap"
        >
          <Download className="w-4 h-4" aria-hidden="true" />
          <span>Export CSV ({filteredLoans.length})</span>
        </button>
      </div>

      {/* Date Range Filter */}
      <AnimatedSection delay={0.02}>
        <div className="card-surface p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-semibold text-slate-500 mr-1">Quick Range:</span>
          {[
            { label: 'Last 7 Days', days: 7 },
            { label: 'Last 30 Days', days: 30 },
            { label: 'Last 90 Days', days: 90 },
          ].map((preset) => (
            <button
              key={preset.days}
              type="button"
              onClick={() => applyPreset(preset.days)}
              className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-[#F5F4FF] text-[#713BFF] hover:bg-[#ECE9FF] transition-colors"
            >
              {preset.label}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2">
            <label htmlFor="report-start" className="text-xs font-medium text-slate-500">
              From
            </label>
            <input
              id="report-start"
              type="date"
              value={startDate}
              max={endDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-[#0C102D] tabular-nums focus:outline-none focus:border-[#713BFF]"
            />
          </div>
          <div className="flex items-center gap-2">
            <label htmlFor="report-end" className="text-xs font-medium text-slate-500">
              To
            </label>
            <input
              id="report-end"
              type="date"
              value={endDate}
              min={startDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-[#0C102D] tabular-nums focus:outline-none focus:border-[#713BFF]"
            />
          </div>
        </div>
        </div>
      </AnimatedSection>

      {/* Summary Totals */}
      <StaggerGrid className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <StaggerItem>
          <StatCard
            title="Issued in Range"
            value={issuedInRange}
            description={`${formatDisplayDate(startDate)} – ${formatDisplayDate(endDate)}`}
            icon={ArrowLeftRight}
            accent="purple"
          />
        </StaggerItem>
        <StaggerItem>
          <StatCard
            title="Returned in Range"
            value={returnedInRange}
            description="Completed loan returns"
            icon={CheckCircle2}
            accent="blue"
          />
        </StaggerItem>
        <StaggerItem>
          <StatCard
            title="Currently Overdue"
            value={overdueRows.length}
            description="Active loans past due date"
            icon={AlertTriangle}
            accent="rose"
          />
        </StaggerItem>
        <StaggerItem>
          <StatCard
            title="Fines in Range"
            value={`${settings.currencySymbol}${totalFinesInRange.toFixed(2)}`}
            description="Paid + currently accrued"
            icon={Receipt}
            accent="amber"
          />
        </StaggerItem>
      </StaggerGrid>

      {/* Charts */}
      <AnimatedSection delay={0.06}>
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        <section className="xl:col-span-7 card-surface p-5 sm:p-6">
          <h2 className="font-display text-lg font-bold text-[#0C102D]">
            Issued vs. Returned Books
          </h2>
          <p className="text-xs text-slate-500 mt-0.5 mb-4">
            Circulation volume across the selected date interval
          </p>

          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={activitySeries} margin={{ top: 8, right: 12, left: -16, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#ECE9FF" vertical={false} />
                <XAxis
                  dataKey="label"
                  tick={{ fill: '#64748B', fontSize: 12 }}
                  axisLine={{ stroke: '#E2E8F0' }}
                  tickLine={false}
                />
                <YAxis
                  allowDecimals={false}
                  tick={{ fill: '#64748B', fontSize: 12 }}
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip
                  contentStyle={{
                    borderRadius: '12px',
                    border: '1px solid rgba(113,59,255,0.15)',
                    fontSize: '12px',
                  }}
                />
                <Legend wrapperStyle={{ fontSize: '12px' }} />
                <Bar dataKey="issued" name="Issued" fill="#713BFF" radius={[6, 6, 0, 0]} />
                <Bar dataKey="returned" name="Returned" fill="#4361EE" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </section>

        <section className="xl:col-span-5 card-surface p-5 sm:p-6">
          <h2 className="font-display text-lg font-bold text-[#0C102D]">
            Category Distribution
          </h2>
          <p className="text-xs text-slate-500 mt-0.5 mb-4">
            Catalog titles and copies grouped by subject category
          </p>

          <div className="h-56 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryStats}
                  dataKey="bookCount"
                  nameKey="category"
                  cx="50%"
                  cy="50%"
                  innerRadius={52}
                  outerRadius={84}
                  paddingAngle={3}
                >
                  {categoryStats.map((entry, idx) => (
                    <Cell
                      key={entry.category}
                      fill={CHART_COLORS[idx % CHART_COLORS.length]}
                    />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    borderRadius: '12px',
                    border: '1px solid rgba(113,59,255,0.15)',
                    fontSize: '12px',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-2 gap-2 mt-2">
            {categoryStats.map((cat, idx) => (
              <div key={cat.category} className="flex items-center justify-between text-xs gap-2">
                <div className="flex items-center gap-2 min-w-0">
                  <span
                    className="w-2.5 h-2.5 rounded-xs shrink-0"
                    style={{ backgroundColor: CHART_COLORS[idx % CHART_COLORS.length] }}
                    aria-hidden="true"
                  />
                  <span className="text-slate-600 truncate">{cat.category}</span>
                </div>
                <span className="font-semibold text-[#0C102D] tabular-nums shrink-0">
                  {cat.bookCount}
                </span>
              </div>
            ))}
          </div>
        </section>
        </div>
      </AnimatedSection>

      {/* Most Borrowed Books & Overdue Report */}
      <AnimatedSection delay={0.1}>
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        <section className="xl:col-span-5 card-surface p-5 sm:p-6">
          <h2 className="font-display text-lg font-bold text-[#0C102D]">
            Most Borrowed Books (Filtered)
          </h2>
          <p className="text-xs text-slate-500 mt-0.5 mb-4">
            Top titles within the selected date window
          </p>

          <div className="space-y-3">
            {popularBooks.map((item, index) => (
              <div
                key={item.book.id}
                className="flex items-center justify-between gap-3 p-3 rounded-xl bg-[#FAF9FF] border border-indigo-100/70"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <span className="w-7 h-7 rounded-lg bg-white border border-indigo-100 text-xs font-bold text-[#713BFF] flex items-center justify-center tabular-nums shrink-0">
                    {index + 1}
                  </span>
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-[#0C102D] truncate">
                      {item.book.title}
                    </p>
                    <p className="text-xs text-slate-500 truncate">{item.book.category}</p>
                  </div>
                </div>
                <span className="text-xs font-bold text-[#4361EE] tabular-nums shrink-0">
                  {item.borrowCount} {item.borrowCount === 1 ? 'loan' : 'loans'}
                </span>
              </div>
            ))}
          </div>
        </section>

        <section className="xl:col-span-7 card-surface overflow-hidden">
          <div className="px-5 sm:px-6 py-4 border-b border-slate-100">
            <h2 className="font-display text-lg font-bold text-[#0C102D]">
              Overdue Loans Report
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              All currently active loans past their due date
            </p>
          </div>

          <DataTable
            columns={overdueColumns}
            data={overdueRows}
            rowKey={(r) => r.loan.id}
            emptyState={
              <div className="p-6">
                <EmptyState
                  icon={BookOpen}
                  title="No overdue loans"
                  description="There are zero overdue books across all active student accounts."
                />
              </div>
            }
          />
        </section>
        </div>
      </AnimatedSection>
    </div>
  );
};
