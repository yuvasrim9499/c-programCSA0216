import React from 'react';
import { useLibrary } from '../hooks/useLibrary';
import { AdminDashboard } from './AdminDashboard';
import { StudentDashboard } from './StudentDashboard';

export const DashboardPage: React.FC = () => {
  const { user } = useLibrary();

  if (!user) return null;
  return user.role === 'admin' ? <AdminDashboard /> : <StudentDashboard />;
};
