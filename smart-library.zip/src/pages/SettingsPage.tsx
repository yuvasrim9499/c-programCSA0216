import React, { useEffect, useState } from 'react';
import { RotateCcw, Save, ShieldAlert } from 'lucide-react';
import { ConfirmDialog } from '../components/ConfirmDialog';
import { FormField, inputBaseClass } from '../components/FormField';
import { AnimatedSection } from '../components/MotionPrimitives';
import { ALL_CATEGORIES } from '../data/seedData';
import { useLibrary } from '../hooks/useLibrary';
import { BookCategory } from '../types/library';

export const SettingsPage: React.FC = () => {
  const {
    user,
    currentStudent,
    settings,
    updateAdminSettings,
    updateStudentProfile,
    resetDemoData,
    showToast,
  } = useLibrary();

  // Admin settings state
  const [libraryName, setLibraryName] = useState(settings.libraryName);
  const [defaultLoanDays, setDefaultLoanDays] = useState(String(settings.defaultLoanDays));
  const [maxActiveLoans, setMaxActiveLoans] = useState(
    String(settings.maxActiveLoansPerStudent)
  );
  const [dailyFine, setDailyFine] = useState(String(settings.dailyOverdueFine));
  const [currencySymbol, setCurrencySymbol] = useState(settings.currencySymbol);
  const [dueSoonDays, setDueSoonDays] = useState(String(settings.dueSoonWindowDays));
  const [adminError, setAdminError] = useState<string | null>(null);

  // Student settings state
  const [stuName, setStuName] = useState(currentStudent?.name || '');
  const [stuEmail, setStuEmail] = useState(currentStudent?.email || '');
  const [stuDept, setStuDept] = useState(currentStudent?.department || '');
  const [stuYear, setStuYear] = useState(currentStudent?.year || '');
  const [stuGoal, setStuGoal] = useState(String(currentStudent?.monthlyGoal || 3));
  const [stuInterests, setStuInterests] = useState<BookCategory[]>(
    currentStudent?.interests || []
  );
  const [prefDueSoon, setPrefDueSoon] = useState(
    currentStudent?.notificationPrefs.dueSoon ?? true
  );
  const [prefOverdue, setPrefOverdue] = useState(
    currentStudent?.notificationPrefs.overdue ?? true
  );
  const [prefConfirmations, setPrefConfirmations] = useState(
    currentStudent?.notificationPrefs.confirmations ?? true
  );
  const [studentError, setStudentError] = useState<string | null>(null);

  const [resetOpen, setResetOpen] = useState(false);

  useEffect(() => {
    setLibraryName(settings.libraryName);
    setDefaultLoanDays(String(settings.defaultLoanDays));
    setMaxActiveLoans(String(settings.maxActiveLoansPerStudent));
    setDailyFine(String(settings.dailyOverdueFine));
    setCurrencySymbol(settings.currencySymbol);
    setDueSoonDays(String(settings.dueSoonWindowDays));
  }, [settings]);

  useEffect(() => {
    if (!currentStudent) return;
    setStuName(currentStudent.name);
    setStuEmail(currentStudent.email);
    setStuDept(currentStudent.department);
    setStuYear(currentStudent.year);
    setStuGoal(String(currentStudent.monthlyGoal));
    setStuInterests(currentStudent.interests);
    setPrefDueSoon(currentStudent.notificationPrefs.dueSoon);
    setPrefOverdue(currentStudent.notificationPrefs.overdue);
    setPrefConfirmations(currentStudent.notificationPrefs.confirmations);
  }, [currentStudent]);

  if (!user) return null;

  const handleSaveAdmin = (e: React.FormEvent) => {
    e.preventDefault();
    setAdminError(null);
    const res = updateAdminSettings({
      libraryName,
      defaultLoanDays: Number.parseInt(defaultLoanDays, 10),
      maxActiveLoansPerStudent: Number.parseInt(maxActiveLoans, 10),
      dailyOverdueFine: Number.parseFloat(dailyFine),
      currencySymbol,
      dueSoonWindowDays: Number.parseInt(dueSoonDays, 10),
    });

    if (!res.ok) {
      setAdminError(res.error || 'Could not save settings.');
      return;
    }

    showToast({
      type: 'success',
      title: 'Library Settings Saved',
      description: 'Borrowing rules and fine calculations have been updated.',
    });
  };

  const handleSaveStudent = (e: React.FormEvent) => {
    e.preventDefault();
    setStudentError(null);
    const res = updateStudentProfile({
      name: stuName,
      email: stuEmail,
      department: stuDept,
      year: stuYear,
      interests: stuInterests,
      monthlyGoal: Number.parseInt(stuGoal, 10) || 3,
      notificationPrefs: {
        dueSoon: prefDueSoon,
        overdue: prefOverdue,
        confirmations: prefConfirmations,
      },
    });

    if (!res.ok) {
      setStudentError(res.error || 'Could not save preferences.');
      return;
    }

    showToast({
      type: 'success',
      title: 'Preferences Saved',
      description: 'Your profile and notification settings are updated.',
    });
  };

  const handleResetDemo = () => {
    resetDemoData();
    showToast({
      type: 'info',
      title: 'Demo Data Reset',
      description: 'Restored initial books, students, loans, and settings.',
    });
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h1 className="font-display text-2xl sm:text-3xl font-bold text-[#0C102D] tracking-tight">
          Settings
        </h1>
        <p className="text-sm text-slate-500 mt-1">
          {user.role === 'admin'
            ? 'Configure library circulation policies, overdue fines, and demo storage.'
            : 'Manage your profile details, reading goal, and notification preferences.'}
        </p>
      </div>

      <AnimatedSection delay={0.02}>
        {user.role === 'admin' ? (
          <form onSubmit={handleSaveAdmin} className="card-surface p-6 space-y-5">
          <div>
            <h2 className="font-display text-lg font-bold text-[#0C102D]">
              Library & Circulation Configuration
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Changes immediately affect loan due dates, borrowing limits, and fine calculations.
            </p>
          </div>

          {adminError && (
            <div
              role="alert"
              className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-sm text-rose-700"
            >
              {adminError}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <FormField id="set-lib-name" label="Library Name" required>
              <input
                id="set-lib-name"
                type="text"
                value={libraryName}
                onChange={(e) => setLibraryName(e.target.value)}
                className={inputBaseClass}
                required
              />
            </FormField>

            <FormField id="set-currency" label="Currency Label / Symbol" required>
              <input
                id="set-currency"
                type="text"
                value={currencySymbol}
                onChange={(e) => setCurrencySymbol(e.target.value)}
                placeholder="₹"
                className={inputBaseClass}
                required
              />
            </FormField>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <FormField id="set-loan-days" label="Default Loan (Days)" required>
              <input
                id="set-loan-days"
                type="number"
                min={1}
                max={180}
                value={defaultLoanDays}
                onChange={(e) => setDefaultLoanDays(e.target.value)}
                className={`${inputBaseClass} tabular-nums`}
                required
              />
            </FormField>

            <FormField id="set-max-loans" label="Max Loans / Student" required>
              <input
                id="set-max-loans"
                type="number"
                min={1}
                max={25}
                value={maxActiveLoans}
                onChange={(e) => setMaxActiveLoans(e.target.value)}
                className={`${inputBaseClass} tabular-nums`}
                required
              />
            </FormField>

            <FormField id="set-daily-fine" label="Daily Overdue Fine" required>
              <input
                id="set-daily-fine"
                type="number"
                step="0.25"
                min={0}
                max={100}
                value={dailyFine}
                onChange={(e) => setDailyFine(e.target.value)}
                className={`${inputBaseClass} tabular-nums`}
                required
              />
            </FormField>

            <FormField id="set-due-soon" label="Due-Soon Alert (Days)">
              <input
                id="set-due-soon"
                type="number"
                min={1}
                max={14}
                value={dueSoonDays}
                onChange={(e) => setDueSoonDays(e.target.value)}
                className={`${inputBaseClass} tabular-nums`}
              />
            </FormField>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold text-white bg-brand-gradient bg-brand-gradient-hover shadow-md shadow-[#713BFF]/20 transition-all"
            >
              <Save className="w-4 h-4" />
              <span>Save Library Settings</span>
            </button>
          </div>
        </form>
      ) : (
        <form onSubmit={handleSaveStudent} className="card-surface p-6 space-y-5">
          <div>
            <h2 className="font-display text-lg font-bold text-[#0C102D]">
              Account & Notification Preferences
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Customize your reading profile and which reminders appear in your inbox.
            </p>
          </div>

          {studentError && (
            <div
              role="alert"
              className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-sm text-rose-700"
            >
              {studentError}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <FormField id="stu-set-name" label="Full Name" required>
              <input
                id="stu-set-name"
                type="text"
                value={stuName}
                onChange={(e) => setStuName(e.target.value)}
                className={inputBaseClass}
                required
              />
            </FormField>

            <FormField id="stu-set-email" label="Email Address" required>
              <input
                id="stu-set-email"
                type="email"
                value={stuEmail}
                onChange={(e) => setStuEmail(e.target.value)}
                className={inputBaseClass}
                required
              />
            </FormField>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <FormField id="stu-set-dept" label="Department">
              <input
                id="stu-set-dept"
                type="text"
                value={stuDept}
                onChange={(e) => setStuDept(e.target.value)}
                className={inputBaseClass}
              />
            </FormField>

            <FormField id="stu-set-year" label="Academic Year">
              <input
                id="stu-set-year"
                type="text"
                value={stuYear}
                onChange={(e) => setStuYear(e.target.value)}
                className={inputBaseClass}
              />
            </FormField>

            <FormField id="stu-set-goal" label="Monthly Reading Goal">
              <input
                id="stu-set-goal"
                type="number"
                min={1}
                max={30}
                value={stuGoal}
                onChange={(e) => setStuGoal(e.target.value)}
                className={`${inputBaseClass} tabular-nums`}
              />
            </FormField>
          </div>

          <div>
            <span className="block text-sm font-medium text-[#1F2442] mb-2">
              Topic Interests
            </span>
            <div className="flex flex-wrap gap-2">
              {ALL_CATEGORIES.map((cat) => {
                const selected = stuInterests.includes(cat);
                return (
                  <button
                    key={cat}
                    type="button"
                    onClick={() =>
                      setStuInterests((prev) =>
                        prev.includes(cat)
                          ? prev.filter((c) => c !== cat)
                          : [...prev, cat]
                      )
                    }
                    className={`px-3 py-1.5 rounded-xl text-xs font-medium border transition-colors ${
                      selected
                        ? 'bg-[#713BFF] text-white border-[#713BFF]'
                        : 'bg-white text-slate-600 border-slate-200 hover:border-[#713BFF]/40'
                    }`}
                  >
                    {cat}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="pt-2 border-t border-slate-100 space-y-3">
            <h3 className="text-sm font-semibold text-[#0C102D]">
              Notification Preferences
            </h3>

            <label className="flex items-center justify-between gap-4 p-3 rounded-xl bg-[#FAF9FF] border border-indigo-100 cursor-pointer">
              <div>
                <p className="text-sm font-medium text-[#0C102D]">Due-Soon Reminders</p>
                <p className="text-xs text-slate-500">
                  Receive alerts before a borrowed book reaches its due date.
                </p>
              </div>
              <input
                type="checkbox"
                checked={prefDueSoon}
                onChange={(e) => setPrefDueSoon(e.target.checked)}
                className="w-4 h-4 rounded text-[#713BFF] focus:ring-[#713BFF]"
              />
            </label>

            <label className="flex items-center justify-between gap-4 p-3 rounded-xl bg-[#FAF9FF] border border-indigo-100 cursor-pointer">
              <div>
                <p className="text-sm font-medium text-[#0C102D]">Overdue Notices</p>
                <p className="text-xs text-slate-500">
                  Receive notices when a loan becomes overdue and fines begin accruing.
                </p>
              </div>
              <input
                type="checkbox"
                checked={prefOverdue}
                onChange={(e) => setPrefOverdue(e.target.checked)}
                className="w-4 h-4 rounded text-[#713BFF] focus:ring-[#713BFF]"
              />
            </label>

            <label className="flex items-center justify-between gap-4 p-3 rounded-xl bg-[#FAF9FF] border border-indigo-100 cursor-pointer">
              <div>
                <p className="text-sm font-medium text-[#0C102D]">
                  Issue & Return Confirmations
                </p>
                <p className="text-xs text-slate-500">
                  Receive confirmation logs whenever books are issued or returned.
                </p>
              </div>
              <input
                type="checkbox"
                checked={prefConfirmations}
                onChange={(e) => setPrefConfirmations(e.target.checked)}
                className="w-4 h-4 rounded text-[#713BFF] focus:ring-[#713BFF]"
              />
            </label>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold text-white bg-brand-gradient bg-brand-gradient-hover shadow-md shadow-[#713BFF]/20 transition-all"
            >
              <Save className="w-4 h-4" />
              <span>Save Preferences</span>
            </button>
          </div>
        </form>
        )}
      </AnimatedSection>

      {/* Reset Demo Data Section */}
      <AnimatedSection delay={0.06}>
        <section className="card-surface p-6 border-rose-200/70">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center shrink-0">
                <ShieldAlert className="w-5 h-5" />
              </div>
              <div>
                <h2 className="font-display text-base font-bold text-[#0C102D]">
                  Reset Demo Data
                </h2>
                <p className="text-xs text-slate-500 mt-1 max-w-xl leading-relaxed">
                  Restore the browser local-storage database back to the initial seeded catalog (18 books, 8 students, sample loans, and default settings). All edits made during this session will be overwritten.
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setResetOpen(true)}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold text-rose-600 bg-rose-50 border border-rose-200 hover:bg-rose-100 transition-colors self-start sm:self-center whitespace-nowrap shrink-0"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Reset Demo Data</span>
            </button>
          </div>
        </section>
      </AnimatedSection>

      <ConfirmDialog
        isOpen={resetOpen}
        onClose={() => setResetOpen(false)}
        onConfirm={handleResetDemo}
        title="Reset All Demo Data?"
        message="This will clear all local-storage changes and re-seed the Smart Library catalog, students, loans, and settings. This action cannot be undone."
        confirmLabel="Reset Demo Data"
        tone="danger"
      />
    </div>
  );
};
