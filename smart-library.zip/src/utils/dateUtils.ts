/**
 * Date utilities operating on local calendar dates (YYYY-MM-DD)
 * so seeded and runtime loan calculations stay consistent across timezones.
 */

export function formatLocalDateISO(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function getTodayISO(): string {
  return formatLocalDateISO(new Date());
}

export function parseLocalDate(isoDate: string): Date {
  const [year, month, day] = isoDate.split('-').map(Number);
  return new Date(year, (month || 1) - 1, day || 1, 0, 0, 0, 0);
}

export function addDaysISO(baseIso: string, deltaDays: number): string {
  const d = parseLocalDate(baseIso);
  d.setDate(d.getDate() + deltaDays);
  return formatLocalDateISO(d);
}

export function addDaysToTodayISO(deltaDays: number): string {
  return addDaysISO(getTodayISO(), deltaDays);
}

/**
 * Returns (dateB - dateA) in whole calendar days.
 * Positive if dateB is after dateA.
 */
export function diffDaysISO(dateAIso: string, dateBIso: string): number {
  const a = parseLocalDate(dateAIso);
  const b = parseLocalDate(dateBIso);
  const msPerDay = 1000 * 60 * 60 * 24;
  return Math.round((b.getTime() - a.getTime()) / msPerDay);
}

export function formatDisplayDate(isoDate: string | null | undefined): string {
  if (!isoDate) return '—';
  const datePart = isoDate.includes('T') ? isoDate.split('T')[0] : isoDate;
  const d = parseLocalDate(datePart);
  return d.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}

export function formatShortDate(isoDate: string): string {
  const d = parseLocalDate(isoDate);
  return d.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
  });
}

export function formatRelativeTimestamp(isoTimestamp: string): string {
  const then = new Date(isoTimestamp).getTime();
  const now = Date.now();
  const diffMins = Math.max(0, Math.round((now - then) / 60000));
  if (diffMins < 1) return 'Just now';
  if (diffMins < 60) return `${diffMins}m ago`;
  const diffHours = Math.round(diffMins / 60);
  if (diffHours < 24) return `${diffHours}h ago`;
  const diffDays = Math.round(diffHours / 24);
  if (diffDays < 7) return `${diffDays}d ago`;
  return new Date(isoTimestamp).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
  });
}
