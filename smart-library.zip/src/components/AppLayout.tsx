import React, { useEffect, useState } from 'react';
import { useLocation, useOutlet } from 'react-router-dom';
import { AnimatePresence, motion } from 'motion/react';
import { Header } from './Header';
import { EASE_SMOOTH } from './MotionPrimitives';
import { Sidebar } from './Sidebar';

const FrozenOutlet: React.FC<{ element: React.ReactNode }> = ({ element }) => {
  const [frozenElement] = useState(() => element);
  return <>{frozenElement}</>;
};

export const AppLayout: React.FC = () => {
  const location = useLocation();
  const currentOutlet = useOutlet();

  const [collapsed, setCollapsed] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return window.innerWidth >= 768 && window.innerWidth < 1100;
    }
    return false;
  });
  const [mobileOpen, setMobileOpen] = useState(false);

  // Auto-collapse on tablet resize
  useEffect(() => {
    const onResize = () => {
      if (window.innerWidth >= 768 && window.innerWidth < 1024) {
        setCollapsed(true);
      } else if (window.innerWidth >= 1280) {
        setCollapsed(false);
      }
    };
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);

  return (
    <div className="min-h-screen bg-[#F5F4FF] text-[#111827] flex">
      <Sidebar
        collapsed={collapsed}
        mobileOpen={mobileOpen}
        onCloseMobile={() => setMobileOpen(false)}
      />

      <div
        className={`flex-1 flex flex-col min-w-0 transition-all duration-200 ${
          collapsed ? 'md:pl-[78px]' : 'md:pl-[256px]'
        }`}
      >
        <Header
          collapsed={collapsed}
          onToggleCollapse={() => setCollapsed((c) => !c)}
          onOpenMobileMenu={() => setMobileOpen(true)}
        />

        <main className="flex-1 px-4 sm:px-6 lg:px-8 py-6 max-w-[1440px] w-full mx-auto">
          <AnimatePresence
            mode="wait"
            initial={false}
            onExitComplete={() => window.scrollTo({ top: 0, behavior: 'instant' })}
          >
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.2, ease: EASE_SMOOTH }}
            >
              <FrozenOutlet element={currentOutlet} />
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
};
