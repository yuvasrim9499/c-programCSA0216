import React, { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Bell,
  ChevronDown,
  LogOut,
  Menu,
  PanelLeftClose,
  PanelLeftOpen,
  Search,
  Settings,
  UserCircle,
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { useLibrary } from '../hooks/useLibrary';

interface HeaderProps {
  collapsed: boolean;
  onToggleCollapse: () => void;
  onOpenMobileMenu: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  collapsed,
  onToggleCollapse,
  onOpenMobileMenu,
}) => {
  const { user, unreadNotificationCount, logout, showToast } = useLibrary();
  const [searchValue, setSearchValue] = useState('');
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(false);
      }
    };
    const handleKeyShortcut = (e: KeyboardEvent) => {
      if (
        e.key === '/' &&
        document.activeElement?.tagName !== 'INPUT' &&
        document.activeElement?.tagName !== 'TEXTAREA' &&
        document.activeElement?.tagName !== 'SELECT'
      ) {
        e.preventDefault();
        searchInputRef.current?.focus();
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    window.addEventListener('keydown', handleKeyShortcut);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      window.removeEventListener('keydown', handleKeyShortcut);
    };
  }, []);

  if (!user) return null;

  const initials = user.name
    .split(' ')
    .map((n) => n[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const q = searchValue.trim();
    navigate(q ? `/books?q=${encodeURIComponent(q)}` : '/books');
  };

  const handleLogout = () => {
    setMenuOpen(false);
    logout();
    showToast({ type: 'info', title: 'Signed out' });
    navigate('/login', { replace: true });
  };

  return (
    <header className="sticky top-0 z-20 h-16 bg-white/95 backdrop-blur-md border-b border-indigo-100/80 px-4 sm:px-6 flex items-center justify-between gap-4">
      <div className="flex items-center gap-3 flex-1 min-w-0">
        {/* Mobile Drawer Toggle */}
        <button
          type="button"
          onClick={onOpenMobileMenu}
          aria-label="Open navigation menu"
          className="md:hidden p-2 rounded-xl text-slate-600 hover:text-[#0C102D] hover:bg-[#F5F4FF] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#713BFF]"
        >
          <Menu className="w-5 h-5" />
        </button>

        {/* Desktop / Tablet Sidebar Collapse Toggle */}
        <button
          type="button"
          onClick={onToggleCollapse}
          aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          className="hidden md:inline-flex p-2 rounded-xl text-slate-600 hover:text-[#713BFF] hover:bg-[#F5F4FF] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#713BFF]"
        >
          {collapsed ? (
            <PanelLeftOpen className="w-5 h-5" />
          ) : (
            <PanelLeftClose className="w-5 h-5" />
          )}
        </button>

        {/* Global Catalog Quick Search */}
        <form onSubmit={handleSearchSubmit} className="relative flex-1 max-w-md hidden sm:block">
          <Search
            className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
            aria-hidden="true"
          />
          <label htmlFor="header-global-search" className="sr-only">
            Search catalog by book title, author, or ISBN
          </label>
          <input
            ref={searchInputRef}
            id="header-global-search"
            type="search"
            value={searchValue}
            onChange={(e) => setSearchValue(e.target.value)}
            placeholder="Search books, authors, or ISBN... (Press /)"
            className="w-full pl-10 pr-4 py-2 rounded-xl border border-slate-200 bg-[#FAF9FF] text-sm text-[#111827] placeholder:text-slate-400 focus:outline-none focus:bg-white focus:border-[#713BFF] focus:ring-3 focus:ring-[#713BFF]/15 transition-all"
          />
        </form>
      </div>

      {/* Right Actions: Mobile Search shortcut, Notifications & Profile Menu */}
      <div className="flex items-center gap-2 sm:gap-3 shrink-0">
        <button
          type="button"
          onClick={() => navigate('/books')}
          aria-label="Search books"
          className="sm:hidden p-2.5 rounded-xl text-slate-600 hover:text-[#713BFF] hover:bg-[#F5F4FF] transition-colors"
        >
          <Search className="w-5 h-5" />
        </button>

        <button
          type="button"
          onClick={() => navigate('/notifications')}
          aria-label={`Notifications (${unreadNotificationCount} unread)`}
          className="relative p-2.5 rounded-xl text-slate-600 hover:text-[#713BFF] hover:bg-[#F5F4FF] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#713BFF]"
        >
          <Bell className="w-5 h-5" />
          {unreadNotificationCount > 0 && (
            <span className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] px-1 rounded-md bg-brand-gradient text-white text-[10px] font-bold flex items-center justify-center tabular-nums shadow-sm">
              {unreadNotificationCount > 9 ? '9+' : unreadNotificationCount}
            </span>
          )}
        </button>

        <div className="relative" ref={menuRef}>
          <button
            type="button"
            onClick={() => setMenuOpen((prev) => !prev)}
            aria-expanded={menuOpen}
            aria-haspopup="menu"
            className="flex items-center gap-2.5 pl-2 pr-3 py-1.5 rounded-xl border border-slate-200/80 hover:border-[#713BFF]/30 bg-white hover:bg-[#FAF9FF] transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#713BFF]"
          >
            <div className="w-8 h-8 rounded-lg bg-brand-gradient text-white font-display font-bold text-xs flex items-center justify-center shrink-0">
              {initials}
            </div>
            <div className="hidden md:block text-left">
              <p className="text-xs font-semibold text-[#0C102D] leading-tight whitespace-nowrap">
                {user.name}
              </p>
              <p className="text-[11px] text-slate-500 leading-tight whitespace-nowrap">
                {user.role === 'admin' ? 'Admin / Librarian' : 'Student'}
              </p>
            </div>
            <ChevronDown
              className={`w-4 h-4 text-slate-400 shrink-0 transition-transform duration-150 ${
                menuOpen ? 'rotate-180' : ''
              }`}
              aria-hidden="true"
            />
          </button>

          <AnimatePresence>
            {menuOpen && (
              <motion.div
                initial={{ opacity: 0, y: 6, scale: 0.97 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 6, scale: 0.97 }}
                transition={{ duration: 0.15, ease: [0.16, 1, 0.3, 1] }}
                role="menu"
                className="absolute right-0 mt-2 w-56 rounded-2xl bg-white border border-indigo-100 shadow-xl py-2 z-40"
              >
                <div className="px-4 py-2.5 border-b border-slate-100">
                  <p className="text-sm font-semibold text-[#0C102D] truncate">{user.name}</p>
                  <p className="text-xs text-slate-500 truncate">{user.email}</p>
                </div>

                {user.role === 'student' && (
                  <button
                    type="button"
                    role="menuitem"
                    onClick={() => {
                      setMenuOpen(false);
                      navigate('/profile');
                    }}
                    className="w-full flex items-center gap-2.5 px-4 py-2.5 text-sm text-slate-700 hover:bg-[#F5F4FF] hover:text-[#713BFF] transition-colors"
                  >
                    <UserCircle className="w-4 h-4" />
                    <span>My Profile</span>
                  </button>
                )}

                <button
                  type="button"
                  role="menuitem"
                  onClick={() => {
                    setMenuOpen(false);
                    navigate('/settings');
                  }}
                  className="w-full flex items-center gap-2.5 px-4 py-2.5 text-sm text-slate-700 hover:bg-[#F5F4FF] hover:text-[#713BFF] transition-colors"
                >
                  <Settings className="w-4 h-4" />
                  <span>Settings</span>
                </button>

                <div className="my-1 border-t border-slate-100" />

                <button
                  type="button"
                  role="menuitem"
                  onClick={handleLogout}
                  className="w-full flex items-center gap-2.5 px-4 py-2.5 text-sm text-rose-600 hover:bg-rose-50 transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Logout</span>
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </header>
  );
};
