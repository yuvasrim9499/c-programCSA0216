import React from 'react';
import { motion } from 'motion/react';
import { EASE_SMOOTH } from './MotionPrimitives';

export interface ColumnDef<T> {
  key: string;
  header: string;
  align?: 'left' | 'right' | 'center';
  render: (row: T) => React.ReactNode;
  className?: string;
  colTrack?: string;
}

interface DataTableProps<T> {
  columns: ColumnDef<T>[];
  data: T[];
  rowKey: (row: T) => string;
  emptyState?: React.ReactNode;
  onRowClick?: (row: T) => void;
}

const tableListVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.045,
    },
  },
};

const tableRowVariants = {
  hidden: { opacity: 0, y: 8 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.2, ease: EASE_SMOOTH },
  },
};

export function DataTable<T>({
  columns,
  data,
  rowKey,
  emptyState,
  onRowClick,
}: DataTableProps<T>) {
  if (data.length === 0 && emptyState) {
    return <>{emptyState}</>;
  }

  const gridTemplateColumns = columns
    .map((col) => col.colTrack || 'minmax(0, 1fr)')
    .join(' ');

  const minWidthClass =
    columns.length >= 7
      ? 'min-w-[820px]'
      : columns.length === 6
      ? 'min-w-[700px]'
      : columns.length === 5
      ? 'min-w-[600px]'
      : 'min-w-[480px]';

  return (
    <div className="overflow-x-auto">
      <div className={`w-full ${minWidthClass}`} role="table">
        <div role="rowgroup">
          <div
            role="row"
            style={{ gridTemplateColumns }}
            className="grid items-center border-b border-slate-100 bg-[#FAF9FF]"
          >
            {columns.map((col) => (
              <div
                key={col.key}
                role="columnheader"
                className={`py-3 px-4 text-xs font-semibold text-slate-500 whitespace-nowrap ${
                  col.align === 'right'
                    ? 'text-right'
                    : col.align === 'center'
                    ? 'text-center'
                    : 'text-left'
                } ${col.className || ''}`}
              >
                {col.header}
              </div>
            ))}
          </div>
        </div>

        <motion.ul
          role="rowgroup"
          initial="hidden"
          animate="visible"
          variants={tableListVariants}
          className="divide-y divide-slate-100 list-none m-0 p-0"
        >
          {data.map((row) => (
            <motion.li
              key={rowKey(row)}
              role="row"
              variants={tableRowVariants}
              style={{ gridTemplateColumns }}
              onClick={onRowClick ? () => onRowClick(row) : undefined}
              className={`grid items-center transition-colors hover:bg-[#FAF9FF] ${
                onRowClick ? 'cursor-pointer' : ''
              }`}
            >
              {columns.map((col) => (
                <div
                  key={col.key}
                  role="cell"
                  className={`py-3.5 px-4 text-sm text-[#1F2442] min-w-0 ${
                    col.align === 'right'
                      ? 'text-right'
                      : col.align === 'center'
                      ? 'text-center'
                      : 'text-left'
                  } ${col.className || ''}`}
                >
                  {col.render(row)}
                </div>
              ))}
            </motion.li>
          ))}
        </motion.ul>
      </div>
    </div>
  );
}
