import React from 'react';
import { Heart, Star, ArrowUpRight, Pencil, Trash2 } from 'lucide-react';
import { motion } from 'motion/react';
import { Book } from '../types/library';
import { BookCover } from './BookCover';
import { StatusBadge } from './StatusBadge';

interface BookCardProps {
  book: Book;
  viewMode?: 'grid' | 'list';
  isStudent: boolean;
  isWishlisted?: boolean;
  onToggleWishlist?: (bookId: string) => void;
  onViewDetails: (book: Book) => void;
  onEdit?: (book: Book) => void;
  onDelete?: (book: Book) => void;
  recommendationReason?: string;
}

export const BookCard: React.FC<BookCardProps> = ({
  book,
  viewMode = 'grid',
  isStudent,
  isWishlisted = false,
  onToggleWishlist,
  onViewDetails,
  onEdit,
  onDelete,
  recommendationReason,
}) => {
  const isAvailable = book.availableCopies > 0;

  if (viewMode === 'list') {
    return (
      <motion.article
        whileHover={{ y: -2 }}
        transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
        className="card-surface p-4 flex flex-col sm:flex-row sm:items-center gap-4 hover:border-[#713BFF]/30 hover:shadow-md transition-colors"
      >
        <div className="w-20 h-28 rounded-xl overflow-hidden shrink-0 border border-slate-100">
          <BookCover
            src={book.coverUrl}
            title={book.title}
            author={book.author}
            category={book.category}
            className="w-full h-full"
          />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
            <span className="font-medium text-[#713BFF]">{book.category}</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono">{book.isbn}</span>
            <span aria-hidden="true">·</span>
            <span className="tabular-nums">{book.publicationYear}</span>
          </div>

          <h3 className="font-display text-base font-bold text-[#0C102D] mt-1 truncate">
            {book.title}
          </h3>
          <p className="text-sm text-slate-600 truncate">by {book.author}</p>

          <div className="mt-2.5 flex flex-wrap items-center gap-4 text-xs text-slate-600">
            <span className="inline-flex items-center gap-1 font-medium text-amber-600 tabular-nums">
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" aria-hidden="true" />
              {book.rating.toFixed(1)}
            </span>
            <span className="tabular-nums">
              <strong className="text-[#0C102D]">{book.availableCopies}</strong> of{' '}
              {book.totalCopies} available
            </span>
            <span className="text-slate-400">Shelf {book.shelfLocation}</span>
          </div>
        </div>

        <div className="flex sm:flex-col items-center sm:items-end justify-between gap-2.5 shrink-0">
          <StatusBadge status={isAvailable ? 'Available' : 'Unavailable'} />
          <div className="flex items-center gap-2">
            {isStudent && onToggleWishlist && (
              <motion.button
                type="button"
                whileTap={{ scale: 0.86 }}
                onClick={() => onToggleWishlist(book.id)}
                aria-label={isWishlisted ? `Remove ${book.title} from wishlist` : `Save ${book.title} to wishlist`}
                className={`p-2 rounded-xl border transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#713BFF] ${
                  isWishlisted
                    ? 'bg-rose-50 border-rose-200 text-rose-600'
                    : 'bg-white border-slate-200 text-slate-500 hover:text-rose-600 hover:border-rose-200'
                }`}
              >
                <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-rose-500' : ''}`} />
              </motion.button>
            )}
            {!isStudent && onEdit && (
              <button
                type="button"
                onClick={() => onEdit(book)}
                aria-label={`Edit ${book.title}`}
                className="p-2 rounded-xl border border-slate-200 text-slate-600 hover:text-[#713BFF] hover:border-[#713BFF]/40 transition-colors"
              >
                <Pencil className="w-4 h-4" />
              </button>
            )}
            {!isStudent && onDelete && (
              <button
                type="button"
                onClick={() => onDelete(book)}
                aria-label={`Delete ${book.title}`}
                className="p-2 rounded-xl border border-slate-200 text-slate-600 hover:text-rose-600 hover:border-rose-200 transition-colors"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
            <button
              type="button"
              onClick={() => onViewDetails(book)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold text-white bg-brand-gradient bg-brand-gradient-hover transition-all whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#713BFF]"
            >
              <span>View Details</span>
              <ArrowUpRight className="w-3.5 h-3.5" aria-hidden="true" />
            </button>
          </div>
        </div>
      </motion.article>
    );
  }

  return (
    <motion.article
      whileHover={{ y: -4 }}
      transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
      className="card-surface h-full overflow-hidden flex flex-col hover:border-[#713BFF]/30 hover:shadow-lg hover:shadow-[#713BFF]/8 transition-shadow duration-200 group"
    >
      <div
        onClick={() => onViewDetails(book)}
        className="relative aspect-[3/4] w-full bg-[#ECE9FF] overflow-hidden cursor-pointer"
      >
        <BookCover
          src={book.coverUrl}
          title={book.title}
          author={book.author}
          category={book.category}
          className="w-full h-full group-hover:scale-[1.03] transition-transform duration-300"
        />

        {isStudent && onToggleWishlist && (
          <motion.button
            type="button"
            whileTap={{ scale: 0.82 }}
            onClick={(e) => {
              e.stopPropagation();
              onToggleWishlist(book.id);
            }}
            aria-label={isWishlisted ? `Remove ${book.title} from wishlist` : `Save ${book.title} to wishlist`}
            className={`absolute top-3 right-3 w-9 h-9 rounded-xl flex items-center justify-center backdrop-blur-md transition-colors shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#713BFF] ${
              isWishlisted
                ? 'bg-white text-rose-600'
                : 'bg-white/90 text-slate-600 hover:text-rose-600 hover:bg-white'
            }`}
          >
            <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-rose-500' : ''}`} />
          </motion.button>
        )}
      </div>

      <div className="p-4 flex-1 flex flex-col">
        <div className="flex items-center justify-between gap-2 text-xs text-slate-500">
          <span className="font-semibold text-[#713BFF] truncate">{book.category}</span>
          <span className="inline-flex items-center gap-1 font-semibold text-amber-600 tabular-nums shrink-0">
            <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" aria-hidden="true" />
            {book.rating.toFixed(1)}
          </span>
        </div>

        <h3
          onClick={() => onViewDetails(book)}
          className="font-display text-base font-bold text-[#0C102D] mt-1.5 line-clamp-1 cursor-pointer hover:text-[#713BFF] transition-colors"
        >
          {book.title}
        </h3>
        <p className="text-xs text-slate-500 mt-0.5 truncate">{book.author}</p>

        {recommendationReason && (
          <p className="mt-2.5 text-xs font-medium text-[#4361EE] bg-[#EEF2FF] px-2.5 py-1.5 rounded-lg line-clamp-2">
            {recommendationReason}
          </p>
        )}

        <div className="mt-auto pt-3.5 border-t border-slate-100 flex items-center justify-between gap-2">
          <div className="text-xs tabular-nums">
            <span className={isAvailable ? 'font-semibold text-emerald-700' : 'font-semibold text-rose-600'}>
              {book.availableCopies}
            </span>
            <span className="text-slate-500"> / {book.totalCopies} copies</span>
          </div>

          <div className="flex items-center gap-1.5">
            {!isStudent && onEdit && (
              <button
                type="button"
                onClick={() => onEdit(book)}
                aria-label={`Edit ${book.title}`}
                className="p-1.5 rounded-lg text-slate-500 hover:text-[#713BFF] hover:bg-[#F5F4FF] transition-colors"
              >
                <Pencil className="w-4 h-4" />
              </button>
            )}
            {!isStudent && onDelete && (
              <button
                type="button"
                onClick={() => onDelete(book)}
                aria-label={`Delete ${book.title}`}
                className="p-1.5 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50 transition-colors"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
            <button
              type="button"
              onClick={() => onViewDetails(book)}
              className="px-3 py-1.5 rounded-xl text-xs font-semibold text-white bg-brand-gradient bg-brand-gradient-hover transition-all whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#713BFF]"
            >
              View Details
            </button>
          </div>
        </div>
      </div>
    </motion.article>
  );
};
