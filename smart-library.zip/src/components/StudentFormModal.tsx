import React, { useEffect, useState } from 'react';
import { ALL_CATEGORIES } from '../data/seedData';
import { useLibrary } from '../hooks/useLibrary';
import { BookCategory, Student, StudentStatus } from '../types/library';
import { FormField, inputBaseClass } from './FormField';
import { Modal } from './Modal';

interface StudentFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  editingStudent?: Student | null;
}

export const StudentFormModal: React.FC<StudentFormModalProps> = ({
  isOpen,
  onClose,
  editingStudent,
}) => {
  const { addStudent, updateStudent, showToast } = useLibrary();

  const [studentId, setStudentId] = useState('');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [department, setDepartment] = useState('Computer Science');
  const [year, setYear] = useState('Junior (Year 3)');
  const [status, setStatus] = useState<StudentStatus>('active');
  const [interests, setInterests] = useState<BookCategory[]>(['Programming', 'Data Science']);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    setError(null);
    if (editingStudent) {
      setStudentId(editingStudent.studentId);
      setName(editingStudent.name);
      setEmail(editingStudent.email);
      setDepartment(editingStudent.department);
      setYear(editingStudent.year);
      setStatus(editingStudent.status);
      setInterests(editingStudent.interests);
    } else {
      const randomSuffix = Math.floor(200 + Math.random() * 799);
      setStudentId(`STU-2026-${randomSuffix}`);
      setName('');
      setEmail('');
      setDepartment('Computer Science');
      setYear('Junior (Year 3)');
      setStatus('active');
      setInterests(['Programming', 'Data Science']);
    }
  }, [editingStudent, isOpen]);

  const toggleInterest = (cat: BookCategory) => {
    setInterests((prev) =>
      prev.includes(cat) ? prev.filter((c) => c !== cat) : [...prev, cat]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const payload = {
      studentId,
      name,
      email,
      department,
      year,
      status,
      interests,
    };

    const res = editingStudent
      ? updateStudent(editingStudent.id, payload)
      : addStudent(payload);

    if (!res.ok) {
      setError(res.error || 'Unable to save student record.');
      return;
    }

    showToast({
      type: 'success',
      title: editingStudent ? 'Student Profile Updated' : 'Student Registered',
      description: `${res.data?.name} (${res.data?.studentId})`,
    });
    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={editingStudent ? 'Edit Student Record' : 'Register New Student'}
      subtitle={
        editingStudent
          ? 'Update student contact details, status, and reading interests.'
          : 'Create a student library membership account.'
      }
      size="lg"
      footer={
        <>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-sm font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            form="student-form"
            className="px-5 py-2 rounded-xl text-sm font-semibold text-white bg-brand-gradient bg-brand-gradient-hover shadow-sm transition-all"
          >
            {editingStudent ? 'Save Changes' : 'Register Student'}
          </button>
        </>
      }
    >
      <form id="student-form" onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div
            role="alert"
            className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-sm text-rose-700"
          >
            {error}
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <FormField id="stu-id" label="Student ID" required helperText="Must be unique (e.g. STU-2026-205)">
            <input
              id="stu-id"
              type="text"
              value={studentId}
              onChange={(e) => setStudentId(e.target.value)}
              placeholder="STU-2026-205"
              className={`${inputBaseClass} font-mono uppercase`}
              required
            />
          </FormField>

          <FormField id="stu-name" label="Full Name" required>
            <input
              id="stu-name"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Jordan Rivera"
              className={inputBaseClass}
              required
            />
          </FormField>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <FormField id="stu-email" label="Email Address" required>
            <input
              id="stu-email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="jordan.rivera@smartlibrary.edu"
              className={inputBaseClass}
              required
            />
          </FormField>

          <FormField id="stu-status" label="Account Status">
            <select
              id="stu-status"
              value={status}
              onChange={(e) => setStatus(e.target.value as StudentStatus)}
              className={inputBaseClass}
            >
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
          </FormField>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <FormField id="stu-dept" label="Department">
            <input
              id="stu-dept"
              type="text"
              value={department}
              onChange={(e) => setDepartment(e.target.value)}
              placeholder="Computer Science"
              className={inputBaseClass}
            />
          </FormField>

          <FormField id="stu-year" label="Academic Year">
            <select
              id="stu-year"
              value={year}
              onChange={(e) => setYear(e.target.value)}
              className={inputBaseClass}
            >
              <option value="Freshman (Year 1)">Freshman (Year 1)</option>
              <option value="Sophomore (Year 2)">Sophomore (Year 2)</option>
              <option value="Junior (Year 3)">Junior (Year 3)</option>
              <option value="Senior (Year 4)">Senior (Year 4)</option>
              <option value="Graduate">Graduate</option>
            </select>
          </FormField>
        </div>

        <div>
          <span className="block text-sm font-medium text-[#1F2442] mb-2">
            Topic Interests (used for rule-based recommendations)
          </span>
          <div className="flex flex-wrap gap-2">
            {ALL_CATEGORIES.map((cat) => {
              const selected = interests.includes(cat);
              return (
                <button
                  key={cat}
                  type="button"
                  onClick={() => toggleInterest(cat)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-medium border transition-colors ${
                    selected
                      ? 'bg-[#713BFF] text-white border-[#713BFF]'
                      : 'bg-white text-slate-600 border-slate-200 hover:border-[#713BFF]/40'
                  }`}
                >
                  {cat}
                </button>
              );
            })}
          </div>
        </div>
      </form>
    </Modal>
  );
};
