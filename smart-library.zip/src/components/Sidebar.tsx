import React from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import {
  ArrowLeftRight,
  BarChart3,
  Bell,
  BookMarked,
  BookOpen,
  Heart,
  LayoutDashboard,
  Library,
  LogOut,
  Settings,
  Sparkles,
  UserCircle,
  Users,
  X,
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { useLibrary } from '../hooks/useLibrary';

interface SidebarProps {
  collapsed: boolean;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

interface NavItem {
  to: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  collapsed,
  mobileOpen,
  onCloseMobile,
}) => {
  const { user, settings, unreadNotificationCount, logout, showToast } = useLibrary();
  const navigate = useNavigate();
  const location = useLocation();

  if (!user) return null;

  const adminNav: NavItem[] = [
    { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/books', label: 'Manage Books', icon: BookOpen },
    { to: '/students', label: 'Manage Students', icon: Users },
    { to: '/issue-return', label: 'Issue / Return', icon: ArrowLeftRight },
    { to: '/recommendations', label: 'Recommendations', icon: Sparkles },
    { to: '/reports', label: 'Reports', icon: BarChart3 },
    {
      to: '/notifications',
      label: 'Notifications',
      icon: Bell,
      badge: unreadNotificationCount,
    },
    { to: '/settings', label: 'Settings', icon: Settings },
  ];

  const studentNav: NavItem[] = [
    { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/books', label: 'Browse Books', icon: BookOpen },
    { to: '/my-loans', label: 'My Loans', icon: BookMarked },
    { to: '/recommendations', label: 'Recommendations', icon: Sparkles },
    { to: '/wishlist', label: 'Wishlist', icon: Heart },
    { to: '/profile', label: 'My Profile', icon: UserCircle },
    {
      to: '/notifications',
      label: 'Notifications',
      icon: Bell,
      badge: unreadNotificationCount,
    },
  ];

  const navItems = user.role === 'admin' ? adminNav : studentNav;

  const handleLogout = () => {
    logout();
    onCloseMobile();
    showToast({ type: 'info', title: 'Signed out', description: 'You have logged out of Smart Library.' });
    navigate('/login', { replace: true });
  };

  const renderNavContent = (isMobileDrawer: boolean) => {
    const isCollapsed = collapsed && !isMobileDrawer;

    return (
      <div className="flex flex-col h-full bg-[#0C102D] text-white select-none">
        {/* Brand Header */}
        <div
          className={`flex items-center ${
            isCollapsed ? 'justify-center px-3' : 'justify-between px-5'
          } h-16 border-b border-white/10 shrink-0`}
        >
          <NavLink
            to="/dashboard"
            onClick={onCloseMobile}
            className="flex items-center gap-3 min-w-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#713BFF] rounded-lg"
          >
            <div className="w-9 h-9 rounded-xl bg-brand-gradient flex items-center justify-center shadow-lg shadow-[#713BFF]/30 shrink-0">
              <Library className="w-5 h-5 text-white" aria-hidden="true" />
            </div>
            {!isCollapsed && (
              <span className="font-display font-bold text-base tracking-tight text-white whitespace-nowrap truncate">
                {settings.libraryName}
              </span>
            )}
          </NavLink>

          {isMobileDrawer && (
            <button
              type="button"
              onClick={onCloseMobile}
              aria-label="Close navigation menu"
              className="p-2 rounded-xl text-indigo-200 hover:text-white hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Navigation Links */}
        <nav className="flex-1 overflow-y-auto px-3 py-5 space-y-1.5" aria-label="Primary navigation">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive =
              location.pathname === item.to ||
              (item.to === '/books' && location.pathname.startsWith('/books/'));

            return (
              <NavLink
                key={item.to}
                to={item.to}
                onClick={onCloseMobile}
                title={isCollapsed ? item.label : undefined}
                className={`relative flex items-center ${
                  isCollapsed ? 'justify-center px-2.5' : 'justify-between px-3.5'
                } py-2.5 rounded-xl text-sm font-medium transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#713BFF] ${
                  isActive
                    ? 'text-white'
                    : 'text-indigo-200/85 hover:text-white hover:bg-white/8'
                }`}
              >
                {isActive && (
                  <motion.span
                    layoutId={isMobileDrawer ? 'sidebar-pill-mobile' : 'sidebar-pill-desktop'}
                    transition={{ type: 'spring', stiffness: 420, damping: 32 }}
                    className="absolute inset-0 rounded-xl bg-brand-gradient shadow-md shadow-[#713BFF]/30"
                    aria-hidden="true"
                  />
                )}
                <div className="relative z-10 flex items-center gap-3 min-w-0">
                  <Icon className="w-5 h-5 shrink-0" aria-hidden="true" />
                  {!isCollapsed && (
                    <span className="whitespace-nowrap truncate">{item.label}</span>
                  )}
                </div>
                {!isCollapsed && typeof item.badge === 'number' && item.badge > 0 && (
                  <span className="relative z-10 ml-2 px-2 py-0.5 text-[11px] font-semibold rounded-md bg-white/20 text-white tabular-nums">
                    {item.badge}
                  </span>
                )}
              </NavLink>
            );
          })}
        </nav>

        {/* Bottom Role Info & Logout */}
        <div className="p-3 border-t border-white/10 space-y-2 shrink-0">
          {!isCollapsed && (
            <div className="px-3 py-2.5 rounded-xl bg-white/5">
              <p className="text-xs font-semibold text-white truncate">{user.name}</p>
              <p className="text-[11px] text-indigo-300 truncate mt-0.5">
                {user.role === 'admin' ? user.roleTitle || 'Librarian' : user.studentId}
              </p>
            </div>
          )}

          <button
            type="button"
            onClick={handleLogout}
            title={isCollapsed ? 'Logout' : undefined}
            className={`w-full flex items-center ${
              isCollapsed ? 'justify-center px-2.5' : 'gap-3 px-3.5'
            } py-2.5 rounded-xl text-sm font-medium text-indigo-200 hover:text-white hover:bg-rose-500/20 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#713BFF]`}
          >
            <LogOut className="w-5 h-5 shrink-0" aria-hidden="true" />
            {!isCollapsed && <span className="whitespace-nowrap">Logout</span>}
          </button>
        </div>
      </div>
    );
  };

  return (
    <>
      {/* Desktop / Tablet Fixed Sidebar */}
      <aside
        className={`hidden md:flex md:flex-col md:fixed md:inset-y-0 md:left-0 z-30 transition-all duration-200 ${
          collapsed ? 'w-[78px]' : 'w-[256px]'
        }`}
      >
        {renderNavContent(false)}
      </aside>

      {/* Animated Mobile Drawer Navigation */}
      <AnimatePresence>
        {mobileOpen && (
          <div className="fixed inset-0 z-50 md:hidden flex">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.18 }}
              className="fixed inset-0 bg-[#0C102D]/60 backdrop-blur-[2px]"
              onClick={onCloseMobile}
              aria-hidden="true"
            />
            <motion.aside
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
              className="relative w-72 max-w-[85vw] h-full z-10 shadow-2xl"
            >
              {renderNavContent(true)}
            </motion.aside>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};
