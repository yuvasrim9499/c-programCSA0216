import React, { useEffect, useState } from 'react';
import { ALL_CATEGORIES, BOOK_COVERS } from '../data/seedData';
import { useLibrary } from '../hooks/useLibrary';
import { BookInput } from '../services/bookService';
import { Book, BookCategory } from '../types/library';
import { FormField, inputBaseClass } from './FormField';
import { Modal } from './Modal';

interface BookFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  editingBook?: Book | null;
}

const COVER_OPTIONS = [
  { label: 'Python & Programming', url: BOOK_COVERS.python },
  { label: 'Machine Learning', url: BOOK_COVERS.machineLearning },
  { label: 'Data Science', url: BOOK_COVERS.dataScience },
  { label: 'Web & Systems', url: BOOK_COVERS.webDev },
  { label: 'Deep Learning', url: BOOK_COVERS.deepLearning },
  { label: 'Artificial Intelligence', url: BOOK_COVERS.aiSystems },
  { label: 'Algorithms & Math', url: BOOK_COVERS.algorithms },
  { label: 'Software & Design', url: BOOK_COVERS.softwareDesign },
];

export const BookFormModal: React.FC<BookFormModalProps> = ({
  isOpen,
  onClose,
  editingBook,
}) => {
  const { addBook, updateBook, showToast } = useLibrary();

  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [isbn, setIsbn] = useState('');
  const [category, setCategory] = useState<BookCategory>('Programming');
  const [publicationYear, setPublicationYear] = useState(String(new Date().getFullYear()));
  const [totalCopies, setTotalCopies] = useState('4');
  const [shelfLocation, setShelfLocation] = useState('A1-01');
  const [rating, setRating] = useState('4.7');
  const [coverUrl, setCoverUrl] = useState(BOOK_COVERS.python);
  const [description, setDescription] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    setError(null);
    if (editingBook) {
      setTitle(editingBook.title);
      setAuthor(editingBook.author);
      setIsbn(editingBook.isbn);
      setCategory(editingBook.category);
      setPublicationYear(String(editingBook.publicationYear));
      setTotalCopies(String(editingBook.totalCopies));
      setShelfLocation(editingBook.shelfLocation);
      setRating(String(editingBook.rating));
      setCoverUrl(editingBook.coverUrl);
      setDescription(editingBook.description);
    } else {
      setTitle('');
      setAuthor('');
      setIsbn('');
      setCategory('Programming');
      setPublicationYear(String(new Date().getFullYear()));
      setTotalCopies('4');
      setShelfLocation('A1-01');
      setRating('4.7');
      setCoverUrl(BOOK_COVERS.python);
      setDescription('');
    }
  }, [editingBook, isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const payload: BookInput = {
      title,
      author,
      isbn,
      category,
      publicationYear: Number.parseInt(publicationYear, 10),
      totalCopies: Number.parseInt(totalCopies, 10),
      shelfLocation,
      rating: Number.parseFloat(rating),
      coverUrl,
      description,
    };

    const res = editingBook
      ? updateBook(editingBook.id, payload)
      : addBook(payload);

    if (!res.ok) {
      setError(res.error || 'Could not save book.');
      return;
    }

    showToast({
      type: 'success',
      title: editingBook ? 'Book Updated' : 'Book Added to Catalog',
      description: res.data?.title,
    });
    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={editingBook ? 'Edit Book Details' : 'Add New Book'}
      subtitle={
        editingBook
          ? 'Update catalog metadata and copy inventory.'
          : 'Register a new title into the Smart Library catalog.'
      }
      size="lg"
      footer={
        <>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-sm font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            form="book-form"
            className="px-5 py-2 rounded-xl text-sm font-semibold text-white bg-brand-gradient bg-brand-gradient-hover shadow-sm transition-all"
          >
            {editingBook ? 'Save Changes' : 'Add Book'}
          </button>
        </>
      }
    >
      <form id="book-form" onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div
            role="alert"
            className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-sm text-rose-700"
          >
            {error}
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <FormField id="book-title" label="Book Title" required>
            <input
              id="book-title"
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Python Programming"
              className={inputBaseClass}
              required
            />
          </FormField>

          <FormField id="book-author" label="Author" required>
            <input
              id="book-author"
              type="text"
              value={author}
              onChange={(e) => setAuthor(e.target.value)}
              placeholder="e.g. Eric Matthes"
              className={inputBaseClass}
              required
            />
          </FormField>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <FormField
            id="book-isbn"
            label="ISBN"
            required
            helperText="10 or 13 digits (hyphens optional)"
          >
            <input
              id="book-isbn"
              type="text"
              value={isbn}
              onChange={(e) => setIsbn(e.target.value)}
              placeholder="978-1718502703"
              className={`${inputBaseClass} font-mono`}
              required
            />
          </FormField>

          <FormField id="book-category" label="Category" required>
            <select
              id="book-category"
              value={category}
              onChange={(e) => setCategory(e.target.value as BookCategory)}
              className={inputBaseClass}
            >
              {ALL_CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </FormField>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <FormField id="book-year" label="Year" required>
            <input
              id="book-year"
              type="number"
              min={1450}
              max={new Date().getFullYear() + 1}
              value={publicationYear}
              onChange={(e) => setPublicationYear(e.target.value)}
              className={`${inputBaseClass} tabular-nums`}
              required
            />
          </FormField>

          <FormField id="book-copies" label="Total Copies" required>
            <input
              id="book-copies"
              type="number"
              min={1}
              max={500}
              value={totalCopies}
              onChange={(e) => setTotalCopies(e.target.value)}
              className={`${inputBaseClass} tabular-nums`}
              required
            />
          </FormField>

          <FormField id="book-shelf" label="Shelf Location" required>
            <input
              id="book-shelf"
              type="text"
              value={shelfLocation}
              onChange={(e) => setShelfLocation(e.target.value)}
              placeholder="B2-14"
              className={inputBaseClass}
              required
            />
          </FormField>

          <FormField id="book-rating" label="Rating (1–5)">
            <input
              id="book-rating"
              type="number"
              step="0.1"
              min={1}
              max={5}
              value={rating}
              onChange={(e) => setRating(e.target.value)}
              className={`${inputBaseClass} tabular-nums`}
            />
          </FormField>
        </div>

        <FormField id="book-cover-preset" label="Cover Artwork Style">
          <select
            id="book-cover-preset"
            value={coverUrl}
            onChange={(e) => setCoverUrl(e.target.value)}
            className={inputBaseClass}
          >
            {COVER_OPTIONS.map((opt) => (
              <option key={opt.label} value={opt.url}>
                {opt.label}
              </option>
            ))}
          </select>
        </FormField>

        <FormField id="book-description" label="Description">
          <textarea
            id="book-description"
            rows={3}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Brief synopsis of topics and target audience..."
            className={inputBaseClass}
          />
        </FormField>
      </form>
    </Modal>
  );
};
