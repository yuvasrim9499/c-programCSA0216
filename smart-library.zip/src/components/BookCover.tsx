import React, { useState } from 'react';
import { BookOpen } from 'lucide-react';

interface BookCoverProps {
  src: string;
  title: string;
  author?: string;
  category?: string;
  className?: string;
}

export const BookCover: React.FC<BookCoverProps> = ({
  src,
  title,
  author,
  category,
  className = '',
}) => {
  const [failed, setFailed] = useState(false);

  if (failed || !src) {
    return (
      <div
        className={`relative flex flex-col justify-between p-4 bg-gradient-to-br from-[#0C102D] via-[#221F5E] to-[#4361EE] text-white select-none overflow-hidden ${className}`}
        role="img"
        aria-label={`${title} cover artwork`}
      >
        <div
          className="absolute -right-8 -top-8 w-28 h-28 rounded-full bg-[#713BFF]/30 blur-xl pointer-events-none"
          aria-hidden="true"
        />
        <div
          className="absolute -left-6 -bottom-6 w-24 h-24 rounded-full bg-[#4361EE]/30 blur-lg pointer-events-none"
          aria-hidden="true"
        />
        <div className="relative z-10 flex items-center justify-between">
          <span className="text-[11px] font-medium text-indigo-200 truncate">
            {category || 'Smart Library'}
          </span>
          <BookOpen className="w-4 h-4 text-indigo-200 shrink-0" aria-hidden="true" />
        </div>
        <div className="relative z-10 mt-auto">
          <p className="font-display font-semibold text-sm leading-snug line-clamp-3 text-white">
            {title}
          </p>
          {author && (
            <p className="text-[11px] text-indigo-200/90 mt-1 truncate">{author}</p>
          )}
        </div>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={`Cover for ${title}${author ? ` by ${author}` : ''}`}
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className={`object-cover bg-[#ECE9FF] ${className}`}
      loading="lazy"
    />
  );
};
