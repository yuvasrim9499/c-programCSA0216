import React from 'react';
import { LucideIcon } from 'lucide-react';
import { motion } from 'motion/react';

interface StatCardProps {
  title: string;
  value: string | number;
  description: string;
  icon: LucideIcon;
  accent?: 'purple' | 'blue' | 'amber' | 'rose' | 'emerald';
  onClick?: () => void;
}

const ACCENT_CLASSES: Record<NonNullable<StatCardProps['accent']>, string> = {
  purple: 'bg-[#713BFF]/10 text-[#713BFF]',
  blue: 'bg-[#4361EE]/10 text-[#4361EE]',
  amber: 'bg-amber-50 text-amber-600',
  rose: 'bg-rose-50 text-rose-600',
  emerald: 'bg-emerald-50 text-emerald-600',
};

export const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  description,
  icon: Icon,
  accent = 'purple',
  onClick,
}) => {
  if (onClick) {
    return (
      <motion.button
        type="button"
        onClick={onClick}
        whileHover={{ y: -3 }}
        whileTap={{ scale: 0.99 }}
        transition={{ duration: 0.16, ease: [0.16, 1, 0.3, 1] }}
        className="card-surface p-5 text-left w-full hover:border-[#713BFF]/30 hover:shadow-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#713BFF]"
      >
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="text-sm font-medium text-slate-500 truncate">{title}</p>
            <p className="mt-2 font-display text-3xl font-bold text-[#0C102D] tabular-nums tracking-tight">
              {value}
            </p>
          </div>
          <div
            className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${ACCENT_CLASSES[accent]}`}
          >
            <Icon className="w-5 h-5" aria-hidden="true" />
          </div>
        </div>
        <p className="mt-3 text-xs text-slate-500 leading-relaxed truncate">{description}</p>
      </motion.button>
    );
  }

  return (
    <motion.div
      whileHover={{ y: -2 }}
      transition={{ duration: 0.16, ease: [0.16, 1, 0.3, 1] }}
      className="card-surface p-5 text-left w-full"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-sm font-medium text-slate-500 truncate">{title}</p>
          <p className="mt-2 font-display text-3xl font-bold text-[#0C102D] tabular-nums tracking-tight">
            {value}
          </p>
        </div>
        <div
          className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${ACCENT_CLASSES[accent]}`}
        >
          <Icon className="w-5 h-5" aria-hidden="true" />
        </div>
      </div>
      <p className="mt-3 text-xs text-slate-500 leading-relaxed truncate">{description}</p>
    </motion.div>
  );
};
