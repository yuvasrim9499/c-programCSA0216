import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  BookOpen,
  Hash,
  LayoutGrid,
  List,
  RotateCcw,
  Search,
  Tag,
  User,
  X,
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { ALL_CATEGORIES } from '../data/seedData';
import { Book } from '../types/library';
import { EASE_SMOOTH } from './MotionPrimitives';

export type AvailabilityFilter = 'all' | 'available' | 'checked_out';
export type BookSortOption = 'title_asc' | 'rating_desc' | 'newest';

type SuggestionKind = 'category' | 'author' | 'title' | 'isbn';

interface SearchSuggestion {
  id: string;
  kind: SuggestionKind;
  prefix: string;
  value: string;
  subtitle: string;
  score: number;
}

interface BookFiltersProps {
  books: Book[];
  searchQuery: string;
  onSearchChange: (value: string) => void;
  selectedCategory: string;
  onCategoryChange: (value: string) => void;
  availability: AvailabilityFilter;
  onAvailabilityChange: (value: AvailabilityFilter) => void;
  sortBy: BookSortOption;
  onSortChange: (value: BookSortOption) => void;
  viewMode: 'grid' | 'list';
  onViewModeChange: (mode: 'grid' | 'list') => void;
  onClearFilters: () => void;
  hasActiveFilters: boolean;
}

function renderHighlightedText(text: string, query: string): React.ReactNode {
  const q = query.trim();
  if (!q) return text;
  const idx = text.toLowerCase().indexOf(q.toLowerCase());
  if (idx === -1) return text;
  const before = text.slice(0, idx);
  const match = text.slice(idx, idx + q.length);
  const after = text.slice(idx + q.length);
  return (
    <>
      {before}
      <mark className="bg-[#ECE9FF] text-[#713BFF] rounded-xs px-0.5 font-semibold">
        {match}
      </mark>
      {after}
    </>
  );
}

const SUGGESTION_META: Record<
  SuggestionKind,
  {
    icon: React.ComponentType<{ className?: string }>;
    accentClass: string;
    iconBgClass: string;
  }
> = {
  category: {
    icon: Tag,
    accentClass: 'text-[#713BFF]',
    iconBgClass: 'bg-[#F5F4FF] text-[#713BFF]',
  },
  author: {
    icon: User,
    accentClass: 'text-[#4361EE]',
    iconBgClass: 'bg-[#EEF2FF] text-[#4361EE]',
  },
  title: {
    icon: BookOpen,
    accentClass: 'text-[#0C102D]',
    iconBgClass: 'bg-slate-100 text-[#0C102D]',
  },
  isbn: {
    icon: Hash,
    accentClass: 'text-slate-600',
    iconBgClass: 'bg-slate-100 text-slate-600',
  },
};

export const BookFilters: React.FC<BookFiltersProps> = ({
  books,
  searchQuery,
  onSearchChange,
  selectedCategory,
  onCategoryChange,
  availability,
  onAvailabilityChange,
  sortBy,
  onSortChange,
  viewMode,
  onViewModeChange,
  onClearFilters,
  hasActiveFilters,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [activeIndex, setActiveIndex] = useState(-1);

  const suggestions = useMemo<SearchSuggestion[]>(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return [];

    const categoryCounts = new Map<string, number>();
    const authorBooks = new Map<string, Book[]>();

    for (const book of books) {
      categoryCounts.set(book.category, (categoryCounts.get(book.category) || 0) + 1);
      const list = authorBooks.get(book.author) || [];
      list.push(book);
      authorBooks.set(book.author, list);
    }

    const categoryMatches: SearchSuggestion[] = ALL_CATEGORIES.filter((cat) =>
      cat.toLowerCase().includes(q)
    )
      .map((cat) => {
        const count = categoryCounts.get(cat) || 0;
        const starts = cat.toLowerCase().startsWith(q);
        return {
          id: `cat-${cat}`,
          kind: 'category' as const,
          prefix: 'Category',
          value: cat,
          subtitle: `${count} ${count === 1 ? 'title' : 'titles'} · Filter by category`,
          score: starts ? 2 : 1,
        };
      })
      .sort((a, b) => b.score - a.score || a.value.localeCompare(b.value))
      .slice(0, 3);

    const authorMatches: SearchSuggestion[] = Array.from(authorBooks.entries())
      .filter(([author]) => author.toLowerCase().includes(q))
      .map(([author, list]) => {
        const starts = author.toLowerCase().startsWith(q);
        return {
          id: `author-${author}`,
          kind: 'author' as const,
          prefix: 'Author',
          value: author,
          subtitle: `${list.length} ${list.length === 1 ? 'book' : 'books'} in catalog`,
          score: starts ? 2 : 1,
        };
      })
      .sort((a, b) => b.score - a.score || a.value.localeCompare(b.value))
      .slice(0, 3);

    const titleMatches: SearchSuggestion[] = books
      .filter((b) => b.title.toLowerCase().includes(q))
      .map((b) => {
        const starts = b.title.toLowerCase().startsWith(q);
        return {
          id: `title-${b.id}`,
          kind: 'title' as const,
          prefix: 'Title',
          value: b.title,
          subtitle: `${b.author} · ${b.availableCopies}/${b.totalCopies} available`,
          score: starts ? 2 : 1,
        };
      })
      .sort((a, b) => b.score - a.score || a.value.localeCompare(b.value))
      .slice(0, 4);

    const normalizedIsbnQ = q.replace(/-/g, '');
    const isbnMatches: SearchSuggestion[] =
      normalizedIsbnQ.length >= 2 && /\d/.test(normalizedIsbnQ)
        ? books
            .filter(
              (b) =>
                b.isbn.toLowerCase().includes(q) ||
                b.isbn.replace(/-/g, '').toLowerCase().includes(normalizedIsbnQ)
            )
            .map((b) => ({
              id: `isbn-${b.id}`,
              kind: 'isbn' as const,
              prefix: 'ISBN',
              value: b.isbn,
              subtitle: b.title,
              score: 1,
            }))
            .slice(0, 2)
        : [];

    return [...categoryMatches, ...authorMatches, ...titleMatches, ...isbnMatches];
  }, [books, searchQuery]);

  const showSuggestions = dropdownOpen && searchQuery.trim().length > 0;

  useEffect(() => {
    setActiveIndex(-1);
  }, [searchQuery]);

  useEffect(() => {
    const handlePointerDown = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handlePointerDown);
    return () => document.removeEventListener('mousedown', handlePointerDown);
  }, []);

  const handleSelectSuggestion = (item: SearchSuggestion) => {
    if (item.kind === 'category') {
      onCategoryChange(item.value);
      onSearchChange('');
    } else {
      onSearchChange(item.value);
    }
    setDropdownOpen(false);
    setActiveIndex(-1);
    inputRef.current?.focus();
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (!showSuggestions || suggestions.length === 0) {
      if (e.key === 'Escape') {
        setDropdownOpen(false);
      }
      return;
    }

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setActiveIndex((prev) => (prev + 1) % suggestions.length);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setActiveIndex((prev) => (prev <= 0 ? suggestions.length - 1 : prev - 1));
    } else if (e.key === 'Enter' && activeIndex >= 0) {
      e.preventDefault();
      handleSelectSuggestion(suggestions[activeIndex]);
    } else if (e.key === 'Escape') {
      e.preventDefault();
      setDropdownOpen(false);
      setActiveIndex(-1);
    }
  };

  return (
    <div className="card-surface p-4 space-y-3 relative z-20">
      <div className="flex flex-col lg:flex-row lg:items-center gap-3">
        <div ref={containerRef} className="relative flex-1 min-w-0">
          <Search
            className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
            aria-hidden="true"
          />
          <label htmlFor="catalog-search" className="sr-only">
            Search books by title, author, category, or ISBN
          </label>
          <input
            ref={inputRef}
            id="catalog-search"
            type="text"
            role="combobox"
            aria-expanded={showSuggestions}
            aria-controls="catalog-search-suggestions"
            aria-autocomplete="list"
            aria-activedescendant={
              activeIndex >= 0 && suggestions[activeIndex]
                ? `suggestion-${suggestions[activeIndex].id}`
                : undefined
            }
            value={searchQuery}
            onFocus={() => setDropdownOpen(true)}
            onChange={(e) => {
              onSearchChange(e.target.value);
              setDropdownOpen(true);
            }}
            onKeyDown={handleKeyDown}
            placeholder="Search by title, author, category, or ISBN..."
            className="w-full pl-10 pr-9 py-2.5 rounded-xl border border-slate-200 bg-white text-sm text-[#111827] placeholder:text-slate-400 focus:outline-none focus:border-[#713BFF] focus:ring-3 focus:ring-[#713BFF]/15"
          />

          {searchQuery && (
            <button
              type="button"
              onClick={() => {
                onSearchChange('');
                setDropdownOpen(false);
                inputRef.current?.focus();
              }}
              aria-label="Clear search text"
              className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}

          <AnimatePresence>
            {showSuggestions && (
              <motion.div
                id="catalog-search-suggestions"
                role="listbox"
                aria-label="Catalog search suggestions"
                initial={{ opacity: 0, y: -4, scale: 0.99 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -4, scale: 0.99 }}
                transition={{ duration: 0.15, ease: EASE_SMOOTH }}
                className="absolute left-0 right-0 top-full mt-2 bg-white rounded-2xl border border-indigo-100 shadow-xl shadow-[#0C102D]/10 overflow-hidden z-30"
              >
                {suggestions.length === 0 ? (
                  <div className="px-4 py-3.5 text-xs text-slate-500">
                    No catalog suggestions for{' '}
                    <span className="font-semibold text-[#0C102D]">"{searchQuery.trim()}"</span>
                  </div>
                ) : (
                  <ul className="max-h-80 overflow-y-auto divide-y divide-slate-100/80 list-none m-0 p-1.5">
                    {suggestions.map((item, idx) => {
                      const meta = SUGGESTION_META[item.kind];
                      const Icon = meta.icon;
                      const isActive = idx === activeIndex;

                      return (
                        <li
                          key={item.id}
                          id={`suggestion-${item.id}`}
                          role="option"
                          aria-selected={isActive}
                        >
                          <button
                            type="button"
                            onMouseEnter={() => setActiveIndex(idx)}
                            onMouseDown={(e) => {
                              // Prevent blur from closing before click fires
                              e.preventDefault();
                              handleSelectSuggestion(item);
                            }}
                            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-colors ${
                              isActive
                                ? 'bg-[#F5F4FF]'
                                : 'hover:bg-[#FAF9FF]'
                            }`}
                          >
                            <div
                              className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${meta.iconBgClass}`}
                            >
                              <Icon className="w-4 h-4" aria-hidden="true" />
                            </div>

                            <div className="min-w-0 flex-1">
                              <p className="text-sm text-[#0C102D] truncate">
                                <span className={`font-semibold ${meta.accentClass}`}>
                                  {item.prefix}:
                                </span>{' '}
                                <span className="font-medium">
                                  {renderHighlightedText(item.value, searchQuery)}
                                </span>
                              </p>
                              <p className="text-xs text-slate-500 truncate mt-0.5">
                                {item.subtitle}
                              </p>
                            </div>
                          </button>
                        </li>
                      );
                    })}
                  </ul>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 lg:flex lg:items-center gap-2.5">
          <div>
            <label htmlFor="category-filter" className="sr-only">
              Filter by category
            </label>
            <select
              id="category-filter"
              value={selectedCategory}
              onChange={(e) => onCategoryChange(e.target.value)}
              className="w-full lg:w-44 rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm text-[#111827] focus:outline-none focus:border-[#713BFF] focus:ring-3 focus:ring-[#713BFF]/15"
            >
              <option value="all">All Categories</option>
              {ALL_CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="availability-filter" className="sr-only">
              Filter by availability
            </label>
            <select
              id="availability-filter"
              value={availability}
              onChange={(e) => onAvailabilityChange(e.target.value as AvailabilityFilter)}
              className="w-full lg:w-40 rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm text-[#111827] focus:outline-none focus:border-[#713BFF] focus:ring-3 focus:ring-[#713BFF]/15"
            >
              <option value="all">All Statuses</option>
              <option value="available">Available Now</option>
              <option value="checked_out">Checked Out</option>
            </select>
          </div>

          <div>
            <label htmlFor="sort-select" className="sr-only">
              Sort books
            </label>
            <select
              id="sort-select"
              value={sortBy}
              onChange={(e) => onSortChange(e.target.value as BookSortOption)}
              className="w-full lg:w-40 rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm text-[#111827] focus:outline-none focus:border-[#713BFF] focus:ring-3 focus:ring-[#713BFF]/15"
            >
              <option value="title_asc">Sort: Title (A–Z)</option>
              <option value="rating_desc">Sort: Highest Rated</option>
              <option value="newest">Sort: Newest</option>
            </select>
          </div>
        </div>

        <div className="flex items-center justify-between lg:justify-end gap-2 shrink-0">
          {hasActiveFilters && (
            <button
              type="button"
              onClick={onClearFilters}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium text-[#713BFF] bg-[#F5F4FF] hover:bg-[#ECE9FF] transition-colors whitespace-nowrap shrink-0"
            >
              <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Clear Filters</span>
            </button>
          )}

          <div
            className="inline-flex items-center p-1 bg-[#F5F4FF] rounded-xl border border-indigo-100"
            role="group"
            aria-label="View layout"
          >
            <button
              type="button"
              onClick={() => onViewModeChange('grid')}
              aria-label="Grid view"
              aria-pressed={viewMode === 'grid'}
              className={`p-1.5 rounded-lg transition-colors ${
                viewMode === 'grid'
                  ? 'bg-white text-[#713BFF] shadow-sm'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => onViewModeChange('list')}
              aria-label="List view"
              aria-pressed={viewMode === 'list'}
              className={`p-1.5 rounded-lg transition-colors ${
                viewMode === 'list'
                  ? 'bg-white text-[#713BFF] shadow-sm'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
