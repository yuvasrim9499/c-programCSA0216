import React from 'react';
import {
  AlertCircle,
  BookOpen,
  CheckCircle2,
  Clock,
  PauseCircle,
  XCircle,
} from 'lucide-react';

export type BadgeVariant =
  | 'Available'
  | 'Unavailable'
  | 'Issued'
  | 'Due Soon'
  | 'Overdue'
  | 'Returned'
  | 'Active'
  | 'Inactive';

interface StatusBadgeProps {
  status: BadgeVariant;
  className?: string;
}

const STYLE_MAP: Record<
  BadgeVariant,
  { bg: string; text: string; border: string; icon: React.ComponentType<{ className?: string }> }
> = {
  Available: {
    bg: 'bg-emerald-50',
    text: 'text-emerald-700',
    border: 'border-emerald-200/80',
    icon: CheckCircle2,
  },
  Active: {
    bg: 'bg-emerald-50',
    text: 'text-emerald-700',
    border: 'border-emerald-200/80',
    icon: CheckCircle2,
  },
  Returned: {
    bg: 'bg-emerald-50',
    text: 'text-emerald-700',
    border: 'border-emerald-200/80',
    icon: CheckCircle2,
  },
  Issued: {
    bg: 'bg-[#EEF2FF]',
    text: 'text-[#4361EE]',
    border: 'border-[#4361EE]/20',
    icon: BookOpen,
  },
  'Due Soon': {
    bg: 'bg-amber-50',
    text: 'text-amber-700',
    border: 'border-amber-200/80',
    icon: Clock,
  },
  Overdue: {
    bg: 'bg-rose-50',
    text: 'text-rose-700',
    border: 'border-rose-200/80',
    icon: AlertCircle,
  },
  Unavailable: {
    bg: 'bg-rose-50',
    text: 'text-rose-700',
    border: 'border-rose-200/80',
    icon: XCircle,
  },
  Inactive: {
    bg: 'bg-slate-100',
    text: 'text-slate-600',
    border: 'border-slate-200',
    icon: PauseCircle,
  },
};

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, className = '' }) => {
  const cfg = STYLE_MAP[status];
  const Icon = cfg.icon;

  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium border whitespace-nowrap shrink-0 ${cfg.bg} ${cfg.text} ${cfg.border} ${className}`}
    >
      <Icon className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
      <span>{status}</span>
    </span>
  );
};
