import { Book, LibrarySettings, Loan, Student } from '../types/library';
import { addDaysISO, diffDaysISO, formatShortDate, getTodayISO } from '../utils/dateUtils';
import { computeLoanMetrics } from './loanService';

export interface ActivityPoint {
  date: string;
  label: string;
  issued: number;
  returned: number;
}

export interface PopularBookStat {
  book: Book;
  borrowCount: number;
  activeCount: number;
}

export interface CategoryDistributionStat {
  category: string;
  bookCount: number;
  totalCopies: number;
  loanCount: number;
}

export interface OverdueReportRow {
  loan: Loan;
  book: Book;
  student: Student;
  daysOverdue: number;
  fineAmount: number;
}

export const reportService = {
  buildActivitySeries(loans: Loan[], startDateIso: string, endDateIso: string): ActivityPoint[] {
    const spanDays = Math.max(1, diffDaysISO(startDateIso, endDateIso) + 1);
    const points: ActivityPoint[] = [];

    // If span > 31 days, bucket into ~10 intervals so the chart stays clean and legible
    if (spanDays > 31) {
      const bucketSize = Math.ceil(spanDays / 10);
      for (let i = 0; i < spanDays; i += bucketSize) {
        const bucketStart = addDaysISO(startDateIso, i);
        const bucketEnd = addDaysISO(
          startDateIso,
          Math.min(spanDays - 1, i + bucketSize - 1)
        );
        const issued = loans.filter(
          (l) => l.issueDate >= bucketStart && l.issueDate <= bucketEnd
        ).length;
        const returned = loans.filter(
          (l) => l.returnDate && l.returnDate >= bucketStart && l.returnDate <= bucketEnd
        ).length;
        points.push({
          date: bucketStart,
          label: formatShortDate(bucketStart),
          issued,
          returned,
        });
      }
      return points;
    }

    for (let i = 0; i < spanDays; i++) {
      const dayIso = addDaysISO(startDateIso, i);
      const issued = loans.filter((l) => l.issueDate === dayIso).length;
      const returned = loans.filter((l) => l.returnDate === dayIso).length;
      points.push({
        date: dayIso,
        label: formatShortDate(dayIso),
        issued,
        returned,
      });
    }
    return points;
  },

  getPopularBooks(books: Book[], loans: Loan[], limit = 6): PopularBookStat[] {
    const borrowMap: Record<string, number> = {};
    const activeMap: Record<string, number> = {};

    for (const loan of loans) {
      borrowMap[loan.bookId] = (borrowMap[loan.bookId] || 0) + 1;
      if (loan.status === 'active') {
        activeMap[loan.bookId] = (activeMap[loan.bookId] || 0) + 1;
      }
    }

    return books
      .map((book) => ({
        book,
        borrowCount: borrowMap[book.id] || 0,
        activeCount: activeMap[book.id] || 0,
      }))
      .sort((a, b) => b.borrowCount - a.borrowCount || b.book.rating - a.book.rating)
      .slice(0, limit);
  },

  getCategoryDistribution(books: Book[], loans: Loan[]): CategoryDistributionStat[] {
    const bookById = new Map(books.map((b) => [b.id, b]));
    const stats = new Map<string, CategoryDistributionStat>();

    for (const book of books) {
      const existing = stats.get(book.category) || {
        category: book.category,
        bookCount: 0,
        totalCopies: 0,
        loanCount: 0,
      };
      existing.bookCount += 1;
      existing.totalCopies += book.totalCopies;
      stats.set(book.category, existing);
    }

    for (const loan of loans) {
      const book = bookById.get(loan.bookId);
      if (book) {
        const existing = stats.get(book.category);
        if (existing) {
          existing.loanCount += 1;
        }
      }
    }

    return Array.from(stats.values()).sort((a, b) => b.loanCount - a.loanCount);
  },

  getOverdueReport(
    loans: Loan[],
    books: Book[],
    students: Student[],
    settings: LibrarySettings
  ): OverdueReportRow[] {
    const today = getTodayISO();
    const bookMap = new Map(books.map((b) => [b.id, b]));
    const studentMap = new Map(students.map((s) => [s.id, s]));

    const rows: OverdueReportRow[] = [];
    for (const loan of loans) {
      if (loan.status !== 'active') continue;
      const metrics = computeLoanMetrics(loan, settings, today);
      if (metrics.derivedStatus === 'Overdue') {
        const book = bookMap.get(loan.bookId);
        const student = studentMap.get(loan.studentId);
        if (book && student) {
          rows.push({
            loan,
            book,
            student,
            daysOverdue: metrics.daysOverdue,
            fineAmount: metrics.calculatedFine,
          });
        }
      }
    }

    return rows.sort((a, b) => b.daysOverdue - a.daysOverdue);
  },

  exportFilteredLoansCSV(
    loans: Loan[],
    books: Book[],
    students: Student[],
    settings: LibrarySettings,
    filename = 'smart-library-report.csv'
  ): void {
    const today = getTodayISO();
    const bookMap = new Map(books.map((b) => [b.id, b]));
    const studentMap = new Map(students.map((s) => [s.id, s]));

    const escapeCsv = (value: string | number) => {
      const str = String(value ?? '');
      if (str.includes(',') || str.includes('"') || str.includes('\n')) {
        return `"${str.replace(/"/g, '""')}"`;
      }
      return str;
    };

    const headers = [
      'Loan ID',
      'Student ID',
      'Student Name',
      'Book Title',
      'ISBN',
      'Category',
      'Issue Date',
      'Due Date',
      'Return Date',
      'Status',
      `Fine (${settings.currencySymbol})`,
    ];

    const rows = loans.map((loan) => {
      const book = bookMap.get(loan.bookId);
      const student = studentMap.get(loan.studentId);
      const metrics = computeLoanMetrics(loan, settings, today);
      return [
        loan.id,
        student?.studentId ?? '',
        student?.name ?? '',
        book?.title ?? '',
        book?.isbn ?? '',
        book?.category ?? '',
        loan.issueDate,
        loan.dueDate,
        loan.returnDate ?? '',
        metrics.derivedStatus,
        metrics.calculatedFine.toFixed(2),
      ].map(escapeCsv);
    });

    const csvContent = [headers.map(escapeCsv).join(','), ...rows.map((r) => r.join(','))].join(
      '\n'
    );
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  },
};
