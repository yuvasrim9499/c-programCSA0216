import {
  Book,
  BookCategory,
  BookRecommendation,
  Loan,
  Student,
} from '../types/library';
import { storageService } from './storageService';

/**
 * Transparent rule-based recommendation engine.
 * Ranks unread/unborrowed books using borrowing history, wishlist similarity,
 * selected topic interests, and catalog rating.
 * Does not call any external AI model or API.
 */
const RELATED_CATEGORIES: Record<BookCategory, BookCategory[]> = {
  Programming: ['Data Science', 'Software Engineering', 'Web & Systems'],
  'Artificial Intelligence': ['Data Science', 'Computer Science', 'Programming'],
  'Data Science': ['Artificial Intelligence', 'Programming', 'Computer Science'],
  'Web & Systems': ['Software Engineering', 'Programming', 'Design & UX'],
  'Software Engineering': ['Web & Systems', 'Computer Science', 'Design & UX'],
  'Computer Science': ['Artificial Intelligence', 'Software Engineering', 'Programming'],
  'Design & UX': ['Web & Systems', 'Software Engineering'],
};

export const recommendationService = {
  getRecommendationsForStudent(
    student: Student | undefined,
    books: Book[],
    loans: Loan[],
    wishlistBookIds: string[],
    limit = 8
  ): BookRecommendation[] {
    if (!student) {
      return this.getGlobalCatalogRecommendations(books, loans, limit);
    }

    const studentLoans = loans.filter((l) => l.studentId === student.id);
    const borrowedBookIds = new Set(studentLoans.map((l) => l.bookId));
    const borrowedBooks = studentLoans
      .map((l) => books.find((b) => b.id === l.bookId))
      .filter((b): b is Book => Boolean(b));

    const wishlistBooks = wishlistBookIds
      .map((id) => books.find((b) => b.id === id))
      .filter((b): b is Book => Boolean(b));

    const borrowCounts: Record<string, number> = {};
    for (const loan of loans) {
      borrowCounts[loan.bookId] = (borrowCounts[loan.bookId] || 0) + 1;
    }

    // Candidates: books the student is not currently borrowing or hasn't already borrowed
    // (Wait: if all books are borrowed, fall back gracefully)
    const candidates = books.filter((b) => !borrowedBookIds.has(b.id));
    const pool = candidates.length > 0 ? candidates : books;

    const scored: BookRecommendation[] = pool.map((book) => {
      let score = book.rating * 10 + (borrowCounts[book.id] || 0) * 3;
      let reason = 'Highly rated foundational guide in the catalog';
      let matchType: BookRecommendation['matchType'] = 'popular';

      // 1. Direct category match with previously borrowed book
      const historyCategoryMatch = borrowedBooks.find((hb) => hb.category === book.category);
      // 2. Adjacent topic match with previously borrowed book
      const historyRelatedMatch = borrowedBooks.find((hb) =>
        RELATED_CATEGORIES[hb.category]?.includes(book.category)
      );
      // 3. Direct wishlist match
      const wishlistCategoryMatch = wishlistBooks.find(
        (wb) => wb.id !== book.id && wb.category === book.category
      );
      // 4. Student selected interest match
      const interestMatch = student.interests.includes(book.category);

      if (historyCategoryMatch) {
        score += 40;
        reason = `Because you borrowed ${historyCategoryMatch.title}`;
        matchType = 'history';
      } else if (interestMatch && borrowedBooks.length === 0) {
        score += 36;
        reason = `Matches your interest in ${book.category}`;
        matchType = 'interest';
      } else if (wishlistCategoryMatch) {
        score += 32;
        reason = `Similar to ${wishlistCategoryMatch.title} in your wishlist`;
        matchType = 'wishlist';
      } else if (interestMatch) {
        score += 30;
        reason = `Matches your interest in ${book.category}`;
        matchType = 'interest';
      } else if (historyRelatedMatch) {
        score += 24;
        reason = `Because you borrowed ${historyRelatedMatch.title}`;
        matchType = 'history';
      } else if ((borrowCounts[book.id] || 0) >= 2) {
        score += 15;
        reason = `Popular among ${book.category} readers`;
        matchType = 'popular';
      }

      if (book.availableCopies > 0) {
        score += 5;
      }

      return { book, reason, score, matchType };
    });

    return scored
      .sort((a, b) => b.score - a.score)
      .slice(0, limit);
  },

  getGlobalCatalogRecommendations(
    books: Book[],
    loans: Loan[],
    limit = 6
  ): BookRecommendation[] {
    const borrowCounts: Record<string, number> = {};
    for (const loan of loans) {
      borrowCounts[loan.bookId] = (borrowCounts[loan.bookId] || 0) + 1;
    }

    return [...books]
      .map((book) => {
        const count = borrowCounts[book.id] || 0;
        const score = book.rating * 12 + count * 6 + (book.availableCopies > 0 ? 4 : 0);
        const reason =
          count >= 2
            ? `Frequently borrowed in ${book.category} (${count} loans)`
            : `Top-rated ${book.category} resource (${book.rating.toFixed(1)}★)`;
        return {
          book,
          reason,
          score,
          matchType: 'popular' as const,
        };
      })
      .sort((a, b) => b.score - a.score)
      .slice(0, limit);
  },

  toggleWishlist(studentId: string, bookId: string): string[] {
    const db = storageService.getDatabase();
    const current = db.wishlists[studentId] || [];
    const exists = current.includes(bookId);
    const updated = exists ? current.filter((id) => id !== bookId) : [bookId, ...current];

    storageService.saveDatabase({
      ...db,
      wishlists: {
        ...db.wishlists,
        [studentId]: updated,
      },
    });
    return updated;
  },
};
