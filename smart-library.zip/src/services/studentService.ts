import { BookCategory, Student, StudentStatus } from '../types/library';
import { getTodayISO } from '../utils/dateUtils';
import { ServiceResult, storageService } from './storageService';

export interface StudentInput {
  studentId: string;
  name: string;
  email: string;
  department: string;
  year: string;
  status: StudentStatus;
  interests?: BookCategory[];
  monthlyGoal?: number;
}

export const studentService = {
  getAll(): Student[] {
    return storageService.getDatabase().students;
  },

  getById(id: string): Student | undefined {
    return storageService.getDatabase().students.find((s) => s.id === id);
  },

  addStudent(input: StudentInput): ServiceResult<Student> {
    const name = input.name.trim();
    const email = input.email.trim().toLowerCase();
    const studentId = input.studentId.trim().toUpperCase();

    if (name.length < 2) return { ok: false, error: 'Full name is required.' };
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return { ok: false, error: 'Please enter a valid email address.' };
    }
    if (!/^[A-Z0-9-]{4,20}$/.test(studentId)) {
      return { ok: false, error: 'Student ID must be 4–20 alphanumeric/hyphen characters.' };
    }

    const db = storageService.getDatabase();
    if (db.students.some((s) => s.studentId.toUpperCase() === studentId)) {
      return { ok: false, error: `Student ID "${studentId}" is already registered.` };
    }
    if (
      db.students.some((s) => s.email.toLowerCase() === email) ||
      db.admins.some((a) => a.email.toLowerCase() === email)
    ) {
      return { ok: false, error: `Email "${email}" is already in use.` };
    }

    const created: Student = {
      id: `stu-${Date.now()}`,
      studentId,
      name,
      email,
      password: 'Student@2026',
      department: input.department.trim() || 'Computer Science',
      year: input.year.trim() || 'Undergraduate',
      status: input.status,
      interests: input.interests?.length ? input.interests : ['Programming', 'Data Science'],
      monthlyGoal: input.monthlyGoal || 3,
      notificationPrefs: { dueSoon: true, overdue: true, confirmations: true },
      joinedAt: getTodayISO(),
    };

    storageService.saveDatabase({
      ...db,
      students: [created, ...db.students],
      wishlists: { ...db.wishlists, [created.id]: [] },
    });
    return { ok: true, data: created };
  },

  updateStudent(id: string, input: StudentInput): ServiceResult<Student> {
    const db = storageService.getDatabase();
    const existing = db.students.find((s) => s.id === id);
    if (!existing) return { ok: false, error: 'Student not found.' };

    const name = input.name.trim();
    const email = input.email.trim().toLowerCase();
    const studentId = input.studentId.trim().toUpperCase();

    if (name.length < 2) return { ok: false, error: 'Full name is required.' };
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return { ok: false, error: 'Please enter a valid email address.' };
    }
    if (!/^[A-Z0-9-]{4,20}$/.test(studentId)) {
      return { ok: false, error: 'Student ID must be 4–20 alphanumeric/hyphen characters.' };
    }

    if (db.students.some((s) => s.id !== id && s.studentId.toUpperCase() === studentId)) {
      return { ok: false, error: `Student ID "${studentId}" belongs to another student.` };
    }
    if (
      db.students.some((s) => s.id !== id && s.email.toLowerCase() === email) ||
      db.admins.some((a) => a.email.toLowerCase() === email)
    ) {
      return { ok: false, error: `Email "${email}" is already used by another account.` };
    }

    const updated: Student = {
      ...existing,
      studentId,
      name,
      email,
      department: input.department.trim() || existing.department,
      year: input.year.trim() || existing.year,
      status: input.status,
      interests: input.interests ?? existing.interests,
      monthlyGoal: input.monthlyGoal ?? existing.monthlyGoal,
    };

    storageService.saveDatabase({
      ...db,
      students: db.students.map((s) => (s.id === id ? updated : s)),
    });
    return { ok: true, data: updated };
  },

  toggleStatus(id: string): ServiceResult<Student> {
    const db = storageService.getDatabase();
    const existing = db.students.find((s) => s.id === id);
    if (!existing) return { ok: false, error: 'Student not found.' };

    const nextStatus: StudentStatus = existing.status === 'active' ? 'inactive' : 'active';
    const updated: Student = { ...existing, status: nextStatus };

    storageService.saveDatabase({
      ...db,
      students: db.students.map((s) => (s.id === id ? updated : s)),
    });
    return { ok: true, data: updated };
  },
};
