import { DerivedLoanStatus, LibrarySettings, Loan, NotificationItem } from '../types/library';
import { diffDaysISO, getTodayISO } from '../utils/dateUtils';
import { ServiceResult, storageService } from './storageService';

export interface LoanComputedInfo {
  derivedStatus: DerivedLoanStatus;
  daysRemaining: number; // Negative when overdue
  daysOverdue: number;
  calculatedFine: number;
}

export function computeLoanMetrics(
  loan: Loan,
  settings: LibrarySettings,
  referenceDateIso: string = getTodayISO()
): LoanComputedInfo {
  if (loan.status === 'returned') {
    return {
      derivedStatus: 'Returned',
      daysRemaining: 0,
      daysOverdue: 0,
      calculatedFine: loan.finePaid,
    };
  }

  const daysRemaining = diffDaysISO(referenceDateIso, loan.dueDate);
  if (daysRemaining < 0) {
    const daysOverdue = Math.abs(daysRemaining);
    const calculatedFine = Number((daysOverdue * settings.dailyOverdueFine).toFixed(2));
    return {
      derivedStatus: 'Overdue',
      daysRemaining,
      daysOverdue,
      calculatedFine,
    };
  }

  if (daysRemaining <= settings.dueSoonWindowDays) {
    return {
      derivedStatus: 'Due Soon',
      daysRemaining,
      daysOverdue: 0,
      calculatedFine: 0,
    };
  }

  return {
    derivedStatus: 'Issued',
    daysRemaining,
    daysOverdue: 0,
    calculatedFine: 0,
  };
}

export interface IssueBookPayload {
  studentId: string;
  bookId: string;
  issueDate: string;
  dueDate: string;
  notes?: string;
}

export const loanService = {
  issueBook(payload: IssueBookPayload): ServiceResult<Loan> {
    const db = storageService.getDatabase();
    const student = db.students.find((s) => s.id === payload.studentId);
    if (!student) return { ok: false, error: 'Selected student does not exist.' };
    if (student.status !== 'active') {
      return { ok: false, error: `${student.name}'s account is inactive and cannot borrow books.` };
    }

    const book = db.books.find((b) => b.id === payload.bookId);
    if (!book) return { ok: false, error: 'Selected book does not exist.' };
    if (book.availableCopies <= 0) {
      return { ok: false, error: `No copies of "${book.title}" are currently available.` };
    }

    if (!payload.issueDate || !payload.dueDate) {
      return { ok: false, error: 'Issue date and due date are required.' };
    }
    if (diffDaysISO(payload.issueDate, payload.dueDate) <= 0) {
      return { ok: false, error: 'Due date must be strictly later than the issue date.' };
    }

    const studentActiveLoans = db.loans.filter(
      (l) => l.studentId === student.id && l.status === 'active'
    );

    if (studentActiveLoans.some((l) => l.bookId === book.id)) {
      return {
        ok: false,
        error: `${student.name} already has an active loan for "${book.title}".`,
      };
    }

    if (studentActiveLoans.length >= db.settings.maxActiveLoansPerStudent) {
      return {
        ok: false,
        error: `${student.name} has reached the maximum limit of ${db.settings.maxActiveLoansPerStudent} active loans.`,
      };
    }

    const loanNumber = db.loans.length + 1;
    const newLoan: Loan = {
      id: `LN-${new Date().getFullYear()}-${String(loanNumber).padStart(3, '0')}-${String(
        Date.now()
      ).slice(-3)}`,
      bookId: book.id,
      studentId: student.id,
      issueDate: payload.issueDate,
      dueDate: payload.dueDate,
      returnDate: null,
      status: 'active',
      finePaid: 0,
      notes: payload.notes?.trim() || undefined,
    };

    const nowIso = new Date().toISOString();
    const newNotifications: NotificationItem[] = [
      {
        id: `ntf-${Date.now()}-adm`,
        recipientId: 'admin',
        type: 'issue',
        title: 'Book Issued',
        message: `"${book.title}" issued to ${student.name} (Due ${payload.dueDate}).`,
        createdAt: nowIso,
        read: false,
        relatedLoanId: newLoan.id,
      },
    ];

    if (student.notificationPrefs.confirmations) {
      newNotifications.push({
        id: `ntf-${Date.now()}-stu`,
        recipientId: student.id,
        type: 'issue',
        title: 'Borrowing Confirmed',
        message: `You borrowed "${book.title}". Please return it by ${payload.dueDate}.`,
        createdAt: nowIso,
        read: false,
        relatedLoanId: newLoan.id,
      });
    }

    storageService.saveDatabase({
      ...db,
      loans: [newLoan, ...db.loans],
      notifications: [...newNotifications, ...db.notifications],
    });

    return { ok: true, data: newLoan };
  },

  returnBook(loanId: string, returnDate: string = getTodayISO()): ServiceResult<Loan> {
    const db = storageService.getDatabase();
    const loan = db.loans.find((l) => l.id === loanId);
    if (!loan) return { ok: false, error: 'Loan record not found.' };
    if (loan.status === 'returned') {
      return { ok: false, error: 'This loan has already been returned.' };
    }

    const metrics = computeLoanMetrics(loan, db.settings, returnDate);
    const updatedLoan: Loan = {
      ...loan,
      status: 'returned',
      returnDate,
      finePaid: metrics.calculatedFine,
    };

    const book = db.books.find((b) => b.id === loan.bookId);
    const student = db.students.find((s) => s.id === loan.studentId);
    const nowIso = new Date().toISOString();

    const newNotifications: NotificationItem[] = [
      {
        id: `ntf-${Date.now()}-ret-adm`,
        recipientId: 'admin',
        type: 'return',
        title: 'Book Returned',
        message: `"${book?.title ?? 'Book'}" returned by ${student?.name ?? 'Student'}${
          metrics.calculatedFine > 0
            ? ` (Fine settled: ${db.settings.currencySymbol}${metrics.calculatedFine.toFixed(2)})`
            : ''
        }.`,
        createdAt: nowIso,
        read: false,
        relatedLoanId: loan.id,
      },
    ];

    if (student && student.notificationPrefs.confirmations) {
      newNotifications.push({
        id: `ntf-${Date.now()}-ret-stu`,
        recipientId: student.id,
        type: 'return',
        title: 'Return Confirmed',
        message: `Your return of "${book?.title ?? 'Book'}" on ${returnDate} has been recorded.`,
        createdAt: nowIso,
        read: false,
        relatedLoanId: loan.id,
      });
    }

    storageService.saveDatabase({
      ...db,
      loans: db.loans.map((l) => (l.id === loanId ? updatedLoan : l)),
      notifications: [...newNotifications, ...db.notifications],
    });

    return { ok: true, data: updatedLoan };
  },
};
