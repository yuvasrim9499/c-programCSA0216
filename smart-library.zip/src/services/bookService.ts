import { BOOK_COVERS } from '../data/seedData';
import { Book, BookCategory } from '../types/library';
import { getTodayISO } from '../utils/dateUtils';
import { ServiceResult, storageService } from './storageService';

export interface BookInput {
  title: string;
  author: string;
  isbn: string;
  category: BookCategory;
  description: string;
  publicationYear: number;
  totalCopies: number;
  shelfLocation: string;
  rating: number;
  coverUrl?: string;
}

export function isValidIsbn(isbn: string): boolean {
  const cleaned = isbn.replace(/[-\s]/g, '');
  return /^(\d{10}|\d{13})$/.test(cleaned);
}

const COVER_BY_CATEGORY: Record<BookCategory, string> = {
  Programming: BOOK_COVERS.python,
  'Artificial Intelligence': BOOK_COVERS.machineLearning,
  'Data Science': BOOK_COVERS.dataScience,
  'Web & Systems': BOOK_COVERS.webDev,
  'Software Engineering': BOOK_COVERS.softwareDesign,
  'Computer Science': BOOK_COVERS.algorithms,
  'Design & UX': BOOK_COVERS.softwareDesign,
};

export const bookService = {
  getAll(): Book[] {
    return storageService.getDatabase().books;
  },

  getById(id: string): Book | undefined {
    return storageService.getDatabase().books.find((b) => b.id === id);
  },

  addBook(input: BookInput): ServiceResult<Book> {
    const title = input.title.trim();
    const author = input.author.trim();
    const isbn = input.isbn.trim();
    const shelfLocation = input.shelfLocation.trim();

    if (title.length < 2) return { ok: false, error: 'Book title is required.' };
    if (author.length < 2) return { ok: false, error: 'Author name is required.' };
    if (!isValidIsbn(isbn)) {
      return { ok: false, error: 'ISBN must be a valid 10-digit or 13-digit number (hyphens allowed).' };
    }
    if (!Number.isInteger(input.totalCopies) || input.totalCopies < 1 || input.totalCopies > 500) {
      return { ok: false, error: 'Total copies must be a whole number between 1 and 500.' };
    }
    const currentYear = new Date().getFullYear() + 1;
    if (!Number.isInteger(input.publicationYear) || input.publicationYear < 1450 || input.publicationYear > currentYear) {
      return { ok: false, error: `Publication year must be between 1450 and ${currentYear}.` };
    }
    if (!shelfLocation) return { ok: false, error: 'Shelf location is required.' };

    const db = storageService.getDatabase();
    const normalizedIsbn = isbn.replace(/[-\s]/g, '');
    if (db.books.some((b) => b.isbn.replace(/[-\s]/g, '') === normalizedIsbn)) {
      return { ok: false, error: 'A book with this ISBN already exists in the catalog.' };
    }

    const newBook: Book = {
      id: `bk-${Date.now()}`,
      title,
      author,
      isbn,
      category: input.category,
      description:
        input.description.trim() ||
        `${title} by ${author}. Cataloged in the ${input.category} collection.`,
      publicationYear: input.publicationYear,
      totalCopies: input.totalCopies,
      availableCopies: input.totalCopies,
      shelfLocation,
      rating: Math.min(5, Math.max(1, Number(input.rating) || 4.5)),
      coverUrl: input.coverUrl?.trim() || COVER_BY_CATEGORY[input.category],
      addedAt: getTodayISO(),
    };

    storageService.saveDatabase({
      ...db,
      books: [newBook, ...db.books],
    });
    return { ok: true, data: newBook };
  },

  updateBook(id: string, input: BookInput): ServiceResult<Book> {
    const db = storageService.getDatabase();
    const existing = db.books.find((b) => b.id === id);
    if (!existing) return { ok: false, error: 'Book not found.' };

    const title = input.title.trim();
    const author = input.author.trim();
    const isbn = input.isbn.trim();
    const shelfLocation = input.shelfLocation.trim();

    if (title.length < 2) return { ok: false, error: 'Book title is required.' };
    if (author.length < 2) return { ok: false, error: 'Author name is required.' };
    if (!isValidIsbn(isbn)) {
      return { ok: false, error: 'ISBN must be a valid 10-digit or 13-digit number.' };
    }

    const activeLoansCount = db.loans.filter(
      (l) => l.bookId === id && l.status === 'active'
    ).length;

    if (!Number.isInteger(input.totalCopies) || input.totalCopies < activeLoansCount) {
      return {
        ok: false,
        error: `Total copies cannot be fewer than the ${activeLoansCount} currently issued ${
          activeLoansCount === 1 ? 'copy' : 'copies'
        }.`,
      };
    }

    const normalizedIsbn = isbn.replace(/[-\s]/g, '');
    if (
      db.books.some(
        (b) => b.id !== id && b.isbn.replace(/[-\s]/g, '') === normalizedIsbn
      )
    ) {
      return { ok: false, error: 'Another book in the catalog already uses this ISBN.' };
    }

    const updatedBook: Book = {
      ...existing,
      title,
      author,
      isbn,
      category: input.category,
      description: input.description.trim() || existing.description,
      publicationYear: input.publicationYear,
      totalCopies: input.totalCopies,
      availableCopies: input.totalCopies - activeLoansCount,
      shelfLocation,
      rating: Math.min(5, Math.max(1, Number(input.rating) || existing.rating)),
      coverUrl: input.coverUrl?.trim() || existing.coverUrl,
    };

    storageService.saveDatabase({
      ...db,
      books: db.books.map((b) => (b.id === id ? updatedBook : b)),
    });
    return { ok: true, data: updatedBook };
  },

  deleteBook(id: string): ServiceResult<void> {
    const db = storageService.getDatabase();
    const book = db.books.find((b) => b.id === id);
    if (!book) return { ok: false, error: 'Book not found.' };

    const activeLoans = db.loans.filter((l) => l.bookId === id && l.status === 'active');
    if (activeLoans.length > 0) {
      return {
        ok: false,
        error: `Cannot delete "${book.title}" because ${activeLoans.length} ${
          activeLoans.length === 1 ? 'copy is' : 'copies are'
        } currently checked out. Return all active loans first.`,
      };
    }

    // Remove from wishlists too
    const nextWishlists = { ...db.wishlists };
    for (const studentKey of Object.keys(nextWishlists)) {
      nextWishlists[studentKey] = nextWishlists[studentKey].filter((bId) => bId !== id);
    }

    storageService.saveDatabase({
      ...db,
      books: db.books.filter((b) => b.id !== id),
      wishlists: nextWishlists,
    });
    return { ok: true };
  },
};
