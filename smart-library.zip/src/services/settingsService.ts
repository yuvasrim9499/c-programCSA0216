import { BookCategory, LibrarySettings, NotificationPreferences, Student } from '../types/library';
import { ServiceResult, storageService } from './storageService';

export interface StudentProfilePatch {
  name: string;
  email: string;
  department: string;
  year: string;
  interests: BookCategory[];
  monthlyGoal: number;
  notificationPrefs: NotificationPreferences;
}

export const settingsService = {
  getSettings(): LibrarySettings {
    return storageService.getDatabase().settings;
  },

  updateAdminSettings(next: LibrarySettings): ServiceResult<LibrarySettings> {
    if (next.libraryName.trim().length < 2) {
      return { ok: false, error: 'Library name must be at least 2 characters.' };
    }
    if (!Number.isInteger(next.defaultLoanDays) || next.defaultLoanDays < 1 || next.defaultLoanDays > 180) {
      return { ok: false, error: 'Default borrowing duration must be between 1 and 180 days.' };
    }
    if (
      !Number.isInteger(next.maxActiveLoansPerStudent) ||
      next.maxActiveLoansPerStudent < 1 ||
      next.maxActiveLoansPerStudent > 25
    ) {
      return { ok: false, error: 'Maximum active loans must be between 1 and 25.' };
    }
    if (Number.isNaN(next.dailyOverdueFine) || next.dailyOverdueFine < 0 || next.dailyOverdueFine > 100) {
      return { ok: false, error: 'Daily overdue fine must be between 0 and 100.' };
    }
    if (!next.currencySymbol.trim()) {
      return { ok: false, error: 'Currency label/symbol is required.' };
    }

    const db = storageService.getDatabase();
    const cleaned: LibrarySettings = {
      ...next,
      libraryName: next.libraryName.trim(),
      currencySymbol: next.currencySymbol.trim().slice(0, 5),
      dueSoonWindowDays: Math.max(1, Math.min(14, Number(next.dueSoonWindowDays) || 3)),
    };

    storageService.saveDatabase({
      ...db,
      settings: cleaned,
    });
    return { ok: true, data: cleaned };
  },

  updateStudentProfile(
    studentInternalId: string,
    patch: StudentProfilePatch
  ): ServiceResult<Student> {
    const db = storageService.getDatabase();
    const student = db.students.find((s) => s.id === studentInternalId);
    if (!student) return { ok: false, error: 'Student account not found.' };

    const name = patch.name.trim();
    const email = patch.email.trim().toLowerCase();
    if (name.length < 2) return { ok: false, error: 'Full name is required.' };
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return { ok: false, error: 'Please enter a valid email address.' };
    }
    if (
      db.students.some((s) => s.id !== studentInternalId && s.email.toLowerCase() === email) ||
      db.admins.some((a) => a.email.toLowerCase() === email)
    ) {
      return { ok: false, error: 'This email address is already in use.' };
    }

    const updated: Student = {
      ...student,
      name,
      email,
      department: patch.department.trim() || student.department,
      year: patch.year.trim() || student.year,
      interests: patch.interests,
      monthlyGoal: Math.max(1, Math.min(30, Number(patch.monthlyGoal) || 3)),
      notificationPrefs: patch.notificationPrefs,
    };

    storageService.saveDatabase({
      ...db,
      students: db.students.map((s) => (s.id === studentInternalId ? updated : s)),
    });

    const currentSession = storageService.getSession();
    if (currentSession && currentSession.id === studentInternalId) {
      storageService.saveSession({
        ...currentSession,
        name: updated.name,
        email: updated.email,
      });
    }

    return { ok: true, data: updated };
  },

  resetDemoData() {
    return storageService.resetDatabase();
  },
};
