import { createSeedDatabase } from '../data/seedData';
import { LibraryDatabase, Role, UserSession } from '../types/library';

const DB_STORAGE_KEY = 'smart_library_db_v1';
const SESSION_STORAGE_KEY = 'smart_library_session_v1';
const REMEMBER_STORAGE_KEY = 'smart_library_remember_v1';
const CURRENCY_MIGRATION_KEY = 'smart_library_currency_inr_v1';

export interface ServiceResult<T> {
  ok: boolean;
  data?: T;
  error?: string;
}

/**
 * Reconciles book availableCopies with active loan records to guarantee consistency.
 */
function reconcileInventory(db: LibraryDatabase): LibraryDatabase {
  const activeCounts: Record<string, number> = {};
  for (const loan of db.loans) {
    if (loan.status === 'active') {
      activeCounts[loan.bookId] = (activeCounts[loan.bookId] || 0) + 1;
    }
  }
  const books = db.books.map((book) => ({
    ...book,
    availableCopies: Math.max(0, book.totalCopies - (activeCounts[book.id] || 0)),
  }));
  return { ...db, books };
}

export const storageService = {
  getDatabase(): LibraryDatabase {
    try {
      const raw = localStorage.getItem(DB_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as LibraryDatabase;
        if (parsed && Array.isArray(parsed.books) && Array.isArray(parsed.students)) {
          let db = reconcileInventory(parsed);
          if (!localStorage.getItem(CURRENCY_MIGRATION_KEY)) {
            let changed = false;
            if (db.settings && db.settings.currencySymbol === '$') {
              db = {
                ...db,
                settings: { ...db.settings, currencySymbol: '₹' },
              };
              changed = true;
            }
            if (Array.isArray(db.notifications)) {
              const updatedNotifications = db.notifications.map((n) =>
                n.id === 'ntf-seed-5' && n.message.includes('$6.00')
                  ? { ...n, message: n.message.replace('$6.00', '₹6.00') }
                  : n
              );
              if (updatedNotifications.some((n, i) => n !== db.notifications[i])) {
                db = { ...db, notifications: updatedNotifications };
                changed = true;
              }
            }
            localStorage.setItem(CURRENCY_MIGRATION_KEY, '1');
            if (changed) {
              this.saveDatabase(db);
            }
          }
          return db;
        }
      }
    } catch {
      // Fallback to fresh seed if corrupted
    }
    const seeded = reconcileInventory(createSeedDatabase());
    this.saveDatabase(seeded);
    return seeded;
  },

  saveDatabase(db: LibraryDatabase): LibraryDatabase {
    const reconciled = reconcileInventory(db);
    try {
      localStorage.setItem(DB_STORAGE_KEY, JSON.stringify(reconciled));
    } catch {
      // Ignore storage quota errors in restricted environments
    }
    return reconciled;
  },

  resetDatabase(): LibraryDatabase {
    const seeded = reconcileInventory(createSeedDatabase());
    this.saveDatabase(seeded);
    return seeded;
  },

  getSession(): UserSession | null {
    try {
      const rawSession = sessionStorage.getItem(SESSION_STORAGE_KEY);
      if (rawSession) {
        return JSON.parse(rawSession) as UserSession;
      }
      const rawLocal = localStorage.getItem(SESSION_STORAGE_KEY);
      if (rawLocal) {
        return JSON.parse(rawLocal) as UserSession;
      }
    } catch {
      return null;
    }
    return null;
  },

  saveSession(session: UserSession | null, rememberMe = true): void {
    try {
      sessionStorage.removeItem(SESSION_STORAGE_KEY);
      localStorage.removeItem(SESSION_STORAGE_KEY);
      if (session) {
        if (rememberMe) {
          localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(session));
        } else {
          sessionStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(session));
        }
      }
    } catch {
      // Ignore
    }
  },

  getRememberedLogin(): { email: string; role: Role } | null {
    try {
      const raw = localStorage.getItem(REMEMBER_STORAGE_KEY);
      if (!raw) return null;
      return JSON.parse(raw) as { email: string; role: Role };
    } catch {
      return null;
    }
  },

  saveRememberedLogin(email: string, role: Role, remember: boolean): void {
    try {
      if (remember) {
        localStorage.setItem(REMEMBER_STORAGE_KEY, JSON.stringify({ email, role }));
      } else {
        localStorage.removeItem(REMEMBER_STORAGE_KEY);
      }
    } catch {
      // Ignore
    }
  },
};
