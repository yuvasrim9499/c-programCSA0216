import { NotificationItem } from '../types/library';
import { getTodayISO } from '../utils/dateUtils';
import { computeLoanMetrics } from './loanService';
import { storageService } from './storageService';

export const notificationService = {
  /**
   * Synchronizes due-soon and overdue notifications based on current date and active loans.
   * Uses relatedLoanId + type deduplication so repeated runs never spam notifications.
   */
  syncLoanAlerts(): NotificationItem[] {
    const db = storageService.getDatabase();
    const today = getTodayISO();
    const newItems: NotificationItem[] = [];

    const hasAlert = (recipientId: string, loanId: string, type: 'due_soon' | 'overdue') =>
      db.notifications.some(
        (n) =>
          n.recipientId === recipientId &&
          n.relatedLoanId === loanId &&
          n.type === type
      ) ||
      newItems.some(
        (n) =>
          n.recipientId === recipientId &&
          n.relatedLoanId === loanId &&
          n.type === type
      );

    for (const loan of db.loans) {
      if (loan.status !== 'active') continue;
      const metrics = computeLoanMetrics(loan, db.settings, today);
      const book = db.books.find((b) => b.id === loan.bookId);
      const student = db.students.find((s) => s.id === loan.studentId);
      if (!book || !student) continue;

      if (metrics.derivedStatus === 'Overdue') {
        if (!hasAlert('admin', loan.id, 'overdue')) {
          newItems.push({
            id: `ntf-auto-adm-od-${loan.id}`,
            recipientId: 'admin',
            type: 'overdue',
            title: 'Overdue Loan Alert',
            message: `${book.title} (borrowed by ${student.name}) is ${metrics.daysOverdue} ${
              metrics.daysOverdue === 1 ? 'day' : 'days'
            } overdue.`,
            createdAt: new Date().toISOString(),
            read: false,
            relatedLoanId: loan.id,
          });
        }
        if (student.notificationPrefs.overdue && !hasAlert(student.id, loan.id, 'overdue')) {
          newItems.push({
            id: `ntf-auto-stu-od-${loan.id}`,
            recipientId: student.id,
            type: 'overdue',
            title: `Overdue Notice: ${book.title}`,
            message: `${book.title} is ${metrics.daysOverdue} ${
              metrics.daysOverdue === 1 ? 'day' : 'days'
            } overdue. Accrued fine: ${db.settings.currencySymbol}${metrics.calculatedFine.toFixed(2)}.`,
            createdAt: new Date().toISOString(),
            read: false,
            relatedLoanId: loan.id,
          });
        }
      } else if (metrics.derivedStatus === 'Due Soon') {
        if (student.notificationPrefs.dueSoon && !hasAlert(student.id, loan.id, 'due_soon')) {
          newItems.push({
            id: `ntf-auto-stu-ds-${loan.id}`,
            recipientId: student.id,
            type: 'due_soon',
            title:
              metrics.daysRemaining === 0
                ? `Due Today: ${book.title}`
                : `Due in ${metrics.daysRemaining} ${metrics.daysRemaining === 1 ? 'Day' : 'Days'}`,
            message: `Please return "${book.title}" by ${loan.dueDate} to avoid overdue fines.`,
            createdAt: new Date().toISOString(),
            read: false,
            relatedLoanId: loan.id,
          });
        }
      }
    }

    if (newItems.length > 0) {
      const updated = storageService.saveDatabase({
        ...db,
        notifications: [...newItems, ...db.notifications],
      });
      return updated.notifications;
    }

    return db.notifications;
  },

  markAsRead(notificationId: string): NotificationItem[] {
    const db = storageService.getDatabase();
    const updated = storageService.saveDatabase({
      ...db,
      notifications: db.notifications.map((n) =>
        n.id === notificationId ? { ...n, read: true } : n
      ),
    });
    return updated.notifications;
  },

  markAllAsRead(recipientId: string): NotificationItem[] {
    const db = storageService.getDatabase();
    const updated = storageService.saveDatabase({
      ...db,
      notifications: db.notifications.map((n) =>
        n.recipientId === recipientId ? { ...n, read: true } : n
      ),
    });
    return updated.notifications;
  },

  clearRead(recipientId: string): NotificationItem[] {
    const db = storageService.getDatabase();
    const updated = storageService.saveDatabase({
      ...db,
      notifications: db.notifications.filter(
        (n) => !(n.recipientId === recipientId && n.read)
      ),
    });
    return updated.notifications;
  },
};
