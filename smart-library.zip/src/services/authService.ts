import { Role, Student, UserSession } from '../types/library';
import { getTodayISO } from '../utils/dateUtils';
import { ServiceResult, storageService } from './storageService';

export interface LoginPayload {
  email: string;
  password: string;
  role: Role;
  rememberMe: boolean;
}

export interface RegisterStudentPayload {
  name: string;
  email: string;
  studentId: string;
  password: string;
  confirmPassword: string;
  department?: string;
}

export const authService = {
  login(payload: LoginPayload): ServiceResult<UserSession> {
    const email = payload.email.trim().toLowerCase();
    const password = payload.password;

    if (!email || !password) {
      return { ok: false, error: 'Please enter both email and password.' };
    }

    const db = storageService.getDatabase();

    if (payload.role === 'admin') {
      const admin = db.admins.find((a) => a.email.toLowerCase() === email);
      if (!admin || admin.password !== password) {
        return { ok: false, error: 'Invalid librarian email or password.' };
      }
      const session: UserSession = {
        id: admin.id,
        role: 'admin',
        name: admin.name,
        email: admin.email,
        roleTitle: admin.roleTitle,
      };
      storageService.saveSession(session, payload.rememberMe);
      storageService.saveRememberedLogin(email, 'admin', payload.rememberMe);
      return { ok: true, data: session };
    }

    const student = db.students.find((s) => s.email.toLowerCase() === email);
    if (!student || student.password !== password) {
      return { ok: false, error: 'Invalid student email or password.' };
    }
    if (student.status === 'inactive') {
      return {
        ok: false,
        error: 'This student account is currently inactive. Please contact the librarian.',
      };
    }

    const session: UserSession = {
      id: student.id,
      role: 'student',
      name: student.name,
      email: student.email,
      studentId: student.studentId,
    };
    storageService.saveSession(session, payload.rememberMe);
    storageService.saveRememberedLogin(email, 'student', payload.rememberMe);
    return { ok: true, data: session };
  },

  registerStudent(payload: RegisterStudentPayload): ServiceResult<UserSession> {
    const name = payload.name.trim();
    const email = payload.email.trim().toLowerCase();
    const studentId = payload.studentId.trim().toUpperCase();
    const password = payload.password;
    const confirmPassword = payload.confirmPassword;

    if (name.length < 2) {
      return { ok: false, error: 'Full name must be at least 2 characters.' };
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return { ok: false, error: 'Please enter a valid email address.' };
    }
    if (!/^[A-Z0-9-]{4,20}$/.test(studentId)) {
      return {
        ok: false,
        error: 'Student ID must be 4–20 characters (letters, numbers, or hyphens, e.g. STU-2026-205).',
      };
    }
    if (password.length < 6) {
      return { ok: false, error: 'Password must be at least 6 characters.' };
    }
    if (password !== confirmPassword) {
      return { ok: false, error: 'Passwords do not match.' };
    }

    const db = storageService.getDatabase();

    if (db.admins.some((a) => a.email.toLowerCase() === email)) {
      return { ok: false, error: 'That email address is reserved and cannot be registered.' };
    }
    if (db.students.some((s) => s.email.toLowerCase() === email)) {
      return { ok: false, error: 'An account with this email address already exists.' };
    }
    if (db.students.some((s) => s.studentId.toUpperCase() === studentId)) {
      return { ok: false, error: 'This Student ID is already registered.' };
    }

    const newStudent: Student = {
      id: `stu-${Date.now()}`,
      studentId,
      name,
      email,
      password,
      department: payload.department?.trim() || 'General Studies',
      year: 'Undergraduate',
      status: 'active',
      interests: ['Programming', 'Data Science'],
      monthlyGoal: 3,
      notificationPrefs: { dueSoon: true, overdue: true, confirmations: true },
      joinedAt: getTodayISO(),
    };

    const updatedDb = {
      ...db,
      students: [newStudent, ...db.students],
      wishlists: { ...db.wishlists, [newStudent.id]: [] },
    };
    storageService.saveDatabase(updatedDb);

    const session: UserSession = {
      id: newStudent.id,
      role: 'student',
      name: newStudent.name,
      email: newStudent.email,
      studentId: newStudent.studentId,
    };
    storageService.saveSession(session, true);
    return { ok: true, data: session };
  },

  logout(): void {
    storageService.saveSession(null);
  },
};
