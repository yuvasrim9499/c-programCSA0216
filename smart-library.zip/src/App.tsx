/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { MotionConfig } from 'motion/react';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { AppLayout } from './components/AppLayout';
import { ProtectedRoute } from './components/ProtectedRoute';
import { ToastContainer } from './components/ToastContainer';
import { LibraryProvider } from './context/LibraryContext';
import { BookCatalogPage } from './pages/BookCatalogPage';
import { BookDetailPage } from './pages/BookDetailPage';
import { DashboardPage } from './pages/DashboardPage';
import { IssueReturnPage } from './pages/IssueReturnPage';
import { LoginPage } from './pages/LoginPage';
import { MyLoansPage } from './pages/MyLoansPage';
import { NotificationsPage } from './pages/NotificationsPage';
import { ProfilePage } from './pages/ProfilePage';
import { RecommendationsPage } from './pages/RecommendationsPage';
import { ReportsPage } from './pages/ReportsPage';
import { SettingsPage } from './pages/SettingsPage';
import { StudentsPage } from './pages/StudentsPage';
import { WishlistPage } from './pages/WishlistPage';

export default function App() {
  return (
    <MotionConfig reducedMotion="user">
      <LibraryProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/login" element={<LoginPage />} />

            <Route
              element={
                <ProtectedRoute>
                  <AppLayout />
                </ProtectedRoute>
              }
            >
              <Route path="/dashboard" element={<DashboardPage />} />
              <Route path="/books" element={<BookCatalogPage />} />
              <Route path="/books/:id" element={<BookDetailPage />} />
              <Route path="/recommendations" element={<RecommendationsPage />} />
              <Route path="/notifications" element={<NotificationsPage />} />
              <Route path="/settings" element={<SettingsPage />} />

              {/* Admin-Only Routes */}
              <Route
                path="/students"
                element={
                  <ProtectedRoute allowedRoles={['admin']}>
                    <StudentsPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/issue-return"
                element={
                  <ProtectedRoute allowedRoles={['admin']}>
                    <IssueReturnPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/reports"
                element={
                  <ProtectedRoute allowedRoles={['admin']}>
                    <ReportsPage />
                  </ProtectedRoute>
                }
              />

              {/* Student-Only Routes */}
              <Route
                path="/my-loans"
                element={
                  <ProtectedRoute allowedRoles={['student']}>
                    <MyLoansPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/wishlist"
                element={
                  <ProtectedRoute allowedRoles={['student']}>
                    <WishlistPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/profile"
                element={
                  <ProtectedRoute allowedRoles={['student']}>
                    <ProfilePage />
                  </ProtectedRoute>
                }
              />
            </Route>

            <Route path="/" element={<Navigate to="/login" replace />} />
            <Route path="*" element={<Navigate to="/dashboard" replace />} />
          </Routes>
          <ToastContainer />
        </BrowserRouter>
      </LibraryProvider>
    </MotionConfig>
  );
}
