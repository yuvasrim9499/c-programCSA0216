import React, { createContext, useCallback, useEffect, useMemo, useState } from 'react';
import { authService, LoginPayload, RegisterStudentPayload } from '../services/authService';
import { BookInput, bookService } from '../services/bookService';
import { IssueBookPayload, loanService } from '../services/loanService';
import { notificationService } from '../services/notificationService';
import { recommendationService } from '../services/recommendationService';
import { settingsService, StudentProfilePatch } from '../services/settingsService';
import { ServiceResult, storageService } from '../services/storageService';
import { StudentInput, studentService } from '../services/studentService';
import {
  Book,
  LibraryDatabase,
  LibrarySettings,
  Loan,
  NotificationItem,
  Student,
  ToastMessage,
  UserSession,
} from '../types/library';

interface LibraryContextValue {
  user: UserSession | null;
  currentStudent: Student | undefined;
  books: Book[];
  students: Student[];
  loans: Loan[];
  notifications: NotificationItem[];
  unreadNotificationCount: number;
  settings: LibrarySettings;
  wishlists: Record<string, string[]>;
  currentUserWishlist: string[];
  toasts: ToastMessage[];
  showToast: (toast: Omit<ToastMessage, 'id'>) => void;
  dismissToast: (id: string) => void;
  login: (payload: LoginPayload) => ServiceResult<UserSession>;
  registerStudent: (payload: RegisterStudentPayload) => ServiceResult<UserSession>;
  logout: () => void;
  addBook: (input: BookInput) => ServiceResult<Book>;
  updateBook: (id: string, input: BookInput) => ServiceResult<Book>;
  deleteBook: (id: string) => ServiceResult<void>;
  addStudent: (input: StudentInput) => ServiceResult<Student>;
  updateStudent: (id: string, input: StudentInput) => ServiceResult<Student>;
  toggleStudentStatus: (id: string) => ServiceResult<Student>;
  issueBook: (payload: IssueBookPayload) => ServiceResult<Loan>;
  returnBook: (loanId: string, returnDate?: string) => ServiceResult<Loan>;
  toggleWishlist: (bookId: string) => void;
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;
  clearReadNotifications: () => void;
  updateAdminSettings: (next: LibrarySettings) => ServiceResult<LibrarySettings>;
  updateStudentProfile: (patch: StudentProfilePatch) => ServiceResult<Student>;
  resetDemoData: () => void;
}

export const LibraryContext = createContext<LibraryContextValue | null>(null);

export const LibraryProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [db, setDb] = useState<LibraryDatabase>(() => {
    storageService.getDatabase();
    notificationService.syncLoanAlerts();
    return storageService.getDatabase();
  });

  const [user, setUser] = useState<UserSession | null>(() => storageService.getSession());
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const refreshDb = useCallback(() => {
    notificationService.syncLoanAlerts();
    setDb(storageService.getDatabase());
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const showToast = useCallback(
    (toast: Omit<ToastMessage, 'id'>) => {
      const id = `toast-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
      setToasts((prev) => [...prev, { ...toast, id }]);
      window.setTimeout(() => {
        dismissToast(id);
      }, 4200);
    },
    [dismissToast]
  );

  // Sync across tabs if localStorage changes externally
  useEffect(() => {
    const handleStorage = () => {
      setDb(storageService.getDatabase());
      setUser(storageService.getSession());
    };
    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, []);

  const currentStudent = useMemo(() => {
    if (!user || user.role !== 'student') return undefined;
    return db.students.find((s) => s.id === user.id);
  }, [db.students, user]);

  const userNotifications = useMemo(() => {
    if (!user) return [];
    const recipientKey = user.role === 'admin' ? 'admin' : user.id;
    return db.notifications
      .filter((n) => n.recipientId === recipientKey)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [db.notifications, user]);

  const unreadNotificationCount = useMemo(
    () => userNotifications.filter((n) => !n.read).length,
    [userNotifications]
  );

  const currentUserWishlist = useMemo(() => {
    if (!user || user.role !== 'student') return [];
    return db.wishlists[user.id] || [];
  }, [db.wishlists, user]);

  const login = useCallback(
    (payload: LoginPayload) => {
      const result = authService.login(payload);
      if (result.ok && result.data) {
        setUser(result.data);
        refreshDb();
      }
      return result;
    },
    [refreshDb]
  );

  const registerStudent = useCallback(
    (payload: RegisterStudentPayload) => {
      const result = authService.registerStudent(payload);
      if (result.ok && result.data) {
        setUser(result.data);
        refreshDb();
      }
      return result;
    },
    [refreshDb]
  );

  const logout = useCallback(() => {
    authService.logout();
    setUser(null);
  }, []);

  const addBook = useCallback(
    (input: BookInput) => {
      const res = bookService.addBook(input);
      if (res.ok) refreshDb();
      return res;
    },
    [refreshDb]
  );

  const updateBook = useCallback(
    (id: string, input: BookInput) => {
      const res = bookService.updateBook(id, input);
      if (res.ok) refreshDb();
      return res;
    },
    [refreshDb]
  );

  const deleteBook = useCallback(
    (id: string) => {
      const res = bookService.deleteBook(id);
      if (res.ok) refreshDb();
      return res;
    },
    [refreshDb]
  );

  const addStudent = useCallback(
    (input: StudentInput) => {
      const res = studentService.addStudent(input);
      if (res.ok) refreshDb();
      return res;
    },
    [refreshDb]
  );

  const updateStudent = useCallback(
    (id: string, input: StudentInput) => {
      const res = studentService.updateStudent(id, input);
      if (res.ok) {
        refreshDb();
        if (user && user.id === id && res.data) {
          setUser({ ...user, name: res.data.name, email: res.data.email, studentId: res.data.studentId });
        }
      }
      return res;
    },
    [refreshDb, user]
  );

  const toggleStudentStatus = useCallback(
    (id: string) => {
      const res = studentService.toggleStatus(id);
      if (res.ok) refreshDb();
      return res;
    },
    [refreshDb]
  );

  const issueBook = useCallback(
    (payload: IssueBookPayload) => {
      const res = loanService.issueBook(payload);
      if (res.ok) refreshDb();
      return res;
    },
    [refreshDb]
  );

  const returnBook = useCallback(
    (loanId: string, returnDate?: string) => {
      const res = loanService.returnBook(loanId, returnDate);
      if (res.ok) refreshDb();
      return res;
    },
    [refreshDb]
  );

  const toggleWishlist = useCallback(
    (bookId: string) => {
      if (!user || user.role !== 'student') return;
      const before = db.wishlists[user.id] || [];
      const wasIn = before.includes(bookId);
      recommendationService.toggleWishlist(user.id, bookId);
      refreshDb();
      const book = db.books.find((b) => b.id === bookId);
      showToast({
        type: 'info',
        title: wasIn ? 'Removed from Wishlist' : 'Saved to Wishlist',
        description: book ? book.title : undefined,
      });
    },
    [db.books, db.wishlists, refreshDb, showToast, user]
  );

  const markNotificationRead = useCallback(
    (id: string) => {
      notificationService.markAsRead(id);
      setDb(storageService.getDatabase());
    },
    []
  );

  const markAllNotificationsRead = useCallback(() => {
    if (!user) return;
    const recipientKey = user.role === 'admin' ? 'admin' : user.id;
    notificationService.markAllAsRead(recipientKey);
    setDb(storageService.getDatabase());
  }, [user]);

  const clearReadNotifications = useCallback(() => {
    if (!user) return;
    const recipientKey = user.role === 'admin' ? 'admin' : user.id;
    notificationService.clearRead(recipientKey);
    setDb(storageService.getDatabase());
  }, [user]);

  const updateAdminSettings = useCallback(
    (next: LibrarySettings) => {
      const res = settingsService.updateAdminSettings(next);
      if (res.ok) refreshDb();
      return res;
    },
    [refreshDb]
  );

  const updateStudentProfile = useCallback(
    (patch: StudentProfilePatch) => {
      if (!user || user.role !== 'student') {
        return { ok: false, error: 'Only student accounts can update student profile settings.' };
      }
      const res = settingsService.updateStudentProfile(user.id, patch);
      if (res.ok && res.data) {
        setUser({
          ...user,
          name: res.data.name,
          email: res.data.email,
        });
        refreshDb();
      }
      return res;
    },
    [refreshDb, user]
  );

  const resetDemoData = useCallback(() => {
    settingsService.resetDemoData();
    notificationService.syncLoanAlerts();
    setDb(storageService.getDatabase());
    // Re-sync current session if user is a seeded account
    if (user) {
      const freshDb = storageService.getDatabase();
      if (user.role === 'admin') {
        const adm = freshDb.admins[0];
        if (adm) {
          const sess: UserSession = {
            id: adm.id,
            role: 'admin',
            name: adm.name,
            email: adm.email,
            roleTitle: adm.roleTitle,
          };
          storageService.saveSession(sess);
          setUser(sess);
        }
      } else {
        const found = freshDb.students.find((s) => s.id === user.id) || freshDb.students[0];
        if (found) {
          const sess: UserSession = {
            id: found.id,
            role: 'student',
            name: found.name,
            email: found.email,
            studentId: found.studentId,
          };
          storageService.saveSession(sess);
          setUser(sess);
        }
      }
    }
  }, [user]);

  const value: LibraryContextValue = {
    user,
    currentStudent,
    books: db.books,
    students: db.students,
    loans: db.loans,
    notifications: userNotifications,
    unreadNotificationCount,
    settings: db.settings,
    wishlists: db.wishlists,
    currentUserWishlist,
    toasts,
    showToast,
    dismissToast,
    login,
    registerStudent,
    logout,
    addBook,
    updateBook,
    deleteBook,
    addStudent,
    updateStudent,
    toggleStudentStatus,
    issueBook,
    returnBook,
    toggleWishlist,
    markNotificationRead,
    markAllNotificationsRead,
    clearReadNotifications,
    updateAdminSettings,
    updateStudentProfile,
    resetDemoData,
  };

  return <LibraryContext.Provider value={value}>{children}</LibraryContext.Provider>;
};
