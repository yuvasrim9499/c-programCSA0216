export type Role = 'admin' | 'student';

export type BookCategory =
  | 'Programming'
  | 'Artificial Intelligence'
  | 'Data Science'
  | 'Web & Systems'
  | 'Software Engineering'
  | 'Computer Science'
  | 'Design & UX';

export type StudentStatus = 'active' | 'inactive';

export type LoanRecordStatus = 'active' | 'returned';

export type DerivedLoanStatus = 'Issued' | 'Due Soon' | 'Overdue' | 'Returned';

export type NotificationType = 'due_soon' | 'overdue' | 'issue' | 'return' | 'system';

export interface UserSession {
  id: string;
  role: Role;
  name: string;
  email: string;
  studentId?: string;
  roleTitle?: string;
}

export interface Book {
  id: string;
  title: string;
  author: string;
  isbn: string;
  category: BookCategory;
  description: string;
  publicationYear: number;
  totalCopies: number;
  availableCopies: number;
  shelfLocation: string;
  rating: number;
  coverUrl: string;
  addedAt: string;
}

export interface NotificationPreferences {
  dueSoon: boolean;
  overdue: boolean;
  confirmations: boolean;
}

export interface Student {
  id: string;
  studentId: string;
  name: string;
  email: string;
  password: string; // Demo only - never store plaintext passwords client-side in production
  department: string;
  year: string;
  status: StudentStatus;
  interests: BookCategory[];
  monthlyGoal: number;
  notificationPrefs: NotificationPreferences;
  joinedAt: string;
}

export interface AdminAccount {
  id: string;
  name: string;
  email: string;
  password: string; // Demo only
  roleTitle: string;
}

export interface Loan {
  id: string;
  bookId: string;
  studentId: string; // References Student.id
  issueDate: string; // YYYY-MM-DD
  dueDate: string; // YYYY-MM-DD
  returnDate: string | null; // YYYY-MM-DD | null
  status: LoanRecordStatus;
  finePaid: number;
  notes?: string;
}

export interface NotificationItem {
  id: string;
  recipientId: string; // 'admin' or Student.id
  type: NotificationType;
  title: string;
  message: string;
  createdAt: string; // ISO string
  read: boolean;
  relatedLoanId?: string;
}

export interface LibrarySettings {
  libraryName: string;
  defaultLoanDays: number;
  maxActiveLoansPerStudent: number;
  dailyOverdueFine: number;
  currencySymbol: string;
  dueSoonWindowDays: number;
}

export type WishlistMap = Record<string, string[]>;

export interface BookRecommendation {
  book: Book;
  reason: string;
  score: number;
  matchType: 'history' | 'interest' | 'wishlist' | 'popular';
}

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info' | 'warning';
  title: string;
  description?: string;
}

export interface LibraryDatabase {
  books: Book[];
  students: Student[];
  admins: AdminAccount[];
  loans: Loan[];
  notifications: NotificationItem[];
  settings: LibrarySettings;
  wishlists: WishlistMap;
  version: number;
}
