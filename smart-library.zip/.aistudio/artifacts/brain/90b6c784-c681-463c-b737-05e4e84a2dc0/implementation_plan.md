# Smart Library Motion & Transition Polish

Introduce cohesive `AnimatePresence` and `motion.div` choreography across every route transition, card grid, tab view, and interactive panel in Smart Library so navigation, filtering, and state updates feel fluid and responsive without sacrificing speed.

## User Review & Critical Decisions

> [!IMPORTANT]
> The clarifying questions were dismissed, so the recommended motion defaults below will be used unless you request changes before approving this plan.

- **Page Transition Style**: Subtle fade paired with a short `8px` vertical slide (`AnimatePresence mode="wait"` over frozen outlet context so exiting views animate out cleanly before entering views mount).
- **Card Entry Choreography**: Gentle staggered reveal (`40ms` per item, capped fast so grids appear immediately) for dashboard summary cards, book catalog grids, recommendation cards, and notification feeds.
- **Filter & Tab Transitions**: Smooth `AnimatePresence` crossfades for tab panels (Circulation, My Loans, Student Profile, Notifications) and gentle layout-aware card entry/exit states when filtering or paginating books.
- **Accessibility & Performance**: All motion uses compositor-only properties (`transform`, `opacity`) under the existing global reduced-motion preference wrapper (`MotionConfig`), keeping routine interactions within `150ms–220ms`.

---

## 1. Overview & Core Concept

- **What It Does**: Upgrades Smart Library's existing static page bodies, card grids, and tab containers with orchestrated `motion.div` and `AnimatePresence` wrappers so every route change, card reveal, filter update, and tab switch moves smoothly.
- **Target Audience / Persona**: Librarians managing circulation and catalog records, and students browsing books, checking loans, and exploring recommendations.
- **Key Value**: Eliminates abrupt visual snaps when switching pages, filtering the catalog, toggling grid/list layouts, or moving between tabs—making the entire interface feel cohesive and tactile while preserving instant control responsiveness.

---

## 2. User Experience & Visual Design

- **Key User Flows**:
  1. **Route Navigation**: Clicking any sidebar item, header shortcut, or dashboard quick link smoothly fades and lifts the outgoing page out while the incoming page glides into place—without resetting the fixed sidebar or top header.
  2. **Dashboard & Catalog Discovery**: Summary metric cards and book cover cards enter in a crisp, rapid stagger rather than popping in all at once; switching between Grid and List views or filtering by category/availability animates transitions smoothly and shows an animated empty state when no books match.
  3. **Multi-Tab Workflows**: Switching between *Issue Book* / *Return Book*, *Current Loans* / *Borrowing History*, *All* / *Unread* notifications, and the five *Student Profile* tabs smoothly crossfades panel content while highlighting the active tab indicator.
- **Visual Identity & Theme**:
  - *Aesthetic Direction*: Crisp, editorial SaaS workspace balancing deep navy navigation (`#0C102D`) with an airy lavender canvas (`#F5F4FF`) and clean white elevated surfaces.
  - *Color Tokens*: Primary accent (`--brand-purple`: `#713BFF`), secondary accent (`--brand-blue`: `#4361EE`), deep navy surface (`--sidebar-navy`: `#0C102D`), canvas (`--canvas-lavender`: `#F5F4FF`), and semantic green/amber/crimson state badges.
  - *Typography & Hierarchy*: `Plus Jakarta Sans` for headings and metric figures, `DM Sans` for readable interface copy, and `JetBrains Mono` with tabular numerals (`tabular-nums`) for ISBNs, student IDs, dates, and financial figures.
  - *Component Styling & Layout*: Single-elevation white cards (`16px` radius, hairline indigo-tinted borders), responsive grids, and horizontally scrollable tables that preserve layout stability during animations.
- **Interactive Feedback & Motion**:
  - Routine hover/press feedback settles within `160ms` using `cubic-bezier(0.16, 1, 0.3, 1)`.
  - Page and panel transitions complete in `180ms–220ms`.
  - Existing modal dialogs, stacked toast notifications, and the floating login hero illustration remain aligned with this unified motion language.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Frozen Route Outlet Inside `AnimatePresence`**
  - *Chosen Approach*: Capture the current outlet element per route location inside an animated wrapper using `AnimatePresence mode="wait"` so React Router does not swap the child view prematurely before the exit animation completes.
  - *Why*: Wrapping a plain `<Outlet />` directly inside `AnimatePresence` skips exit animations because the inner route updates immediately on navigation.
  - *Alternatives Considered*: Animating only on mount (`initial` → `animate`), which feels noticeably less cohesive when moving between sibling pages.
- **Decision 2: Compositor-Only Motion & Capped Stagger Timing**
  - *Chosen Approach*: Animate only `opacity` and `transform` (`translateY`, `scale`), with a short `40ms` stagger across card grids and `layout="position"` only where list reordering occurs.
  - *Why*: Prevents layout thrashing, keeps Recharts containers sized reliably on mount, and respects the `prefers-reduced-motion` policy enforced globally.
  - *Alternatives Considered*: Animating container heights or heavy spring physics across large tables, which can cause chart resize flicker and sluggish perceived speed.
- **Decision 3: Retaining the Existing `motion` Package**
  - *Chosen Approach*: Continue using the already-installed `motion/react` (Framer Motion v12) package, which provides the standard `motion.div`, `AnimatePresence`, and `MotionConfig` APIs.
  - *Why*: Zero extra bundle bloat or duplicate dependencies while delivering full Framer Motion v12 capabilities.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

- **Architecture & Component Diagram**:

```text
┌──────────────────────────────────────────────────────────────────────┐
│                  MotionConfig (reducedMotion="user")                 │
│  ┌────────────────────────────────────────────────────────────────┐  │
│  │                     LibraryContext & Services                  │  │
│  └───────────────────────────────┬────────────────────────────────┘  │
│                                  ▼                                   │
│  ┌────────────────────────────────────────────────────────────────┐  │
│  │                       Application Shell                        │  │
│  │  ┌──────────────┐   ┌───────────────────────────────────────┐  │  │
│  │  │ Fixed/Drawer │   │  Header (Animated Profile Dropdown)   │  │  │
│  │  │   Sidebar    │   ├───────────────────────────────────────┤  │  │
│  │  │ (Spring Pill)│   │  AnimatePresence mode="wait"          │  │  │
│  │  └──────────────┘   │   └─► AnimatedOutlet (motion.div)     │  │  │
│  │                     └──────────────────┬────────────────────┘  │  │
│  └────────────────────────────────────────┼───────────────────────┘  │
│                                           ▼                          │
│  ┌────────────────────────────────────────────────────────────────┐  │
│  │                   Shared Motion Primitives                     │  │
│  │   • PageTransition   • StaggerGrid / StaggerItem               │  │
│  │   • TabPanelPresence • AnimatedSectionCard                     │  │
│  └───────────────────────────────┬────────────────────────────────┘  │
│                                  ▼                                   │
│  ┌────────────────────────────────────────────────────────────────┐  │
│  │                 Animated Views & Card Grids                    │  │
│  │  Dashboards (KPI + Charts) · Catalog & Wishlist (Grid/List)    │  │
│  │  Recommendations · Issue/Return Tabs · Profile Tabs · Reports  │  │
│  │  Notifications Feed · Student Directory · Settings             │  │
│  └────────────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────────────┘
```

- **Data Model & State**:
  - All existing library entities (`Book`, `Student`, `Loan`, `NotificationItem`, `LibrarySettings`, `WishlistMap`) and `localStorage` persistence remain untouched; motion wrappers read reactive state without altering business rules or inventory reconciliation.
- **Interactive Component & State Mapping**:
  - **Route Changes**: Navigating updates router location → `AnimatePresence mode="wait"` fades/slides out the previous frozen outlet (`150ms`) → mounts the new page wrapper (`200ms`).
  - **Catalog Filtering, Sorting & Pagination**: Updating search, category, availability, sort, or page updates the visible slice → `AnimatePresence` transitions between matching card grids and the empty state, while `StaggerGrid` / `StaggerItem` animates card entries cleanly.
  - **Dashboard KPI & Panel Entry**: Admin and Student dashboards stagger their 4 summary `StatCard` blocks, then reveal chart/activity/overdue/goal panels with `motion.div` wrappers without delaying chart measurement.
  - **Tabbed Workflows**: Switching tabs in Circulation (`Issue` / `Return`), Student Loans (`Current` / `History`), Student Profile (`Current` / `History` / `Wishlist` / `Fines` / `Notifications`), and Notifications (`All` / `Unread`) animates both the active tab pill (`layoutId`) and the active panel via `AnimatePresence mode="wait"`.
